# PATCH_MANIFEST_v1.4.4.md

## Patch Identity

```text
Internal version: 1.4.4
External ZIP name: Portable_BOS_v1.44.zip
Date: 2026-07-03
Rollback target: Portable_BOS_v1.43.zip / internal v1.4.3 package
```

## Reason For Patch

During HomeVisualizer development, two reusable process rules were recorded in `docs/BOS_REVISION_BACKLOG.md` without interrupting active product work: a User-Facing Design Review Gate (technical wording such as `Save JSON` reaching end users) and a Fast UI Polish Mode (full regression verification is unnecessarily heavy for small wording/label changes). This is the scheduled BOS maintenance checkpoint that promotes both into the core BOS package.

## Files Added

```text
BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md
BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md
BOS_MENU_BOOK_v1.4.4.md
BOS_INTEGRITY_MAP_v1.4.4.md
INTEGRITY_REPORT_v1.4.4.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.4.md
PATCH_MANIFEST_v1.4.4.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.4.md
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.4.md
```

## Files Changed

```text
00_FIRST_READ_ME.md
ACTIVATE_BOS_FROM_ZIP.md
ACTIVATE_BOS_GATEWAY.ps1
BOS_ACTIVATION_MANIFEST.md
BOS_UPGRADE_MANAGER.ps1
BUILD_BOS_ACTIVATION_ZIP.ps1
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERIFY_BOS_PACKAGE.ps1
VERSION.txt
BOS_version_1.4/MANIFEST.md
BOS_version_1.4/PROJECT_STATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/MODULE_REGISTRY.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
```

## Files Archived

```text
BOS_MENU_BOOK_v1.4.3.md -> archive/v1.4.3_root_release_files/
BOS_INTEGRITY_MAP_v1.4.3.md -> archive/v1.4.3_root_release_files/
INTEGRITY_REPORT_v1.4.3.md -> archive/v1.4.3_root_release_files/
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.3.md -> archive/v1.4.3_root_release_files/
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.3.md -> BOS_version_1.4/07_ARCHIVE/v1.4.3_upgrade_reports/
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.3.md -> BOS_version_1.4/07_ARCHIVE/v1.4.3_upgrade_reports/
```

## Registry / Manifest Impact

```text
MODULE_REGISTRY.md updated: yes (root and 12_UPGRADE_SYSTEM copies)
BOS_ACTIVATION_MANIFEST.md updated: yes
BOS_version_1.4/MANIFEST.md updated: yes
```

## Verification Plan

```text
1. Run source verification (required-file presence + registry path resolution).
2. Check file completeness against this manifest.
3. Extract ZIP into clean temp folder.
4. Run verification from the extracted folder.
5. Generate SHA256.
```

## Expected Result

```text
PACKAGE VERIFICATION PASSED
BOS UPGRADE MANAGER PASSED
Clean ZIP extraction verification passed
```

## User Content Survival Check

```text
Does the patch touch user project folders? no
This patch modifies only the Portable BOS package. It does not touch
C:\Apps\HomeVisualizer or any other user project folder.
```
