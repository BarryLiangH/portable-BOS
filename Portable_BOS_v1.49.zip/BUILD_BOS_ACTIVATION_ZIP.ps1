# BUILD_BOS_ACTIVATION_ZIP.ps1
# Rebuilds the Portable BOS v1.4.9 release ZIP from the current package folder.
# v1.4.5: generates PACKAGE_CHECKSUMS.txt (SHA256 per file) before verification.
# Simple outside, detailed inside.

param(
    [string]$OutputZip = ""
)

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Parent = Split-Path -Parent $PackageRoot

if ([string]::IsNullOrWhiteSpace($OutputZip)) {
    $OutputZip = Join-Path $Parent "Portable_BOS_v1.49.zip"
}


# --- v1.4.5 Package Checksums Generation ---
# Every file in the package (except the checksum file itself) gets a SHA256 line:
#   <lowercase sha256>  <relative/path/with/forward/slashes>
$ChecksumFile = Join-Path $PackageRoot "PACKAGE_CHECKSUMS.txt"
$Lines = @()
$AllFiles = Get-ChildItem -Path $PackageRoot -Recurse -File | Sort-Object FullName
foreach ($F in $AllFiles) {
    $Rel = $F.FullName.Substring($PackageRoot.Length).TrimStart('\','/') -replace '\\', '/'
    if ($Rel -eq "PACKAGE_CHECKSUMS.txt") { continue }
    $H = (Get-FileHash -Algorithm SHA256 -Path $F.FullName).Hash.ToLower()
    $Lines += "$H  $Rel"
}
$Lines | Out-File -FilePath $ChecksumFile -Encoding utf8
Write-Host ("PACKAGE_CHECKSUMS.txt written with {0} entries." -f $Lines.Count) -ForegroundColor Cyan

& (Join-Path $PackageRoot "VERIFY_BOS_PACKAGE.ps1")

if (Test-Path $OutputZip) {
    Remove-Item $OutputZip -Force
}

Compress-Archive -Path (Join-Path $PackageRoot "*") -DestinationPath $OutputZip -Force

$Hash = Get-FileHash -Algorithm SHA256 -Path $OutputZip
$ShaFile = "$OutputZip.sha256.txt"
"$($Hash.Hash.ToLower())  $(Split-Path -Leaf $OutputZip)" | Out-File -FilePath $ShaFile -Encoding utf8

Write-Host ""
Write-Host "Portable BOS package rebuilt:" -ForegroundColor Green
Write-Host $OutputZip -ForegroundColor Cyan
Write-Host "SHA256 written:" -ForegroundColor Green
Write-Host $ShaFile -ForegroundColor Cyan
