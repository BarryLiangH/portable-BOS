# ACTIVATE_BOS_FROM_ZIP.md

# How To Activate Portable BOS From ZIP

Version: 1.4.9

## Simple Method

1. Upload the ZIP to an AI chat.
2. Tell the AI:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

3. The AI reads:
   - `00_FIRST_READ_ME.md`
   - `BOS_ACTIVATION_MANIFEST.md`
   - `MODULE_REGISTRY.md`
4. The AI loads Core + Governance + User Content Survival + Incubator v1.1 + Memory + Upgrade System.
5. The AI asks whether Barry already has an Incubator handoff or wants to run Incubator v1.1 from a raw idea.
6. The AI proposes Block 1 only.
7. Barry approves before coding starts.

## Local Windows Method

Simple ZIP activation is preferred.

The local Gateway installer is optional. It must protect user content and default to SKIP existing project files.

Run only when needed:

```powershell
powershell -ExecutionPolicy Bypass -File ".\ACTIVATE_BOS_GATEWAY.ps1" -ProjectName "MyProject"
```

## Upgrade Method

For BOS package upgrades, run:

```powershell
powershell -ExecutionPolicy Bypass -File ".\BOS_UPGRADE_MANAGER.ps1"
```

To rebuild a verified ZIP after a complete upgrade:

```powershell
powershell -ExecutionPolicy Bypass -File ".\BOS_UPGRADE_MANAGER.ps1" -BuildRelease
```

## Rule

The AI should not ask Barry to manually open and paste many MD files.

The manifest and registry are the bootloader.

## v1.4.9 Universal Incubation Upgrade Note

Activation from ZIP does not require running the Gateway installer.

The Gateway installer is optional and must pass the User Content Survival Gate before use. Any release ZIP must pass clean-install simulation before release.

Main rule:

```text
User content must survive rerun.
```
