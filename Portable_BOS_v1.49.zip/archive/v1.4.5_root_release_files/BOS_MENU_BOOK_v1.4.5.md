# BOS_MENU_BOOK_v1.4.5.md

## Portable BOS Menu Book

Version: 1.4.5 - Integrity, Checksums, Core Digest, Universal Design Rules

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.5 Adds

```text
1. BOS_CORE_DIGEST.md - one-page constraint summary loaded early at activation.
2. PACKAGE_CHECKSUMS.txt - per-file SHA256 verification; verifier now checks
   file content, not only file existence.
3. Registry copy identity check - root and 12_UPGRADE_SYSTEM MODULE_REGISTRY.md
   must be byte-identical.
4. Gate numbering fix - duplicate Gate 6 corrected; User Content Survival Gate
   is now Gate 7.
5. Version Header Rule - per-file package version headers retired; VERSION.txt
   is the single version source.
6. FAILURE_LIBRARY.md index, entry rules, and F010 renumbering.
7. Two universal design standards promoted from HomeVisualizer:
   BOS_INTERACTION_EDIT_SESSION_RULE.md and BOS_WORKSPACE_FIRST_LAYOUT_RULE.md.
```

## Menu A - Easy ZIP Activation

Barry uploads the BOS ZIP and says:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

AI should respond:

```text
BOS v1.4.5 activated.

I loaded the Core Digest, Module Registry, Core, Governance, User Content Survival,
Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard,
User-Facing Design Review Gate, Fast UI Polish Mode, Universal Design Rules,
Gateway Safety Notice, and Persona rules.

Do you already have an Incubator-generated idea / Project Seed, or should I run
Incubator v1.1 from your raw idea?
```

## Menu C - Upgrade Safety

Before any BOS upgrade release:

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Update PATCH_MANIFEST.
6. Regenerate PACKAGE_CHECKSUMS.txt.
7. Run package verification (files + registry + checksums).
8. Extract ZIP into a clean temp folder.
9. Run verification again from the extracted ZIP.
10. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.45.zip
Internal version: 1.4.5
Details: BOS_UPGRADE_JOURNAL.md and PATCH_MANIFEST_v1.4.5.md
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
USER-FACING DESIGN REVIEW CHECK:
VERIFICATION:
PROMOTION CHECK:
```

## Menu F - Fast UI Polish Mode Quick Reference

```text
Use for: wording, labels, tooltips, grouping, spacing, non-logic display polish.
Do not use for: geometry, data-model, persistence, validation, transform, or any
behavioural/logic change.
Steps: backup -> patch UI files + targeted tests -> syntax check -> targeted UI
verification -> design review gate -> browser check -> checkpoint + next approval.
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
Verify content by checksum, not only file presence.
No user-facing wording ships without a design review pass.
```
