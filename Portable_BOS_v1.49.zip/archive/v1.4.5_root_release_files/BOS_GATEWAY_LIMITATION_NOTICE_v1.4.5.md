# BOS_GATEWAY_LIMITATION_NOTICE_v1.4.5.md

## Purpose

Carries forward the Gateway Safety Notice under Portable BOS v1.4.5.

## Notice

Normal activation does not require running any installer.

If the Gateway installer is used, it must not silently overwrite existing project files. Existing project files must be skipped by default and recorded in a conflict/rerun report unless Barry explicitly approves replacement.

This rule applies to all user-created content, not only `README.md` and `PROJECT_STATE.md`.

## v1.4.5 Change

No change to Gateway installer behaviour. This notice is re-issued under the new version number for registry consistency. Note: the duplicate "Gate 6" numbering in BOS_INTEGRITY_GATES.md was corrected in v1.4.5 — the User Content Survival Gate is now Gate 7.

## Rollback

If Gateway behaviour needs to roll back, use `Portable_BOS_v1.44.zip` / internal v1.4.4.
