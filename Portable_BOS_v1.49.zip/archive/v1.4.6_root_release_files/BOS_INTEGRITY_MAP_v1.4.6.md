# BOS_INTEGRITY_MAP_v1.4.6.md

## Purpose

Map the active Portable BOS v1.4.6 integrity structure.

## Active Identity

```text
External ZIP: Portable_BOS_v1.46.zip
Internal version: 1.4.6
Core folder: BOS_version_1.4
```

## Required Active Root Files

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
PACKAGE_CHECKSUMS.txt
BOS_MENU_BOOK_v1.4.6.md
BOS_INTEGRITY_MAP_v1.4.6.md
INTEGRITY_REPORT_v1.4.6.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.6.md
PATCH_MANIFEST_v1.4.6.md
```

## Active v1.4.5-Scope Additions (accepted in v1.4.6)

```text
BOS_version_1.4/00_BOOTSTRAP/BOS_CORE_DIGEST.md
BOS_version_1.4/06_STANDARDS/BOS_INTERACTION_EDIT_SESSION_RULE.md
BOS_version_1.4/06_STANDARDS/BOS_WORKSPACE_FIRST_LAYOUT_RULE.md
PACKAGE_CHECKSUMS.txt
```

## Carried Forward

```text
BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md    (v1.4.4)
BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md             (v1.4.4)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md  (v1.4.3; No-Suffix rule added v1.4.6)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md          (v1.4.3)
```

## Pass Criteria

```text
1. Active registry paths exist.
2. Current version references point to v1.4.6 files.
3. Simple activation is unchanged.
4. User Content Survival remains active (Gate 7).
5. Package QA Gate, Release Naming Standard, Design Review Gate,
   Fast UI Polish Mode, Core Digest, and both universal design rules active.
6. Both MODULE_REGISTRY.md copies are byte-identical.
7. Every checksummed file exists and matches its SHA256.
8. No release-name suffixes in active package identity.
9. Clean ZIP extraction verification passes.
```
