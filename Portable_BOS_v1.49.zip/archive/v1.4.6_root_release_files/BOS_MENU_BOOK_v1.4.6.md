# BOS_MENU_BOOK_v1.4.6.md

## Portable BOS Menu Book

Version: 1.4.6 - Integrity, Checksums, Core Digest, Universal Design Rules (corrective release)

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.6 Contains

v1.4.6 is the accepted release of the v1.4.5 scope. The first v1.4.5 package failed on-machine verification (stale required-entry in the verify script) and was never accepted.

```text
1. BOS_CORE_DIGEST.md - one-page constraint summary loaded early at activation.
2. PACKAGE_CHECKSUMS.txt - per-file SHA256 verification; verifier checks file
   content, not only file existence.
3. Registry copy identity check - both MODULE_REGISTRY.md copies must be
   byte-identical.
4. Gate numbering fix - User Content Survival Gate is now Gate 7.
5. Version Header Rule - VERSION.txt is the single version source.
6. FAILURE_LIBRARY.md index, entry rules, F010 renumbering, and F011
   (Unchecked String Replacement and Emulated Verification Divergence).
7. Universal design standards promoted from HomeVisualizer:
   BOS_INTERACTION_EDIT_SESSION_RULE.md and BOS_WORKSPACE_FIRST_LAYOUT_RULE.md.
8. No-Suffix Corrective Release Rule in BOS_RELEASE_NAMING_STANDARD.md -
   corrective packages take the next PATCH version, never a name suffix.
```

## Menu A - Easy ZIP Activation

Barry uploads the BOS ZIP and says:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

AI should respond:

```text
BOS v1.4.6 activated.

I loaded the Core Digest, Module Registry, Core, Governance, User Content Survival,
Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard,
User-Facing Design Review Gate, Fast UI Polish Mode, Universal Design Rules,
Gateway Safety Notice, and Persona rules.

Do you already have an Incubator-generated idea / Project Seed, or should I run
Incubator v1.1 from your raw idea?
```

## Menu C - Upgrade Safety

Before any BOS upgrade release:

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Update PATCH_MANIFEST.
6. Regenerate PACKAGE_CHECKSUMS.txt.
7. Run package verification (files + registry + identity + checksums).
8. Extract ZIP into a clean temp folder.
9. Run verification again from the extracted ZIP.
10. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.46.zip
Internal version: 1.4.6
Details: BOS_UPGRADE_JOURNAL.md and PATCH_MANIFEST_v1.4.6.md
Corrective releases: next PATCH version, never a name suffix.
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
USER-FACING DESIGN REVIEW CHECK:
VERIFICATION:
PROMOTION CHECK:
```

## Menu F - Fast UI Polish Mode Quick Reference

```text
Use for: wording, labels, tooltips, grouping, spacing, non-logic display polish.
Do not use for: geometry, data-model, persistence, validation, transform, or any
behavioural/logic change.
Steps: backup -> patch UI files + targeted tests -> syntax check -> targeted UI
verification -> design review gate -> browser check -> checkpoint + next approval.
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
Verify content by checksum, not only file presence.
Corrective releases advance the version; they never add a name suffix.
```
