# BOS_INTEGRITY_MAP_v1.4.0.md

## Purpose

This map explains how Portable BOS v1.4.0 keeps logic integrity after upgrades.

## Integrity Chain

```text
00_FIRST_READ_ME.md
  ↓
BOS_ACTIVATION_MANIFEST.md
  ↓
MODULE_REGISTRY.md
  ↓
Active Modules
  ↓
BOS_UPGRADE_JOURNAL.md
  ↓
VERIFY_BOS_PACKAGE.ps1
  ↓
BOS_UPGRADE_MANAGER.ps1
  ↓
Verified ZIP + SHA256
```

## Active Incubator

```text
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

## Upgrade Rule

A filename change is a system-level patch.

It must update:

```text
1. MODULE_REGISTRY.md
2. BOS_ACTIVATION_MANIFEST.md
3. BOS_version_1.4/MANIFEST.md
4. BOS_UPGRADE_JOURNAL.md
5. VERIFY_BOS_PACKAGE.ps1
6. BUILD_BOS_ACTIVATION_ZIP.ps1
7. BOS_UPGRADE_MANAGER.ps1 if required
8. VERSION.txt
9. INTEGRITY_REPORT
```

## Simple Activation Protected

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```
