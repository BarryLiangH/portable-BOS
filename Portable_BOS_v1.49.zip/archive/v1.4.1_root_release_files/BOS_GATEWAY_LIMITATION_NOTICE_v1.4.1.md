# BOS_GATEWAY_LIMITATION_NOTICE_v1.4.1.md

## Purpose

This notice records the controlled safety correction added after the v1.4.0 integrity review.

Portable BOS remains safe to use as a **development protocol** through simple ZIP activation.

The Gateway installer is now treated as a **cautious helper**, not the main activation path.

## Simple Activation Remains Unchanged

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Recommended Use Mode

Use BOS in this order:

```text
1. Upload the ZIP.
2. Ask the AI to read 00_FIRST_READ_ME.md.
3. Load the manifest and MODULE_REGISTRY.md.
4. Use Core + Governance + Incubator + Memory + Upgrade System.
5. Do not run the Gateway installer unless a local folder installation is truly needed.
```

## Gateway Installer Safety Status

The Gateway installer may be used only with caution.

It must not overwrite existing project files silently.

If a project folder already contains important files such as:

```text
README.md
PROJECT_STATE.md
ROADMAP.md
WORKFLOW.md
HARNESS.md
CHECKPOINT.md
```

then the Gateway must:

```text
1. preserve the existing file;
2. create a conflict report;
3. create backups when needed;
4. default to SKIP instead of overwrite;
5. require Barry's explicit approval for replacement.
```

## Registry Path Rule

`MODULE_REGISTRY.md` inside the ZIP is package-root relative.

If BOS is installed to `C:\BOS\Core\...`, the installer must also create an installed registry or installed path report using absolute resolved paths.

Do not assume package-relative registry paths will work after installation.

## Maturity Clarification

Portable BOS v1.4.1 is:

```text
Level 3.5 — Structured Portable Protocol with Upgrade System and Gateway Safety Patch.
Level 4 Candidate — not yet fully autonomous production.
```

It is not yet a fully autonomous Level 4 software factory.

## Project Generator Clarification

The Project Generator is currently a documented generator procedure and template guide.

It is not yet a complete executable generator.

## Final Rule

Use the workflow now.

Treat installer automation as optional.

Keep the simple activation unchanged.
