# BOS_INTEGRITY_MAP_v1.4.1.md

## Purpose

This map explains how Portable BOS v1.4.1 keeps logic integrity after upgrades.

## Integrity Chain

```text
00_FIRST_READ_ME.md
  ↓
BOS_ACTIVATION_MANIFEST.md
  ↓
MODULE_REGISTRY.md
  ↓
Active Modules
  ↓
BOS_UPGRADE_JOURNAL.md
  ↓
VERIFY_BOS_PACKAGE.ps1
  ↓
Gateway Safety Gate
  ↓
BOS_UPGRADE_MANAGER.ps1
  ↓
Verified ZIP + SHA256
```

## Active Incubator

```text
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

## Upgrade Rule

A filename change is a system-level patch.

It must update:

```text
1. MODULE_REGISTRY.md
2. BOS_ACTIVATION_MANIFEST.md
3. BOS_version_1.4/MANIFEST.md
4. BOS_UPGRADE_JOURNAL.md
5. VERIFY_BOS_PACKAGE.ps1
6. BUILD_BOS_ACTIVATION_ZIP.ps1
7. BOS_UPGRADE_MANAGER.ps1 if required
8. VERSION.txt
9. INTEGRITY_REPORT
```

## Simple Activation Protected

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```


## Gateway Safety Patch

```text
1. Simple activation remains unchanged.
2. Gateway installer is optional.
3. Existing project files must be skipped by default.
4. Installed path reports must use absolute paths.
5. BOS maturity is Level 3.5 / Level 4 Candidate.
```
