# BOS_MENU_BOOK_v1.4.1.md

## Portable BOS Easy Activation Menu v1.4.1

### Menu A — Start BOS

Upload the ZIP and say:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

### Menu B — After BOS asks for idea

Paste either:

```text
1. Incubator-generated idea
2. Raw idea
3. Project continuation note
4. Failure case / improvement note
```

### Menu C — AI must return before coding

```text
Incubator Summary:
Governance Classification:
Project Seed:
Architecture Gate:
Fragile Shortcut Check:
Environment Reality Check:
Builder Safety Handoff:
v0.1 Scope:
Recommended Block 1:
Done When:
Verification Method:
Files Expected:
Approval Needed:
```

### Menu D — Approve Block 1

```text
Approved. Execute Block 1 only. Follow BOS Integrity Gates. Verify before reporting done.
```

### Menu E — Stop unsafe AI behavior

```text
Stop. Apply BOS Integrity Gates. Do not continue until you explain what was actually created, what was only proposed, and how verification will be proven.
```

### Menu F — Active Incubator

The active Incubator file is registered as:

```text
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

Archived Incubator files must not be loaded during activation.

### Menu G — BOS Upgrade Procedure

For BOS system upgrades, do not manually copy-paste scattered patches.

Use the upgrade procedure:

```text
1. Read BOS_UPGRADE_JOURNAL.md.
2. Read MODULE_REGISTRY.md.
3. Prepare or apply patch as a package-level change.
4. Update registry, manifest, scripts, journal, and integrity report together.
5. Run VERIFY_BOS_PACKAGE.ps1.
6. Run BOS_UPGRADE_MANAGER.ps1.
7. Build the release ZIP.
8. Generate SHA256.
9. Release only if verification passes.
```

### Menu H — Upgrade Command To AI

```text
Upgrade this BOS package using the Upgrade System.

Read BOS_UPGRADE_JOURNAL.md first.
Use MODULE_REGISTRY.md as the active module map.
Do not manually patch only one file.
Apply the patch completely, verify references, update journal, build a new ZIP, generate checksum, and report integrity result.
```

### Final Rule

Simple activation stays simple. Governance, Incubator v1.1, Memory, Upgrade System, and Integrity run inside the BOS after activation.


### Menu I — Gateway Safety Rule

Normal BOS activation does not require running the Gateway installer.

If the Gateway installer is used:

```text
1. Existing project files must not be overwritten silently.
2. README.md and PROJECT_STATE.md are skipped by default if they exist.
3. A conflict report must be created when existing files are detected.
4. Installed registry/path reports must use absolute paths.
```

### Menu J — Maturity Clarification

```text
Portable BOS v1.4.1 = Level 3.5 / Level 4 Candidate.
It is not yet a fully autonomous Level 4 software factory.
```
