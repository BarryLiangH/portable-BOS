# BOS_INTEGRITY_MAP_v1.4.2.md

## Version

Portable BOS v1.4.2 — User Content Survival Patch

## Simple Activation

Unchanged:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Active Protection Chain

```text
00_FIRST_READ_ME.md
  ↓
BOS_ACTIVATION_MANIFEST.md
  ↓
MODULE_REGISTRY.md
  ↓
10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
  ↓
02_ENGINEERING/SAFE_FILE_GENERATION_RULES.md
  ↓
12_UPGRADE_SYSTEM/PATCH_APPLICATION_RULES.md
  ↓
VERIFY_BOS_PACKAGE.ps1
```

## New Integrity Rule

```text
User content must survive rerun.
```

## Required Registered File

```text
BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
```

## Required Updated References

```text
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
BOS_version_1.4/MANIFEST.md
BOS_version_1.4/PROJECT_STATE.md
BOS_version_1.4/10_GOVERNANCE/BOS_INTEGRITY_GATES.md
BOS_version_1.4/10_GOVERNANCE/CORE_CHANGE_CONTROL.md
BOS_version_1.4/02_ENGINEERING/SAFE_FILE_GENERATION_RULES.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_APPLICATION_RULES.md
BOS_version_1.4/12_UPGRADE_SYSTEM/REFERENCE_INTEGRITY_CHECK.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
```

## Verification Requirement

A package is not v1.4.2 verified unless:

```text
1. all active registry paths exist;
2. simple activation is unchanged;
3. User Content Survival rule is loaded during activation;
4. upgrade journal contains v1.4.2;
5. Gateway/project generation defaults to SKIP existing user files;
6. a conflict/rerun report is required for reruns;
7. ZIP and SHA256 are produced.
```
