# BOS_MENU_BOOK_v1.4.2.md

## Portable BOS Menu Book

Version: 1.4.2 — User Content Survival Patch

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.2 Adds

v1.4.2 adds one major safety rule:

```text
User content must survive rerun.
```

This means activation, Gateway installer, project generation, and upgrade reruns must be non-destructive by default.

## Menu A — Easy ZIP Activation

Barry uploads the BOS ZIP and says:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

AI reads:

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
```

## Menu B — Required AI Activation Result

AI should respond:

```text
BOS v1.4.2 activated.

I loaded Core, Governance, User Content Survival, Incubator v1.1, Memory, Upgrade System, and Persona.

Do you already have an Incubator-generated idea / Project Seed, or should I run Incubator v1.1 from your raw idea?
```

## Menu C — Incubator Input

Barry provides:

```text
1. Raw idea, or
2. Incubator-generated idea, or
3. Project Seed, or
4. Existing project continuation note.
```

## Menu D — Project Seed

AI must create or review:

```text
Project name:
One-sentence purpose:
Target user:
Main problem:
Platform:
First useful version:
Architecture risk:
Definition of done for v0.1:
```

## Menu E — Gates Before Coding

Before coding, AI must pass:

```text
1. Architecture Gate
2. Environment Reality Gate
3. File Creation Gate
4. User Content Survival Gate
5. Block Approval Gate
6. Verification Gate
```

## Menu F — User Content Survival Gate

Before any rerun or file generation:

```text
1. Detect existing files.
2. Default to SKIP.
3. Backup before approved overwrite.
4. Produce a conflict/rerun report.
5. Never delete user content silently.
```

## Menu G — Block 1 Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
VERIFICATION:
PROMOTION CHECK:
```

## Menu H — Barry Approval Command

```text
Approved. Execute Block 1 under BOS v1.4.2 integrity rules.

Protect user content.
Default to SKIP existing files.
Backup before approved overwrite.
Verify before reporting done.
```

## Menu I — Completion Report

```text
BLOCK COMPLETED:
FILES TOUCHED:
USER CONTENT SURVIVAL RESULT:
DONE WHEN RESULT:
VERIFICATION RESULT:
ERRORS FOUND:
RULES TRIGGERED:
PROMOTION:
PROJECT_STATE UPDATE:
NEXT RECOMMENDED BLOCK:
```

## Final Rule

```text
Generated files are replaceable.
User-created content is protected.
BOS must know the difference.
```
