# BOS_GATEWAY_LIMITATION_NOTICE_v1.4.2.md

## Portable BOS v1.4.2 Gateway Safety Notice

Simple activation remains preferred:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What Changed In v1.4.2

v1.4.2 adds the **User Content Survival Patch**.

The Gateway installer and any project generator must be non-destructive by default.

## Main Rule

```text
User content must survive rerun.
```

## Gateway Status

The Gateway installer is still optional.

Do not run the Gateway installer on an important existing project unless you are prepared to review the conflict/rerun report.

## Required Behavior

If the Gateway installer or generator is rerun:

```text
1. Existing user files are skipped by default.
2. Existing user files are never overwritten silently.
3. Approved overwrites require timestamped backup.
4. A conflict/rerun report must be created.
5. Barry's project content must survive.
```

## Protected Examples

```text
README.md
PROJECT_STATE.md
project_journal.md
decision_log.md
architecture.md
data/
raw/
wiki/
uploaded files
manual edits
custom templates
scripts
```

## Final Rule

The BOS may regenerate package files in a controlled upgrade workspace.

The BOS must not silently destroy project/user content.
