# BOS_INTEGRITY_MAP_v1.4.3.md

## Purpose

Map the active Portable BOS v1.4.3 integrity structure.

## Active Identity

```text
External ZIP: Portable_BOS_v1.43.zip
Internal version: 1.4.3
Core folder: BOS_version_1.4
```

## Required Active Root Files

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
BOS_MENU_BOOK_v1.4.3.md
BOS_INTEGRITY_MAP_v1.4.3.md
INTEGRITY_REPORT_v1.4.3.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.3.md
PATCH_MANIFEST_v1.4.3.md
```

## Active Upgrade Additions

```text
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_MANIFEST_TEMPLATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_COMMAND.md
```

## Optional Incubator Domain Extension

```text
BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md
```

## Pass Criteria

```text
1. Active registry paths exist.
2. Current version references point to v1.4.3 files.
3. Simple activation is unchanged.
4. User Content Survival remains active.
5. Package QA Gate is active.
6. Release Naming Standard is active.
7. Clean ZIP extraction verification passes.
```
