# BOS_MENU_BOOK_v1.4.3.md

## Portable BOS Menu Book

Version: 1.4.3 - Package QA Gate + Release Naming Standard

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.3 Adds

```text
1. BOS Release Naming Standard.
2. Package QA Gate.
3. Patch Manifest requirement.
4. Clean-install simulation rule.
5. Test-version drift prevention rule.
6. Optional Incubator domain extension index.
```

## Menu A - Easy ZIP Activation

Barry uploads the BOS ZIP and says:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

AI should respond:

```text
BOS v1.4.3 activated.

I loaded Core, Governance, User Content Survival, Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard, and Persona.

Do you already have an Incubator-generated idea / Project Seed, or should I run Incubator v1.1 from your raw idea?
```

## Menu C - Upgrade Safety

Before any BOS upgrade release:

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Update PATCH_MANIFEST.
6. Run package verification.
7. Extract ZIP into a clean temp folder.
8. Run verification again from the extracted ZIP.
9. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.43.zip
Internal version: 1.4.3
Details: BOS_UPGRADE_JOURNAL.md and PATCH_MANIFEST_v1.4.3.md
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
VERIFICATION:
PROMOTION CHECK:
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
```
