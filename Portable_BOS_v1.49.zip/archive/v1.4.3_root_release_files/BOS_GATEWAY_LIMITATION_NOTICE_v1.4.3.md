# BOS_GATEWAY_LIMITATION_NOTICE_v1.4.3.md

## Portable BOS Gateway Notice

Version: 1.4.3

Simple ZIP activation remains the preferred path.

The Gateway installer is optional. If used, it must:

```text
1. protect user-created content;
2. skip existing project files by default;
3. create timestamped backups before approved overwrite;
4. produce conflict/rerun reports;
5. pass package QA and reference integrity checks.
```

## Package QA Addition

A Gateway or release package is not complete until clean-install simulation from the ZIP passes.
