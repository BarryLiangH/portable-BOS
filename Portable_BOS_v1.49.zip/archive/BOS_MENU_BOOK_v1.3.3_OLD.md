# BOS_MENU_BOOK_v1.4.0.md

## Portable BOS Easy Activation Menu

### Menu A — Start BOS

Upload the ZIP and say:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

### Menu B — After BOS asks for idea

Paste either:

```text
1. Incubator-generated idea
2. Raw idea
3. Project continuation note
4. Failure case / improvement note
```

### Menu C — AI must return before coding

```text
Incubator Summary:
Governance Classification:
Project Seed:
Architecture Gate:
Fragile Shortcut Check:
Environment Reality Check:
Builder Safety Handoff:
v0.1 Scope:
Recommended Block 1:
Done When:
Verification Method:
Files Expected:
Approval Needed:
```

### Menu D — Approve Block 1

```text
Approved. Execute Block 1 only. Follow BOS Integrity Gates. Verify before reporting done.
```

### Menu E — Stop unsafe AI behavior

```text
Stop. Apply BOS Integrity Gates. Do not continue until you explain what was actually created, what was only proposed, and how verification will be proven.
```

### Menu F — Active Incubator

The active Incubator file is:

```text
BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

Archived Incubator files must not be loaded during activation.

### Final Rule

Simple activation stays simple. Governance, Incubator v1.1, Memory, and Integrity run inside the BOS after activation.
