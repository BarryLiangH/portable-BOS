# BOS_INTEGRITY_MAP_v1.4.7.md

## Purpose

Map the active Portable BOS v1.4.7 integrity structure.

## Active Identity

```text
External ZIP: Portable_BOS_v1.47.zip
Internal version: 1.4.7
Core folder: BOS_version_1.4
```

## Required Active Root Files

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
PACKAGE_CHECKSUMS.txt
BOS_MENU_BOOK_v1.4.7.md
BOS_INTEGRITY_MAP_v1.4.7.md
INTEGRITY_REPORT_v1.4.7.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.7.md
PATCH_MANIFEST_v1.4.7.md
```

## v1.4.7 Additions

```text
Present-tense drift corrections in PROJECT_STATE.md, WORKFLOW.md,
ROLLBACK_POLICY.md; F012 in FAILURE_LIBRARY.md; drift guard in
VERIFY_BOS_PACKAGE.ps1.
```

## Pass Criteria

```text
1. Active registry paths exist.
2. Current version references point to v1.4.7 files.
3. Simple activation is unchanged.
4. All prior gates active (Gate 7, Package QA, Naming, Design Review,
   Fast UI Polish, Core Digest, universal design rules).
5. Both MODULE_REGISTRY.md copies are byte-identical.
6. Every checksummed file exists and matches its SHA256.
7. PROJECT_STATE.md Current Active Package matches registry PACKAGE_NAME
   and names no old VERIFIED zip.
8. Clean ZIP extraction verification passes.
```
