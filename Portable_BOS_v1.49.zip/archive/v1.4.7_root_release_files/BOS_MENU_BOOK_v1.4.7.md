# BOS_MENU_BOOK_v1.4.7.md

## Portable BOS Menu Book

Version: 1.4.7 - Present-Tense Drift Correction

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.7 Adds

```text
1. Present-tense drift fixed: PROJECT_STATE.md no longer claims v1.4.2 as the
   current active package; WORKFLOW.md Level 3.5 no longer embeds a version;
   ROLLBACK_POLICY.md points to the active patch manifest for the current
   rollback target.
2. Mechanical guard: VERIFY_BOS_PACKAGE.ps1 now checks that PROJECT_STATE.md's
   Current Active Package matches the registry PACKAGE_NAME and names no old
   VERIFIED zip.
3. F012 promoted: Present-Tense Drift in State Documents.
All v1.4.5/v1.4.6 capabilities are carried forward.
```

## Menu A - Easy ZIP Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

```text
BOS v1.4.7 activated.

I loaded the Core Digest, Module Registry, Core, Governance, User Content Survival,
Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard,
User-Facing Design Review Gate, Fast UI Polish Mode, Universal Design Rules,
Gateway Safety Notice, and Persona rules.

Do you already have an Incubator-generated idea / Project Seed, or should I run
Incubator v1.1 from your raw idea?
```

## Menu C - Upgrade Safety

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Grep active files for "Current", old ZIP names, and prior versions;
   update or re-label every present-tense hit (F012).
6. Update PATCH_MANIFEST.
7. Regenerate PACKAGE_CHECKSUMS.txt.
8. Run package verification (files + registry + identity + checksums + drift).
9. Extract ZIP into a clean temp folder; verify again from there.
10. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.47.zip
Internal version: 1.4.7
Corrective releases: next PATCH version, never a name suffix.
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
USER-FACING DESIGN REVIEW CHECK:
VERIFICATION:
PROMOTION CHECK:
```

## Menu F - Fast UI Polish Mode Quick Reference

```text
Use for: wording, labels, tooltips, grouping, spacing, non-logic display polish.
Do not use for: geometry, data-model, persistence, validation, transform, or any
behavioural/logic change.
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
Verify content by checksum. A "Current" claim lives in one place only.
```
