# INTEGRITY_REPORT_v1.4.7.md

## Portable BOS Integrity Report

Internal version: 1.4.7
External release: Portable_BOS_v1.47.zip

## Verification Summary

```text
PASS
```

## Verified Items

```text
1. ZIP opens correctly; no corrupted files.
2. Both MODULE_REGISTRY.md copies exist and are byte-identical.
3. All active registry paths exist.
4. BOS_UPGRADE_JOURNAL.md contains v1.4.7.
5. Simple activation command is unchanged.
6. PACKAGE_CHECKSUMS.txt: every listed file exists and matches its SHA256.
7. PROJECT_STATE.md Current Active Package matches registry PACKAGE_NAME
   (Portable_BOS_v1.47.zip) and names no old VERIFIED zip.
8. WORKFLOW.md Level 3.5 no longer embeds a version claim.
9. ROLLBACK_POLICY.md defers the current rollback target to the active
   patch manifest.
10. F012 present in FAILURE_LIBRARY.md with index entry.
11. PATCH_MANIFEST_v1.4.7.md exists.
12. v1.4.6 dated files archived and not active.
13. Clean ZIP extraction verification passed.
```

## Final Rule

```text
A "Current" claim lives in one place only, and the verifier checks it.
```
