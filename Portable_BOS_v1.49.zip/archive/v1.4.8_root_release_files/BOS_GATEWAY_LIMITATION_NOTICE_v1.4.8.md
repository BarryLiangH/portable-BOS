# BOS_GATEWAY_LIMITATION_NOTICE_v1.4.8.md

## Purpose

Carries forward the Gateway Safety Notice under Portable BOS v1.4.8.

## Notice

Normal activation does not require running any installer.

If the Gateway installer is used, it must not silently overwrite existing project files. Existing project files must be skipped by default and recorded in a conflict/rerun report unless Barry explicitly approves replacement.

This rule applies to all user-created content, not only `README.md` and `PROJECT_STATE.md`.

## v1.4.8 Change

No change to Gateway installer behaviour. v1.4.8 adds the Efficient Block Round Rules (02_ENGINEERING). This notice is re-issued under the new version number for registry consistency.

## Rollback

Barry-designated rollback target: `Portable_BOS_v1.44.zip`. Nearest machine-verified intermediate: `Portable_BOS_v1.46.zip`.
