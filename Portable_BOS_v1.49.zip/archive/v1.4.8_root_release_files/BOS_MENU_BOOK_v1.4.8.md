# BOS_MENU_BOOK_v1.4.8.md

## Portable BOS Menu Book

Version: 1.4.8 - Efficient Block Round Rules

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.8 Adds

```text
Efficient Block Round Rules (02_ENGINEERING/EFFICIENT_BLOCK_ROUND_RULES.md):
1. Pre-Delivery Execution Gate
2. Clean-Extract Package Test Gate (restated from v1.4.3)
3. DOM Smoke Gate for browser apps
4. Screenshot-First Layout Protocol
5. Two-Strike Diagnosis Rule
6. Debug Loop vs Release Loop Rule
7. Optional Local AI Coding Mode (with CLAUDE.md skeleton)
Purpose: Barry is a confirming tester, not the first tester, and one block
must not cost 4-5 download/install/debug cycles.
All v1.4.5/v1.4.6/v1.4.7 capabilities carried forward.
```

## Menu A - Easy ZIP Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

```text
BOS v1.4.8 activated.

I loaded the Core Digest, Module Registry, Core, Governance, User Content Survival,
Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard,
User-Facing Design Review Gate, Fast UI Polish Mode, Efficient Block Round Rules,
Universal Design Rules, Gateway Safety Notice, and Persona rules.

Do you already have an Incubator-generated idea / Project Seed, or should I run
Incubator v1.1 from your raw idea?
```

## Menu C - Upgrade Safety

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Grep active files for "Current", old ZIP names, and prior versions;
   update or re-label every present-tense hit (F012).
6. Update PATCH_MANIFEST.
7. Regenerate PACKAGE_CHECKSUMS.txt.
8. Run package verification (files + registry + identity + checksums + drift).
9. Extract ZIP into a clean temp folder; verify again from there.
10. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.48.zip
Internal version: 1.4.8
Corrective releases: next PATCH version, never a name suffix.
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
USER-FACING DESIGN REVIEW CHECK:
PRE-DELIVERY EXECUTION RESULT:
VERIFICATION:
PROMOTION CHECK:
```

## Menu F - Block Round Quick Reference

```text
Before delivery: run the real suite (paste real SUMMARY) + clean-extract test
+ DOM smoke for browser apps.
Layout blocks: screenshot before and after.
2 failed rounds on one symptom: deliver a diagnosis, not fix attempt #3.
Debug loop may run locally (Claude Code); release loop is always chat+ZIP.
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
Barry confirms tests; Barry does not discover failures.
```
