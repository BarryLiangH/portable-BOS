# BOS_MENU_BOOK_v1.4.4.md

## Portable BOS Menu Book

Version: 1.4.4 - User-Facing Design Review Gate + Fast UI Polish Mode

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.4 Adds

```text
1. User-Facing Design Review Gate (06_STANDARDS) - wording/label review before any UI-facing package.
2. Fast UI Polish Mode (02_ENGINEERING) - lightweight verification lane for wording/label/low-risk layout changes.
3. Both rules promoted from HomeVisualizer product backlog notes (docs/BOS_REVISION_BACKLOG.md).
```

## Menu A - Easy ZIP Activation

Barry uploads the BOS ZIP and says:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

AI should respond:

```text
BOS v1.4.4 activated.

I loaded Core, Governance, User Content Survival, Incubator v1.1, Memory, Upgrade System,
Package QA, Release Naming Standard, User-Facing Design Review Gate, Fast UI Polish Mode,
and Persona.

Do you already have an Incubator-generated idea / Project Seed, or should I run Incubator v1.1
from your raw idea?
```

## Menu C - Upgrade Safety

Before any BOS upgrade release:

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Update PATCH_MANIFEST.
6. Run package verification.
7. Extract ZIP into a clean temp folder.
8. Run verification again from the extracted ZIP.
9. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.44.zip
Internal version: 1.4.4
Details: BOS_UPGRADE_JOURNAL.md and PATCH_MANIFEST_v1.4.4.md
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
USER-FACING DESIGN REVIEW CHECK:
VERIFICATION:
PROMOTION CHECK:
```

## Menu F - Fast UI Polish Mode Quick Reference

```text
Use for: wording, labels, tooltips, grouping, spacing, non-logic display polish.
Do not use for: geometry, data-model, persistence, validation, transform, or any
behavioural/logic change.
Steps: backup -> patch UI files + targeted tests -> syntax check -> targeted UI
verification -> design review gate -> browser check -> checkpoint + next approval.
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
No user-facing wording ships without a design review pass.
```
