# BOS_INTEGRITY_MAP_v1.4.4.md

## Purpose

Map the active Portable BOS v1.4.4 integrity structure.

## Active Identity

```text
External ZIP: Portable_BOS_v1.44.zip
Internal version: 1.4.4
Core folder: BOS_version_1.4
```

## Required Active Root Files

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
BOS_MENU_BOOK_v1.4.4.md
BOS_INTEGRITY_MAP_v1.4.4.md
INTEGRITY_REPORT_v1.4.4.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.4.md
PATCH_MANIFEST_v1.4.4.md
```

## Active Upgrade Additions (carried forward from v1.4.3)

```text
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_MANIFEST_TEMPLATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_COMMAND.md
```

## Active v1.4.4 Additions

```text
BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md
BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md
```

## Optional Incubator Domain Extension

```text
BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md
```

## Pass Criteria

```text
1. Active registry paths exist.
2. Current version references point to v1.4.4 files.
3. Simple activation is unchanged.
4. User Content Survival remains active.
5. Package QA Gate is active.
6. Release Naming Standard is active.
7. User-Facing Design Review Gate is active.
8. Fast UI Polish Mode is active.
9. Clean ZIP extraction verification passes.
```
