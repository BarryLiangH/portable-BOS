# BOS_GATEWAY_LIMITATION_NOTICE_v1.4.4.md

## Purpose

Carries forward the Gateway Safety Notice under Portable BOS v1.4.4.

## Notice

Normal activation does not require running any installer.

If the Gateway installer is used, it must not silently overwrite existing project files. Existing project files must be skipped by default and recorded in a conflict/rerun report unless Barry explicitly approves replacement.

This rule applies to all user-created content, not only `README.md` and `PROJECT_STATE.md`.

## v1.4.4 Change

No change to Gateway installer behaviour in this release. v1.4.4 adds two standards/engineering rule files (User-Facing Design Review Gate, Fast UI Polish Mode) promoted from HomeVisualizer product development. This notice is re-issued under the new version number for registry consistency.

## Rollback

If Gateway behaviour needs to roll back, use `Portable_BOS_v1.43.zip` / internal v1.4.3.
