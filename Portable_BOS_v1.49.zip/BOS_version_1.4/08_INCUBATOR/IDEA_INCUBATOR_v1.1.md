# BOS Idea Incubator v1.1
## Builder-Safe Project Incubation Procedure

Version: 1.1  
File name: `IDEA_INCUBATOR_v1.1.md`  
Supersedes: `IDEA_INCUBATOR.md` v1.0  
Target Use: Portable BOS v1.4.0+ / New Project Creation / Safe Builder Handoff  
Purpose: Turn a raw idea into a BOS-ready and builder-safe project seed.

---

# 0. Why This File Exists

Many good ideas begin as a small concept seed.

Example:

```text
I want a furniture and decoration system that converts a 2D blueprint into a 3D interior view.
```

But a seed is not ready for system development.

A real BOS-ready idea needs:

```text
concept
+ user
+ problem
+ context
+ knowledge background
+ use cases
+ boundaries
+ first useful version
+ architecture gate
+ fragile shortcut check
+ environment reality check
+ builder safety handoff
+ Block 1 proposal
```

This file upgrades Incubator v1.0 by adding **Builder-Safe Handoff**.

The goal is:

```text
Concept Seed
  ↓
Expanded Knowledge
  ↓
Integrated Idea
  ↓
BOS Project Seed
  ↓
Architecture Gate
  ↓
Builder Safety Handoff
  ↓
Block 1 Proposal
  ↓
Wait for Barry Approval
  ↓
System Development
```

---

# 1. Role of the AI

When using this file, the AI acts as an **Idea Incubation Agent**.

The AI should help Barry:

1. Capture the raw idea.
2. Ask only necessary clarifying questions.
3. Expand the hidden knowledge behind the idea.
4. Identify the real user and real problem.
5. Convert the idea into a BOS-ready Project Seed.
6. Identify the required architecture foundation.
7. Detect fragile shortcuts before coding.
8. Check the execution environment before Builder handoff.
9. Prepare a safe Block 1 proposal.
10. Stop before coding.

The AI must not jump directly into implementation.

The AI must first make the idea clear enough and safe enough to develop.

---

# 2. Core Principle

A raw idea is usually incomplete.

The AI must look for the missing layers:

```text
What is the idea?
Why does it matter?
Who needs it?
What problem does it remove?
What knowledge is required?
What is the first useful version?
What must wait until later?
What architecture foundation is required?
What shortcut could destroy the project later?
What should BOS build first?
How will the Builder safely create and verify files?
```

Important rule:

```text
A successful Incubator idea is not permission to code.
```

---

# 3. Idea Maturity Levels

## Level 0 — Spark

The user only has a feeling or loose thought.

Example:

```text
Maybe AI can help me manage my learning.
```

AI task:

```text
Clarify the direction.
Do not build yet.
```

---

## Level 1 — Concept Seed

The user has a basic concept.

Example:

```text
I want an AI assistant that helps convert articles into BOS updates.
```

AI task:

```text
Expand the hidden knowledge and use case.
```

---

## Level 2 — Integrated Idea

The idea has:

```text
target user
problem
workflow
inputs
outputs
success criteria
first version
```

AI task:

```text
Convert into BOS Project Seed.
```

---

## Level 3 — Builder-Ready Project Seed

The idea has:

```text
Project Seed
Architecture Gate
v0.1 Scope
Forbidden Shortcuts
Environment Reality Check
Builder Safety Handoff
Block 1 Proposal
```

AI task:

```text
Ask Barry for approval before any coding.
```

---

# 4. The Idea Incubation Sequence

Use this exact sequence:

```text
1. Capture Concept Seed
2. Identify User and Problem
3. Expand Knowledge Background
4. Define Knowledge Gaps
5. Define Real-Life Use Cases
6. Define Inputs and Outputs
7. Define Boundaries
8. Define First Useful Version
9. Convert to BOS Project Seed
10. Run Architecture Gate
11. Detect Fragile Shortcuts
12. Run Environment Reality Check
12B. Run Daily-Use Controls Baseline Gate
13. Prepare Builder Safety Handoff
14. Propose Block 1
15. Stop and wait for Barry approval
```

---

# 5. Step 1 — Capture Concept Seed

Ask the user:

```text
What is the raw idea?
Say it in one paragraph, even if it is incomplete.
```

Then summarize:

```text
Your concept seed is:
<summary>
```

Do not judge too early.

---

# 6. Step 2 — Identify User and Problem

Ask:

```text
Who will use this?
What problem does it remove?
What repeated pain does it solve?
What is the current manual way to do this?
```

Output:

```text
Target user:
Main problem:
Current manual process:
Pain removed:
```

---

# 7. Step 3 — Expand Knowledge Background

Every idea needs hidden knowledge.

The AI should identify:

```text
Domain knowledge:
Technical knowledge:
User behavior knowledge:
Data or file knowledge:
Workflow knowledge:
Safety or risk knowledge:
Business or practical knowledge:
```

Example:

For a 2D-to-3D interior design system:

```text
Domain knowledge:
Interior design, floor plans, rooms, furniture placement

Technical knowledge:
Graph data model, 2D rendering, 3D rendering, geometry, JSON state

Workflow knowledge:
Blueprint → floor plan model → room detection → 3D view → furniture placement

Risk knowledge:
Do not use flat point arrays for room topology.
Do not start with 3D rendering before the floor plan model is verified.
```

---

# 8. Step 4 — Knowledge Gap Map

The AI should create a gap map:

```text
Known:
Unknown:
Need to research:
Need user decision:
Can assume for v0.1:
Must not assume:
```

This prevents premature coding.

---

# 9. Step 5 — Define Real-Life Use Cases

Create 3 use cases:

```text
Use Case 1 — Daily simple use
Use Case 2 — Edge case
Use Case 3 — Future advanced use
```

Each use case should include:

```text
Input:
Action:
Output:
Success:
```

---

# 10. Step 6 — Define Inputs and Outputs

The idea must become concrete.

## Inputs

```text
What does the user provide?
Text?
PDF?
ZIP?
Article link?
Voice note?
Folder?
Blueprint image?
Furniture photo?
Manual command?
```

## Outputs

```text
What should the system produce?
Markdown?
Project folder?
PowerShell script?
Report?
ZIP package?
Checklist?
AI prompt?
2D preview?
3D preview?
JSON project state?
```

Output format:

```text
Input types:
Output types:
Preferred output mode:
```

---

# 11. Step 7 — Define Boundaries

A good idea needs boundaries.

Ask:

```text
What should v0.1 do?
What should v0.1 not do?
What is too advanced for now?
What requires human approval?
What must be verified?
```

Output:

```text
In scope:
Out of scope:
Human approval required:
Verification required:
```

---

# 12. Step 8 — Define First Useful Version

The first version should be small but real.

Use this rule:

```text
v0.1 must be useful in one real situation.
```

Output:

```text
v0.1 goal:
v0.1 user action:
v0.1 system output:
v0.1 success criteria:
```

---

# 13. Step 9 — Convert to BOS Project Seed

After incubation, convert the idea into this format:

```text
PROJECT SEED

Project name:
One-sentence purpose:
Target user:
Main problem:
Current manual process:
Pain removed:
Platform:
Input types:
Output types:
First useful version:
Existing BOS overlap:
Required knowledge:
Known gaps:
Out of scope:
Definition of done for v0.1:
First real-life use case:
What problem this removes from Barry's life:
```

---

# 14. Step 10 — Architecture Gate

The Incubator must identify the architecture foundation before Builder handoff.

Output:

```text
ARCHITECTURE GATE

Core data model:
Why this model:
Rejected model / shortcut:
Future features this model must support:
Architecture risks:
Gate result:
```

For any project involving geometry, rooms, relationships, workflow, state transitions, permissions, or multi-step editing, the AI must define the core state model before UI or rendering.

Example rule:

```text
Foundation before interface.
State model before rendering.
Room logic before furniture.
Furniture before decoration intelligence.
```

---

# 15. Step 11 — Fragile Shortcut Detection

The Incubator must identify shortcuts that may look fast but will destroy the project later.

Output:

```text
FRAGILE SHORTCUT CHECK

Shortcut 1:
Why it is tempting:
Why it is dangerous:
Correct approach:

Shortcut 2:
Why it is tempting:
Why it is dangerous:
Correct approach:
```

Example:

```text
Shortcut:
Use a flat array of wall points.

Why tempting:
Easy to draw lines quickly on canvas.

Why dangerous:
Cannot safely support rooms, inner walls, undo/redo, or 3D extrusion.

Correct approach:
Use a graph model with nodes, edges, faces, openings, and furniture.
```

---

# 16. Step 12 — Environment Reality Check

Before Builder handoff, the AI must state the execution reality.

First read `03_INTELLIGENCE/DELIVERY_PROFILE.md` and state its standing
defaults (paths, delivery method, install batch style) as assumptions.
Ask only where this project genuinely differs from the profile.

Output:

```text
ENVIRONMENT REALITY CHECK

Can the AI create files directly in this environment?
If yes, how will files be delivered?
If no, what must Barry run?
Recommended file creation method:
Project root path:
Required tools:
Verification method:
```

Important rule:

```text
BOS must never confuse generated text with executed work.
```

The AI must not claim:

```text
file created
test passed
app running
verified
```

unless there is proof.

Valid proof includes:

```text
downloadable file
visible generated file package
terminal output pasted by Barry
directory listing
file content check
checksum
verification report
```

---

# 16B. Step 12B — Daily-Use Controls Baseline Gate

Before Builder handoff, run the checklist in
`06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md`.

Every item must be answered:

```text
INCLUDED / DEFERRED to vX / N/A (reason)
```

Purpose of this gate:

```text
Everyday usability basics (font size, folder pickers, undo/redo,
empty-area-free layout, progress feedback, remembered settings) are
planned by the AI before the first build. Barry must never discover a
missing basic control through manual testing rounds.
```

If the project is visual/geometric, also load the CAD extension.
If the project processes business documents, also load the office
document extension. See `DOMAIN_EXTENSION_INDEX.md`.

A plan with unanswered baseline items is not builder-ready.

---

# 17. Step 13 — Builder Safety Handoff

The Incubator must prepare the Builder to execute safely.

Output:

```text
BUILDER SAFETY HANDOFF

Project:
Accepted architecture:
Forbidden shortcuts:
Environment method:
File generation method:
Verification method:
Block 1:
Do not start:
Human approval required:
```

Required rule:

```text
The Incubator does not hand over only an idea.
The Incubator hands over a controlled build-start package.
```

---

# 18. Step 14 — BOS-Ready Block 1 Requirement

Block 1 must be small, useful, and verifiable.

AI must propose:

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
VERIFICATION:
PROMOTION CHECK:
```

Block 1 should not be a huge full system.

Good Block 1 examples:

```text
Create project skeleton and README.
Create input/output specification.
Create core data model.
Create first parser.
Create first validation script.
Create first safe generator script.
```

Bad Block 1 examples:

```text
Build complete app.
Add UI, database, 3D, AI, and automation at once.
Integrate all AI providers.
Create full production deployment.
```

---

# 19. Step 15 — Stop and Wait

The Incubator must stop after proposing Block 1.

Required instruction:

```text
Do not write code until Barry approves Block 1.
```

Barry approval phrase:

```text
Approved. Execute Block 1 under BOS integrity rules.
```

---

# 20. Idea Quality Checklist

Before sending to BOS, verify:

```text
Does the idea have a real user?
Does it remove a repeated pain?
Is the first version small?
Are inputs and outputs clear?
Are unknowns listed?
Are boundaries clear?
Is there a verification method?
Can Block 1 be completed independently?
Has Architecture Gate passed?
Have fragile shortcuts been rejected?
Has Environment Reality Check been completed?
Has the Daily-Use Controls Baseline been answered item by item?
Has the right domain extension been loaded (CAD / office documents)?
Has Builder Safety Handoff been prepared?
```

If any answer is no, return to incubation.

---

# 21. Promotion Rule

If an idea-incubation session reveals a reusable lesson, promote it into BOS.

Classification:

```text
Failure → FAILURE_LIBRARY.md
Success → SUCCESS_LIBRARY.md
Workflow → WORKFLOW.md
Harness → HARNESS.md
Project Starter → NEW_PROJECT_STARTER.md
Block Rule → BLOCK_ENGINE.md
Portable BOS → PORTABLE_BOS_LIMITS_AND_GUARDRAILS.md
Idea Creation → IDEA_INCUBATOR_v1.1.md
Governance → BOS_GROWTH_GOVERNANCE.md
Memory → MEMORY_LAYER_PROCEDURE.md
```

---

# 22. Standard User Command

Barry can use this command:

```text
Use IDEA_INCUBATOR_v1.1.md.

Help me expand this concept seed into a BOS-ready and Builder-safe project idea.

Do not write code yet.

First:
identify the user, problem, hidden knowledge, knowledge gaps, use cases, inputs, outputs, boundaries, and v0.1.

Then:
convert it into a BOS Project Seed.

Then:
run Architecture Gate, Fragile Shortcut Check, Environment Reality Check, and Builder Safety Handoff.

Finally:
propose Block 1 but wait for my approval.
```

---

# 23. Short Command

```text
Incubate this idea for BOS v1.1. Expand it into a Project Seed, run Architecture Gate and Builder Safety Handoff, then propose Block 1 only.
```

---

# 24. Final Rule

Do not let a seed jump directly into coding.

A seed must first become an integrated idea.

An integrated idea must pass Architecture Gate.

A gated idea must pass Builder Safety Handoff.

Only then may it enter BOS development.

```text
Seed first.
Knowledge second.
Integration third.
Architecture fourth.
Builder safety fifth.
BOS development sixth.
```
