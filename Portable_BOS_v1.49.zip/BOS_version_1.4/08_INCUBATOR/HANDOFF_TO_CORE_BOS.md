# HANDOFF_TO_CORE_BOS.md

# Incubator To Core BOS Handoff

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file defines the handoff from Incubator Branch to Core BOS execution.

## Handoff Format

```text
# BOS Incubator Handoff

Project name:
Purpose:
Target user:
Problem:
Smallest useful version:
Suggested first block:
Done condition:
Verification method:
Risks:
Files likely needed:
Memory entries to create:
Governance status:
```

## Rule

After handoff, Core BOS must load:

- OWNER.md
- NEW_PROJECT_STARTER.md
- BLOCK_ENGINE.md
- FAILURE_LIBRARY.md
- HARNESS.md
- WORKFLOW.md
- PROMOTION_ENGINE.md
- BOS_GROWTH_GOVERNANCE.md

Then propose Block 1.

Do not start coding until Barry approves.
