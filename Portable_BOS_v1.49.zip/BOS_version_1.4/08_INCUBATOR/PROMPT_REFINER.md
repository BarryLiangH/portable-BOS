# PROMPT_REFINER.md

# Incubator Prompt Refiner

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Prompt Refiner converts unclear human intention into a cleaner instruction before incubation.

## Input

Barry may provide:

- a rough idea
- copied article
- video summary
- tool claim
- emotional statement
- project wish
- incomplete brainstorm

## Output

The AI should rewrite the input into:

```text
Clear request:
Hidden goal:
Missing information:
Likely project category:
Suggested next question:
```

## Rule

Prompt Refiner improves the request.

It must not decide the whole project alone.
