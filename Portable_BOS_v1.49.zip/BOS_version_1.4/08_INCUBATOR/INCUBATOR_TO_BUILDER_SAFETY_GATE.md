# INCUBATOR_TO_BUILDER_SAFETY_GATE.md

## Purpose

This file prevents a good Incubator output from being rushed into unsafe coding.

## Rule

The Incubator may create:

```text
ideas
requirements
problem statements
MVP concepts
architecture candidates
project seeds
```

But the Builder may not code until the idea passes the BOS Integrity Gates.

## Required Handoff

Every Incubator-to-Builder handoff must include:

```text
1. Project Seed
2. Core user problem
3. MVP scope
4. Architecture candidate
5. Data model candidate
6. Known risks
7. Block 1 proposal
8. Verification method
```

## Block 1 Preference

Block 1 should build the smallest stable foundation, not the prettiest UI.

For complex projects, foundation comes first:

```text
state model before UI
file generation before feature claims
verification before completion reports
```

## Stop Rule

If the architecture is unclear, stop and ask for Architecture Gate review.
