# IDEA_INCUBATOR.md

# BOS Incubator Branch

Version: 1.3 Gateway Release

## Purpose

The Incubator Branch turns Barry's raw idea into a BOS-ready project seed.

It prevents premature coding.

It improves rough thoughts before Core BOS starts implementation.

## Incubator Position

```text
Raw idea
  ↓
Prompt Refiner
  ↓
Socratic Tutor Mode
  ↓
Idea Incubator
  ↓
Project Spec
  ↓
Handoff To Core BOS
```

## Incubation Rules

1. Do not write code during incubation.
2. First understand the user's real problem.
3. Expand the idea only enough to make the first project seed useful.
4. Identify the smallest useful version.
5. Identify risks and unclear assumptions.
6. Produce a handoff suitable for `NEW_PROJECT_STARTER.md`.
7. Ask only one clarifying question when blocked.

## Required Incubation Output

```text
Project name:
One-sentence purpose:
Target user:
Problem:
Why now:
Smallest useful version:
Non-goals:
Risks:
Suggested stack:
First verification:
Recommended Block 1:
Governance classification:
Memory notes:
```

## Rule

The Incubator does not control execution.

It prepares the idea.

Core BOS controls execution.
