# OFFICE_DOCUMENT_PROCESSING_EXTENSION.md

## Purpose

Optional Incubator checklist for office document processing, business
document analysis, contract review, correspondence handling, report
generation, or any system whose primary material is business documents.

Do not load this extension unless the project processes, analyzes, or
generates business documents.

Reference products: DocAgent, planned IntelliDoc Advisor.

## Analysis Depth Requirement

A document system must not stop at summarizing. Before coding, the plan
must define which of these analysis layers v0.1 delivers:

```text
1. Extraction   - parties, dates, amounts, obligations, deadlines.
2. Structure    - document type detection, section mapping.
3. Risk         - litigation-relevant clauses, liabilities, penalties,
                  jurisdiction, governing law, termination traps.
4. Financial    - payment terms, currencies, totals cross-check,
                  interest/penalty math, credit terms.
5. Execution    - what must be done, by whom, by when; a concrete
                  action/procedure list, not only a description.
```

## Advisory Output Rules

```text
1. Risk and financial findings are advisories with reasons, not silent
   auto-corrections. The system flags; Barry decides.
2. Every advisory states: finding, why it matters, suggested action,
   confidence level.
3. Litigation-sensitive wording is quoted exactly from the source
   document, with its location, so the human can verify.
4. Financial figures are recomputed where possible and mismatches are
   flagged with both values shown.
5. The system must state clearly that advisories are analysis support,
   not legal or financial advice.
```

## Bilingual and Mixed-Language Questions

For Barry's environment, mixed Chinese-English content is normal, not an
edge case. Before coding, define:

```text
1. Input languages accepted (English, Simplified Chinese, mixed).
2. Output language rule: follow source, follow user setting, or both.
3. Terminology consistency: key business terms translated the same way
   throughout one document set.
4. Encoding safety on Windows (UTF-8 end to end; see FAILURE_LIBRARY
   F003).
```

## Independent Control Models

Separate:

```text
1. source document model (immutable original);
2. extraction/analysis model (derived data with source locations);
3. advisory model (findings, severity, status: open/accepted/dismissed);
4. output/report model;
5. provider model (which AI/provider produced which result).
```

## Forbidden Couplings

```text
The original document must never be modified in place.
Analysis results must never overwrite source text.
An advisory dismissal must not delete the finding, only mark it.
Provider switching must not silently change prior results.
Generated output must be traceable to the source passages used.
```

## Daily Operation Questions

Before coding, define:

```text
1. Batch handling: one document at a time, a folder, or both?
2. Where do results land (default output folder, naming pattern)?
3. What happens on a partially failed batch?
4. How does the user re-run one document without redoing the batch?
5. What is kept between sessions (history, settings, recent folders)?
```

## Acceptance Tests Before Coding

```text
1. Feed a mixed Chinese-English document -> extraction preserves both
   languages without corruption.
2. Introduce a deliberate arithmetic error in a document -> financial
   layer flags the mismatch with both values.
3. Dismiss an advisory -> finding remains recorded as dismissed.
4. Re-run a single document from a batch -> other results untouched.
5. Every advisory in the report links back to a source location.
```

## Relationship To Core Rules

```text
DAILY_USE_CONTROLS_BASELINE.md      - still mandatory (folder pickers,
                                      undo/redo, font size, progress).
USER_FACING_DESIGN_REVIEW_GATE.md   - report wording in user language.
SAFE_FILE_GENERATION_RULES.md       - output writing safety.
```
