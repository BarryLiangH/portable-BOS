# CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md

## Purpose

Optional Incubator checklist for CAD, geometry, map, room layout, floor plan, interior design, physical layout, or measurement-based projects.

Do not load this extension unless the project involves physical space, geometry, measurement, layout, or drawing.

## Measurement Model Questions

Before coding, define:

```text
1. Real-world unit: mm, cm, meter, inch, or abstract unit?
2. Measurement source: user input, 2D drawing mark, image calibration, imported CAD, or manual scale?
3. Model unit to real unit conversion.
4. Display unit for user review.
```

## Independent Control Models

Separate:

```text
1. physical geometry model;
2. object/layout model;
3. measurement scale model;
4. viewport/camera model;
5. renderer model;
6. interaction model.
```

## Forbidden Couplings

```text
Viewer zoom must not change physical dimensions.
Furniture/object resize must not change room/space geometry.
Room/space resizing must not change object size unless an explicit layout rule says so.
Renderer bounds must not be recalculated from unrelated overlay objects.
Pixels must not become real-world measurement unless calibrated.
```

## Acceptance Tests Before Coding

```text
1. Change object size -> room/space dimensions unchanged.
2. Zoom view -> physical dimensions unchanged.
3. Change room/space size -> object dimensions unchanged unless explicitly reflowed.
4. Measurement labels reflect real model data, not screen pixels.
```
