# DOMAIN_EXTENSION_INDEX.md

## Purpose

Keep the Incubator general-purpose while allowing optional domain-specific checklists.

The core Incubator must not become a room-design-only system.

## Core Rule

The core Incubator asks general questions:

```text
1. What are the independent control models?
2. Which state is real data?
3. Which state is display-only?
4. Which state is user interaction state?
5. Which things must never affect each other?
```

## Optional Domain Extensions

Domain extensions may be loaded only when relevant.

Examples:

```text
CAD / geometry / physical layout
AI memory system
Data pipeline
Mobile app
Financial model
Business document assistant
```

## Available Extensions

```text
08_INCUBATOR/domain_extensions/CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md
08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md
```

## Loading Rule

```text
CAD extension: load for physical space, geometry, measurement, layout,
drawing, 2D/3D conversion projects.
Office document extension: load for business document processing,
analysis, contract review, report generation projects.
The Daily-Use Controls Baseline (06_STANDARDS) is not an extension; it
is mandatory for every project regardless of domain.
```

## Final Rule

General core. Optional domain extensions.
