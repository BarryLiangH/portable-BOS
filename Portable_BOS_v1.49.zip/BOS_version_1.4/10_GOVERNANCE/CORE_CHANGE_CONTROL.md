# CORE_CHANGE_CONTROL.md

# Core BOS Change Control

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Protect Core BOS from uncontrolled changes.

## Core Files

Core files include:

- OWNER.md
- VISION.md
- PROJECT_STATE.md
- 00_BOOTSTRAP/BLOCK_ENGINE.md
- 00_BOOTSTRAP/NEW_PROJECT_STARTER.md
- 01_EXPERIENCE/FAILURE_LIBRARY.md
- 01_EXPERIENCE/SUCCESS_LIBRARY.md
- 01_EXPERIENCE/PROMOTION_ENGINE.md
- 02_ENGINEERING/HARNESS.md
- 02_ENGINEERING/WORKFLOW.md
- 02_ENGINEERING/LOOP.md
- 04_FACTORY/PROJECT_GENERATOR.md
- 06_STANDARDS/MARKDOWN_STANDARD.md

## Change Requirements

Before changing Core BOS:

1. State the reason.
2. Identify affected files.
3. Check for duplicate rule.
4. Classify maturity level.
5. Get Barry approval.
6. Backup old file.
7. Apply change.
8. Verify manifest.
9. Update PROJECT_STATE.md.
10. Update decision log or governance report.

## Rule

No silent Core BOS mutation.

---
## User Content Survival Extension v1.4.2

Core change control also protects user-created project content.

Before any gateway, installer, generator, or upgrade script writes into a project folder, it must follow:

```text
1. Detect existing files.
2. Default to SKIP.
3. Backup before approved overwrite.
4. Produce a rerun/conflict report.
5. Never delete user content silently.
```

The active rule file is:

```text
10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
```
