# BRANCH_APPROVAL_RULES.md

# BOS Branch Approval Rules

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Control when an idea becomes a branch or branch module.

## Approved Branches In v1.3

- Core BOS
- Incubator
- Memory
- Governance

## Future Branch Placeholders

- Intelligence
- Automation

## Approval Test

A branch or module is justified only if it:

1. Changes future AI behavior.
2. Solves a repeated problem.
3. Has a clear owner file.
4. Does not duplicate an existing branch.
5. Can be tested in a real project.
6. Does not make activation too heavy.

## Rule

Do not add branches because an idea is exciting.

Add branches only when the function is repeatedly useful.
