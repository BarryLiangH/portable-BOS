# BOS_GROWTH_GOVERNANCE.md

# BOS Growth Governance

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Governance prevents uncontrolled BOS growth.

A living BOS needs an immune system.

This file is that immune system.

## Core Principle

```text
The BOS must grow, but it must not mutate uncontrolled.
```

## Growth Path

Every new idea must pass through maturity levels:

```text
Level 0 — Raw Idea
Level 1 — Incubated
Level 2 — Branch Candidate
Level 3 — Pilot Rule
Level 4 — Stable Rule
Level 5 — Core BOS Principle
```

## Protected Core Rule

Core BOS is protected.

New ideas do not enter Core BOS directly.

They must first be classified, tested, verified, and approved.

## Where New Ideas Go

```text
Prompt technique
  → Incubator Branch

Knowledge / memory structure
  → Memory Branch

Rule about controlling BOS changes
  → Governance Branch

Reusable project execution method
  → Core candidate after pilot

Automation script idea
  → Future Automation placeholder
```

## Barry Approval Required

Barry approval is required before:

- changing Core BOS rules
- changing activation load order
- adding a new top-level branch
- deleting or deprecating existing BOS files
- promoting a pilot rule into Stable Core
- adding safety-related changes

## Governance Review Output

```text
New idea:
Source:
Branch fit:
Maturity level:
Risk:
Duplicate existing idea:
Recommended action:
Approval required:
```

## Final Rule

Growth without governance becomes clutter.

Governance without growth becomes dead procedure.

Portable BOS needs both.
