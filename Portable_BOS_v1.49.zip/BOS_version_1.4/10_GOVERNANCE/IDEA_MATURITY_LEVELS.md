# IDEA_MATURITY_LEVELS.md

# BOS Idea Maturity Levels

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Level 0 — Raw Idea

Interesting but not analyzed.

Action:

Store in incubator backlog or memory raw layer.

## Level 1 — Incubated

Expanded enough to understand.

Action:

Create an incubator handoff.

## Level 2 — Branch Candidate

Useful enough to test inside a branch.

Action:

Place inside Incubator, Memory, Governance, or future branch.

## Level 3 — Pilot Rule

Used in one real project.

Action:

Track result and verification.

## Level 4 — Stable Rule

Worked across more than one case.

Action:

Can be added to stable branch rules.

## Level 5 — Core BOS Principle

Permanent operating principle.

Action:

Requires Barry approval and decision_log update.
