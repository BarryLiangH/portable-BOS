# BOS_FAILURE_CASE_001_DEEPSEEK_HOMEVISUALIZER.md

## Case Name

DeepSeek HomeVisualizer Post-Mortem

## Summary

DeepSeek successfully helped create the Incubator idea for HomeVisualizer, a multi-room 2D/3D floor plan layout tool, but the implementation phase collapsed because the agent skipped architecture validation, hallucinated local file creation, and generated unsafe PowerShell file-writing scripts.

## What Worked

```text
Incubator idea generation worked.
The target product concept was useful.
The need for multi-room 2D/3D floor planning was valid.
```

## What Failed

```text
1. Ghost Folder Illusion
2. Ghost File Verification
3. Unsafe PowerShell generation
4. Coding before architecture
5. Wrong floor plan data model
6. No environment reality check
7. No real verification before reporting progress
```

## Root Cause

The builder confused generated text with executed work and started coding before passing architecture and environment gates.

## Architecture Failure

The failed version represented walls as a sequential click-point array.

That model cannot safely support:

```text
Undo / redo
Inner partition walls
Room splitting
Closed room detection
3D floor extrusion
Furniture attached to rooms
```

## Correct Architectural Target

HomeVisualizer must use a graph-based floor plan model:

```javascript
const floorPlan = {
    nodes: [],     // wall intersections and corners
    edges: [],     // wall segments with fromNodeId and toNodeId
    faces: [],     // closed room loops
    furniture: []  // furniture attached to room faces
};
```

## New Permanent Rule Candidate

A successful Incubator idea is not permission to code.

Every incubated idea must pass:

```text
1. Architecture Gate
2. Environment Reality Gate
3. File Creation Gate
4. Block Approval Gate
5. Verification Gate
```

## Key Lesson

BOS must never confuse generated text with executed work.

## HomeVisualizer Recovery Route

Correct Block order:

```text
1. Graph-based state engine
2. Outer wall creation
3. Closed-loop face detection
4. Inner partition split
5. Undo/redo as graph operations
6. Room labels
7. Furniture attached to faces
8. 3D extrusion from faces
```

## BOS Promotion Target

```text
Governance: BOS_INTEGRITY_GATES.md
Incubator: INCUBATOR_TO_BUILDER_SAFETY_GATE.md
Engineering: SAFE_FILE_GENERATION_RULES.md
Experience: FAILURE_LIBRARY.md
```
