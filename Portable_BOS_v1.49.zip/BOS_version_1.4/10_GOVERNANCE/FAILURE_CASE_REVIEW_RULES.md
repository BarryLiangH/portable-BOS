# FAILURE_CASE_REVIEW_RULES.md

## Purpose

This file defines how BOS learns from failed AI development attempts without letting failure noise corrupt Core BOS.

## Failure Case Intake

Every serious failure should be recorded as:

```text
Failure Case ID:
Project:
Agent / Tool:
Phase failed:
What worked:
What failed:
Root cause:
BOS rules violated:
New rule candidate:
Promotion target:
Status:
```

## Classification

Classify failures into one or more types:

```text
1. Incubator failure
2. Architecture failure
3. Environment hallucination
4. File creation failure
5. Verification failure
6. PowerShell/script safety failure
7. State model failure
8. Governance failure
```

## Promotion Rule

A failure case does not automatically become a Core BOS rule.

It must pass Governance first:

```text
Failure observation
→ Rule candidate
→ Pilot rule
→ Verified useful
→ Stable BOS rule
```

## Minimum Output After Review

After reviewing a failure case, AI must produce:

```text
Failure summary:
Root cause:
BOS rule violated:
New rule candidate:
Where to store it:
Whether Core BOS must change now:
```
