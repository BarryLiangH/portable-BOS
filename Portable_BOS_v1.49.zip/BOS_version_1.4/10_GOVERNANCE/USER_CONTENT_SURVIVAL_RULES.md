# USER_CONTENT_SURVIVAL_RULES.md

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file protects Barry's/user-created content when Portable BOS activation, gateway installation, project generation, upgrade scripts, or reruns are used more than once.

The v1.4.2 principle is:

```text
User content must survive rerun.
```

## Core Rule

BOS rerun must be **non-destructive by default**.

The BOS must never silently overwrite, delete, replace, truncate, or regenerate over user-created content.

## Protected User Content

Protected content includes, but is not limited to:

```text
README.md
PROJECT_STATE.md
project_journal.md
decision_log.md
architecture.md
user notes
raw ideas
Incubator handoff files
source materials
uploaded blueprints
photos
drawings
manual edits
generated project files
custom templates
logs
verification reports
data files
scripts edited by Barry
```

## Default Behavior

When a file or folder already exists, the default action is:

```text
SKIP
```

The BOS may create missing folders, but must not replace existing files without approval.

## Allowed Actions

For existing user files, the BOS may do only one of these:

```text
1. SKIP existing file.
2. BACKUP then overwrite, only with explicit Barry approval.
3. PROPOSE merge, but do not perform merge until Barry approves.
4. WRITE a new version beside the old file using a timestamp or version suffix.
```

## Backup Rule

Before any approved overwrite, create a timestamped backup.

Example:

```text
README.md.backup_YYYYMMDD_HHMMSS
```

## Force Overwrite Rule

Force overwrite must require an explicit user command.

Valid examples:

```text
Barry explicitly approves overwrite.
Barry runs script with a Force option after reading the conflict report.
```

Invalid examples:

```text
Assuming overwrite is allowed because the script was rerun.
Assuming overwrite is allowed because the project name is the same.
Assuming overwrite is allowed because the file looks old.
```

## Rerun Report Requirement

Every activation, gateway, project-generation, or upgrade rerun that touches project folders must produce a rerun report.

The report must list:

```text
1. Newly created files
2. Existing files skipped
3. Files backed up
4. Files overwritten with approval
5. Files proposed for merge
6. Any folders created
7. Any errors
8. Exact next recommended action
```

## Project Generator Rule

The Project Generator must be treated as a **procedure and template system** unless it actually creates files and verifies them.

If it generates a project structure, it must obey User Content Survival rules.

## Upgrade Rule

A BOS upgrade must protect:

```text
1. Active BOS files
2. User-created project files
3. Archive files
4. Custom branch files
5. Manually edited templates
```

An upgrade may modify BOS package files only inside the controlled upgrade workspace. It must not touch external user project folders unless explicitly requested.

## No Silent Delete Rule

BOS must not silently delete:

```text
project folders
archive folders
raw/ folders
wiki/ folders
data/ folders
user-uploaded source folders
```

If cleanup is needed, BOS must create a cleanup proposal first.

## Activation Rule

Simple activation remains unchanged:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

This file is loaded by the Activation Manifest so the user does not need to remember this rule manually.

## Final Rule

```text
Generated files are replaceable.
User-created content is protected.
BOS must know the difference.
```
