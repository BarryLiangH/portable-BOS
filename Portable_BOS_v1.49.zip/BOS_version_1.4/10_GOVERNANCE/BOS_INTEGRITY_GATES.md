# BOS_INTEGRITY_GATES.md

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file protects Portable BOS from the HomeVisualizer / DeepSeek failure pattern: good incubation followed by unsafe execution.

## Core Rule

A successful Incubator idea is not permission to code.

Every implementation must pass these gates first.

---

## Gate 1 — Architecture Gate

Before coding, the AI must state the core architecture and data model.

Required checks:

```text
1. What is the core data model?
2. What features must this data model support later?
3. Which shortcut would break future features?
4. Is the model suitable for undo/redo, state changes, relationships, and verification?
5. What is the smallest stable foundation for Block 1?
```

If the project involves geometry, state, relationships, workflow, rooms, graphs, permissions, multi-step editing, or 3D rendering, the data model must be approved before UI code.

---

## Gate 2 — Environment Reality Gate

Before creating files or commands, the AI must state reality:

```text
1. Can the AI directly create files in this environment?
2. If not, will Barry run a script?
3. What operating system is assumed?
4. What is the project root path?
5. How will file creation be verified?
```

The AI must not claim local file creation unless it has actually created a downloadable file or Barry confirms terminal output.

---

## Gate 3 — File Creation Gate

For multi-file work, the AI must provide one safe method:

```text
1. downloadable ZIP package; or
2. safe PowerShell generator script; or
3. COPY-RUN command with backup and verification.
```

Every file must have:

```text
File path:
Purpose:
Creation method:
Verification method:
```

---

## Gate 4 — Block Approval Gate

The AI must propose Block 1 before coding.

Required format:

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
VERIFICATION:
PROMOTION CHECK:
```

No implementation begins until Barry approves.

---

## Gate 5 — Verification Gate

The AI must not report “done” without proof.

Valid proof includes:

```text
1. actual tool-created file;
2. downloadable ZIP;
3. terminal output pasted by Barry;
4. directory listing;
5. test output;
6. checksum;
7. user confirmation.
```

---

## Final Integrity Rule

BOS must never confuse generated text with executed work.


---

## Gate 6 — Gateway Safety Gate

If a local gateway installer or project scaffold script is used, the AI or script must verify:

```text
1. Is this a new project folder or an existing project folder?
2. Which files already exist?
3. Will any file be overwritten?
4. Was a conflict report created?
5. Did the script default to SKIP for existing README.md and PROJECT_STATE.md?
6. Are installed registry/path entries absolute and resolved?
```

Gateway installation is optional.

Simple ZIP activation remains the preferred activation method.

---
## Gate 7 — User Content Survival Gate

Before rerunning activation, gateway installation, project generation, or upgrade scripts, the AI must confirm:

```text
1. Could this action touch an existing project folder?
2. Could this action overwrite README.md, PROJECT_STATE.md, journals, notes, data, source material, or user edits?
3. Is the default action SKIP for existing files?
4. Is a backup created before any approved overwrite?
5. Will a rerun/conflict report be produced?
```

If the answer is unclear, stop and ask Barry before proceeding.

Rule:

```text
User content must survive rerun.
```
