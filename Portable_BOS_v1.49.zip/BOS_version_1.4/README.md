# README.md

# Portable BOS v1.4.2 User Content Survival Patch

## Mission

Portable BOS turns Barry's ideas into disciplined, resumable, verifiable AI project development.

Its operating equation is:

```text
Idea
  ↓
Incubator
  ↓
Core BOS
  ↓
Verified Block
  ↓
Memory
  ↓
Governance
  ↓
Upgrade System
  ↓
Improved BOS
```

## What Changed In v1.4.2

v1.4.2 adds the User Content Survival Patch.

Main rule:

```text
User content must survive rerun.
```

Existing project files, journals, notes, data, source materials, and manual edits must be skipped by default during rerun unless Barry explicitly approves overwrite with backup.

## What Changed In v1.4.1

v1.4.1 adds the Gateway Safety Patch.

```text
1. Simple activation unchanged.
2. Gateway installer optional and overwrite-safe.
3. Existing project files skipped by default.
4. Installed path report uses absolute paths.
5. Maturity clarified as Level 3.5 / Level 4 Candidate.
```

## What Changed In v1.4.0

v1.4.0 adds the BOS Upgrade System.

The goal is to prevent package-level system crashes caused by file rename, branch updates, outdated references, or incomplete patching.

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Main Branches

```text
BOS_version_1.4/
├── 00_BOOTSTRAP/
├── 01_EXPERIENCE/
├── 02_ENGINEERING/
├── 03_INTELLIGENCE/
├── 04_FACTORY/
├── 05_PRODUCTS/
├── 06_STANDARDS/
├── 07_ARCHIVE/
├── 08_INCUBATOR/
├── 09_MEMORY/
├── 10_GOVERNANCE/
├── 11_PERSONAS/
└── 12_UPGRADE_SYSTEM/
```

## Module Registry

The root `MODULE_REGISTRY.md` defines active files.

Core BOS should load logical roles from the registry instead of relying on fragile hardcoded filenames.

## Active Incubator Branch

```text
08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

## Upgrade System Branch

The Upgrade System includes:

```text
BOS_UPGRADE_POLICY.md
BOS_UPGRADE_JOURNAL.md
PATCH_PROPOSAL_TEMPLATE.md
PATCH_APPLICATION_RULES.md
REFERENCE_INTEGRITY_CHECK.md
VERSIONING_POLICY.md
ROLLBACK_POLICY.md
UPGRADE_COMPLETION_REPORT_TEMPLATE.md
```

## Standard AI Load Order

1. Root `00_FIRST_READ_ME.md`
2. Root `BOS_ACTIVATION_MANIFEST.md`
3. Root `MODULE_REGISTRY.md`
4. `OWNER.md`
5. `VISION.md`
6. `PROJECT_STATE.md`
7. `02_ENGINEERING/HARNESS.md`
8. `02_ENGINEERING/WORKFLOW.md`
9. `00_BOOTSTRAP/BLOCK_ENGINE.md`
10. `10_GOVERNANCE/BOS_GROWTH_GOVERNANCE.md`
11. `08_INCUBATOR/IDEA_INCUBATOR_v1.1.md`
12. `09_MEMORY/MEMORY_LAYER_PROCEDURE.md`
13. `12_UPGRADE_SYSTEM/BOS_UPGRADE_POLICY.md`
14. `12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md`
15. `11_PERSONAS/BOS_ARCHITECT_GROWTH_PARTNER.md`

## Golden Rule

Core BOS is protected.

New ideas must pass through Incubator, Memory, Governance, and Upgrade System before they become permanent Core BOS changes.

No BOS ZIP should be called VERIFIED unless registry, manifest, journal, version, scripts, and integrity report agree.
---

## v1.4.3 Package QA Gate + Release Naming Standard

External release name: `Portable_BOS_v1.43.zip`

Adds release naming discipline, package QA gate, patch manifest requirement, clean-install ZIP simulation, and optional Incubator domain extension index.

---

## v1.4.4 User-Facing Design Review Gate + Fast UI Polish Mode

External release name: `Portable_BOS_v1.44.zip`

Adds a User-Facing Design Review Gate (06_STANDARDS) so implementation language never reaches end users unreviewed, and a Fast UI Polish Mode (02_ENGINEERING) as a lightweight, still-safe verification lane for wording/label/low-risk layout changes. Both rules were promoted from HomeVisualizer product backlog notes at a planned maintenance checkpoint.
