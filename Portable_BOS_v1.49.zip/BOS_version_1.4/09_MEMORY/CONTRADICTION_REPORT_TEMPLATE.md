# CONTRADICTION_REPORT_TEMPLATE.md

# Contradiction Report Template

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Record possible conflicts between new material and existing BOS rules.

## Conflict Format

```text
Conflict ID:
Date:
New source:
Existing rule/file:
Conflict:
Severity:
Recommendation:
Needs Barry approval:
Resolution:
```

## Rule

A contradiction report is not automatically a BOS change.

It is a review item.
