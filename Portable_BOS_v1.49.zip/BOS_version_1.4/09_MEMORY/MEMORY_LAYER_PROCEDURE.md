# MEMORY_LAYER_PROCEDURE.md

# BOS Memory Layer Procedure

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Prepare every BOS project for future long-term memory systems such as Cognee, Mem0, Graphiti, custom SQLite memory, or a Markdown-only LLMWiki.

## Principle

Do not make Cognee the BOS.

BOS is the operating procedure.

Cognee or another engine may become the memory backend later.

## Memory Architecture

```text
Core BOS
  ↓
Project Files
  ↓
Journals / Decisions / Checkpoints
  ↓
Memory Index
  ↓
Optional Knowledge Graph / Vector Store
```

## Required Project Memory Files

Every serious project should maintain:

```text
README.md
PROJECT_STATE.md
project_journal.md
decision_log.md
memory_index.md
source_registry.md
contradiction_report.md
```

## Memory Quality Rules

1. Store verified facts separately from ideas.
2. Do not store every chat message.
3. Do not store private secrets.
4. Mark deprecated knowledge.
5. Link decisions to checkpoints.
6. Link sources to generated wiki pages.
7. Keep project state current.
8. Make memory useful for future action.

## Rule

Memory is valuable only if it changes the next AI action.
