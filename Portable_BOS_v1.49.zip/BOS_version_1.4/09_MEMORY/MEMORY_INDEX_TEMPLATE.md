# MEMORY_INDEX_TEMPLATE.md

# Memory Index Template

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Project Identity

- Project name:
- Purpose:
- First user:
- Current status:

## Stable Facts

- Tech stack:
- Main folders:
- Important commands:
- Current checkpoint:

## Important Decisions

- Decision:
- Date:
- Reason:
- Impact:
- Related files:

## Entities

- People:
- Projects:
- Modules:
- APIs:
- Scripts:
- Documents:

## Relationships

- Module depends on:
- Script updates:
- API calls:
- Decision affects:
- Journal confirms:

## Open Questions

- Question:
- Why it matters:
- Current owner:
