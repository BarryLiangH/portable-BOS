# SOURCE_REGISTRY_TEMPLATE.md

# Source Registry Template

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Track raw sources used by the Memory Branch.

## Source Record Format

```text
Source ID:
Date added:
Source type:
Original filename or link:
Stored in raw/:
Summary:
Used for:
Generated wiki pages:
Reliability:
Sensitive content:
Governance status:
```
