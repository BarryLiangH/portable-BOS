# LLMWIKI_PROCEDURE.md

# BOS LLMWiki Procedure

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This procedure adapts the LLMWiki idea into Portable BOS.

It allows raw sources to become AI-maintained structured wiki knowledge while keeping Core BOS protected.

## Three Layers

```text
raw/
  Original imported material. Read-only.

wiki/
  AI-generated structured knowledge.

memory_skills/
  Commands and procedures for ingesting, querying, comparing, and detecting contradictions.
```

## BOS Adaptation

```text
09_MEMORY/
├── raw/
├── wiki/
├── memory_skills/
├── memory_index_template.md
├── source_registry_template.md
└── contradiction_report_template.md
```

## Source Rule

Raw material is evidence.

Wiki material is interpretation.

Governance decides whether any wiki insight becomes a BOS rule.

## Ingest Output

Every ingest should produce:

```text
Source summary:
Entities:
Concepts:
Tools:
Possible BOS branch:
Possible contradiction:
Suggested wiki pages:
Governance classification:
```

## Safety Rule

AI may suggest BOS improvements from wiki knowledge.

AI must not silently rewrite Core BOS.
