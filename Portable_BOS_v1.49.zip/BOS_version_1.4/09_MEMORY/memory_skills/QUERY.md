# QUERY.md

# Memory Skill: Query

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Command Purpose

Answer questions from BOS memory.

## Procedure

1. Search memory_index.
2. Search wiki pages.
3. Check source_registry.
4. Separate verified facts from interpretation.
5. Return concise answer and next recommended action.

## Rule

Do not invent memory.
