# UPDATE_WIKI.md

# Memory Skill: Update Wiki

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Command Purpose

Create or update structured wiki pages from verified raw sources.

## Rule

Wiki pages can be updated by AI.

Core BOS files cannot be changed without governance approval.
