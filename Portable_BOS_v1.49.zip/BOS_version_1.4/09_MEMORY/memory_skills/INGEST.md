# INGEST.md

# Memory Skill: Ingest

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Command Purpose

Turn new raw material into structured BOS memory.

## Procedure

1. Store or reference the original source under raw/.
2. Summarize the source.
3. Extract entities, concepts, tools, workflows, risks, and reusable ideas.
4. Classify the insight into Core, Incubator, Memory, Governance, Future Intelligence, or Future Automation.
5. Propose wiki pages.
6. Update memory_index.md.
7. Add source_registry entry.
8. Create contradiction report if needed.

## Rule

Do not modify raw source.
