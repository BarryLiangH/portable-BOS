# DETECT_CONFLICT.md

# Memory Skill: Detect Conflict

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Command Purpose

Find contradictions between new ideas and existing BOS rules.

## Check

- Does this conflict with Core BOS?
- Does this duplicate an existing module?
- Does this belong in Incubator, Memory, Governance, Intelligence, or Automation?
- Is it mature enough for a pilot?
- Does it need Barry approval?

## Output

```text
Conflict:
Affected file:
Severity:
Suggested action:
Approval needed:
```
