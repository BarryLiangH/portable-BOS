# NEW_PROJECT_STARTER.md

# BOS — New Project Starter

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file turns a one-paragraph idea into a working project seed.

It exists to skip the first days of sentence-to-sentence debugging and start the new project at block-delegation level.

This file is the canonical place for project seed fields.

PROJECT_SEED_TEMPLATE.md is only a scaffold output template and must not duplicate this file's decision process.

## How To Use

1. Copy this file into a new AI chat.
2. Add one paragraph describing the idea.
3. AI fills Section A.
4. AI proposes Section D: first block.
5. Barry approves or corrects.
6. AI executes one block.
7. AI verifies.
8. AI promotes new lessons into BOS.

---

## SECTION A — Project Seed

AI fills this from Barry's one-paragraph idea.

If unclear, ask ONE clarifying question only.

- Project name:
- One-sentence purpose:
- Target: BOS Core / BPAIECO Module / Application-Specific
- Platform: Windows desktop / web / CLI / mobile / other
- Primary language or stack:
- Existing overlap: BrainAgentWorkSpace / DocAgent / Changes / TOTO-AI / none
- Definition of done for v0.1:
- First user:
- First real-life use case:
- What problem does this remove from Barry's life?:

---

## SECTION B — Inherited Rules

These are proven rules from previous projects.

Do not rediscover them.

### B1. 3-Strike Rule

If the same error fails 3 times, stop.

Summarize what was tried.

Ask Barry before a fourth attempt.

### B2. Dependency-Chasing Limit

Do not keep installing or upgrading packages endlessly.

If package changes do not solve the problem quickly, stop and reassess.

### B3. Windows Python GUI Threading Rule

Background threads must not update UI widgets directly.

Use main-thread scheduling such as `self.after(0, ...)`.

### B4. CustomTkinter Transparent Tuple Rule

Do not use `("transparent", "transparent")` as a CTk color tuple.

### B5. Windows UTF-8 Output Rule

When printing Chinese or non-ASCII text on Windows, explicitly handle UTF-8 stdout/stderr.

### B6. Drag-and-Drop Block Rule

Do not retry native drag-and-drop without a deliberate COM `IDropTarget` strategy.

### B7. Explicit Output Folder Rule

Always create output folders before writing.

### B8. Knowledge Before Code

Write the workflow and project seed before implementing.

### B9. Resume Rule

A project must be resumable in a new chat using PROJECT_STATE.md plus this starter file.

---

## SECTION C — Block Delegation Contract

A block is a bounded unit of work that AI may complete without line-by-line interruption.

Before starting, AI must state:

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
VERIFICATION:
PROMOTION CHECK:
```

Barry approves or edits before execution.

### During A Block

AI may work independently if:

- goal is clear
- files are bounded
- no mission change is needed
- inherited rules are followed
- verification is possible

AI must stop if:

- same error occurs 3 times
- architecture must change
- new dependency risk appears
- output no longer matches the block goal
- human judgment is required

---

## SECTION D — First Block Proposal

AI fills this before writing code.

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
VERIFICATION:
PROMOTION CHECK:
```

The first block should be the smallest end-to-end proof of the idea.

---

## SECTION E — Verification And Promotion Checklist

Before calling a block done:

- [ ] Does it run without error?
- [ ] Does output match DONE WHEN?
- [ ] Were inherited rules followed?
- [ ] Did anything require 2+ attempts?
- [ ] If yes, was a new FAILURE_LIBRARY entry created?
- [ ] Was any success pattern discovered?
- [ ] If yes, was a new SUCCESS_LIBRARY entry created?
- [ ] Is PROJECT_STATE.md updated?
- [ ] Can the project resume in a new chat?

---

## SECTION F — Promotion Rule

If a fix, rule, pattern, or workflow would help future projects:

1. Add it to this file immediately.
2. Add it to FAILURE_LIBRARY.md, SUCCESS_LIBRARY.md, HARNESS.md, WORKFLOW.md, or NEW_PROJECT_STARTER.md according to the promotion target.
3. Update PROJECT_STATE.md.
4. Use it in the next project.

Skipping promotion means BOS does not learn.
