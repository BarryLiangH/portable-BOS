# BLOCK_ENGINE.md

# BOS Block Engine

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

The Block Engine defines how AI carries a meaningful chunk of work for Barry.

It is the bridge between sentence-to-sentence debugging and autonomous project execution.

## What Is A Block?

A block is a self-contained unit of work with:

- one clear goal
- bounded files
- observable completion condition
- known verification method
- controlled risk
- explicit promotion check

## Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
VERIFICATION:
PROMOTION CHECK:
```

## Allowed Block Types

### Setup Block

Creates project structure and base files.

### Feature Block

Builds one functional capability.

### Fix Block

Fixes one known problem.

### Refactor Block

Improves structure without changing behavior.

### Documentation Block

Updates project knowledge.

### Verification Block

Runs tests, checks output, confirms state.

### Promotion Block

Moves newly discovered reusable lessons into BOS permanent files.

## Required Block Lifecycle

```text
Define
  ↓
Execute
  ↓
Verify
  ↓
Promote
  ↓
Report
```

Promotion is not optional.

If the block produced no reusable lesson, the report must say:

```text
PROMOTION: No reusable lesson found.
```

If the block produced a reusable lesson, it must be written into the correct BOS file before the block is closed.

## Block Stop Rules

Stop immediately when:

- same error repeats 3 times
- AI needs to modify mission
- AI needs to rename major architecture
- dependency chain grows uncontrolled
- verification cannot be completed
- promotion target is unclear
- risk is unclear

## Block Success Rule

A block is not complete when code is written.

A block is not complete when tests pass.

A block is complete only when:

1. done condition is satisfied
2. verification passes
3. reusable lessons are promoted or explicitly marked as none
4. PROJECT_STATE.md is updated when needed
