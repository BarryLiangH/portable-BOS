# BOS_CORE_DIGEST.md

## Purpose

One-page distillation of the non-negotiable BOS rules. Loaded early at activation so every AI session starts with the core constraints even before the full module set is read. The full modules remain authoritative; this digest never overrides them — it summarizes them.

## Identity

```text
Owner: Barry.
BOS goal: compress experience into reusable capability so every new project
starts at block delegation, not sentence-to-sentence debugging.
Version: see VERSION.txt.
```

## The Ten Constraints

```text
1. NO CODING before: Project Seed accepted → Architecture Gate passed →
   Builder Safety Handoff done → Block 1 proposed → Barry approves.
2. BLOCK FORMAT: BLOCK / FILES TOUCHED / DONE WHEN / RISK / USER CONTENT
   SURVIVAL CHECK / PACKAGE QA CHECK / USER-FACING DESIGN REVIEW CHECK /
   VERIFICATION / PROMOTION CHECK.
3. 3-STRIKE RULE: same error fails 3 times → stop, summarize, ask Barry.
4. BACKUP BEFORE OVERWRITE. User content must survive rerun; default action
   for existing user files is SKIP; overwrite needs explicit Barry approval
   plus a timestamped backup.
5. NEVER CLAIM VERIFICATION that was not actually run. Generated text is not
   executed work. Valid proof: real file, ZIP, terminal output pasted by
   Barry, test output, checksum, or Barry's confirmation.
6. PACKAGE QA GATE: a release is complete only when the delivered ZIP is
   extracted into a clean folder and verification passes from there.
   Generate SHA256 only after that passes.
7. PROMOTE OR DECLARE: every block ends with a promoted reusable lesson or
   the explicit line "PROMOTION: No reusable lesson found."
8. DESIGN REVIEW GATE: no user-facing wording ships unreviewed. Action
   language, not implementation language (Save Design, not Save JSON).
9. PATCH DISCIPLINE: any BOS change is a controlled patch — journal first,
   then registry, manifest, version, scripts, and integrity files together.
   A file rename is a system-level patch.
10. WRONG-FILE PREVENTION: when verification fails, patch the file named by
    the failing line, not a guessed nearby file.
```

## Stop Immediately When

```text
same error repeats 3 times · scope expands uncontrollably · verification
cannot run · mission or major architecture would change · risk is unclear ·
promotion target is unclear · AI is guessing instead of knowing
```

## Barry's Delivery Standard

```text
Clear, direct, copy-run PowerShell batches. One full working batch, not
fragments. Backup before overwrite. Verification before moving on. Short
explanation before commands. Checkpoint sentence and next approval sentence
at the end of every delivered block. No sudden workflow changes.
```

## Load-On-Demand Rule

This digest covers the constraints. For the reasoning behind them and full
procedures, load the authoritative modules via MODULE_REGISTRY.md when the
task touches their area — e.g. FAILURE_LIBRARY.md before debugging a known
problem class, BOS_INTEGRITY_GATES.md before any new project handoff,
12_UPGRADE_SYSTEM/* before any BOS package change.
