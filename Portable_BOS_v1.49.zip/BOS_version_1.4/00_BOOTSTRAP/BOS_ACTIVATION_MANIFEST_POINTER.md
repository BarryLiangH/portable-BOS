# BOS_ACTIVATION_MANIFEST_POINTER.md

# Activation Manifest Pointer

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)
The canonical activation manifest is at the package root:

```text
BOS_ACTIVATION_MANIFEST.md
```

The canonical active module map is at the package root:

```text
MODULE_REGISTRY.md
```

Read those files first when activating BOS from a ZIP package.

Active Incubator:

```text
08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

Upgrade System:

```text
12_UPGRADE_SYSTEM/
```
