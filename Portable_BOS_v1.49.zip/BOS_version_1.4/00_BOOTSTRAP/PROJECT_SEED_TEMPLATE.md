# PROJECT_SEED_TEMPLATE.md

# BOS Project Seed Output Template

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file is not the canonical decision form.

NEW_PROJECT_STARTER.md is the canonical place where AI fills project seed fields.

This file defines the output folder scaffold generated after Section A is completed.

## Generated Project Folder

```text
NewProject/
├── README.md
├── PROJECT_STATE.md
├── ROADMAP.md
├── WORKFLOW.md
├── HARNESS.md
├── CHECKPOINT.md
├── docs/
├── app/
├── tests/
├── data/
├── scripts/
└── archive/
```

## Required Inheritance

Every generated project must inherit:

- BOS OWNER.md decision rule
- BOS FAILURE_LIBRARY.md rules
- BOS HARNESS.md safety rules
- BOS BLOCK_ENGINE.md block contract
- BOS PROMOTION_ENGINE.md promotion rule

## Rule

Do not duplicate project seed questions here.

This file only defines what is generated after the seed is accepted.
