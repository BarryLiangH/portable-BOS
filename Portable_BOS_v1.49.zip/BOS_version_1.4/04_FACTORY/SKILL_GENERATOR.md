# SKILL_GENERATOR.md

# BOS Skill Generator

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Convert repeated capability into reusable skill files.

## When To Create A Skill

Create a skill when:

- the same task appears in 2+ projects
- the instruction is stable
- the AI needs repeated guidance
- the skill reduces future prompting

## Skill Test

A skill is useful only if it changes AI behavior.

If it is just inspiration, do not create it.
