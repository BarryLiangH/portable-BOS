# PROJECT_GENERATOR.md

# BOS Project Generator

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

The Project Generator currently defines the documented procedure and templates for turning a project idea into a ready project folder.

It is not yet a complete executable one-click generator.

If file creation is required, the Builder must still use BOS Integrity Gates, safe file generation, and verification.

## Input

One paragraph:

```text
NewProject/
├── README.md
├── PROJECT_STATE.md
├── ROADMAP.md
├── WORKFLOW.md
├── HARNESS.md
├── CHECKPOINT.md
├── docs/
├── app/
├── tests/
├── data/
├── scripts/
└── archive/
```

## Required Generated Files

### README.md

What the project is.

### PROJECT_STATE.md

Current state and resume instruction.

### ROADMAP.md

v0.1, v0.2, v1.0 path.

### WORKFLOW.md

How this project should be developed.

Must reference BOS WORKFLOW.md.

### HARNESS.md

Project-specific guardrails plus inherited BOS rules.

Must be seeded from:

- OWNER.md
- FAILURE_LIBRARY.md
- HARNESS.md
- BLOCK_ENGINE.md
- PROMOTION_ENGINE.md

### CHECKPOINT.md

How the project records safe resume points.

## First Generated Block

Every generated project must include Block 1.

Block 1 should create the smallest end-to-end working proof.

## Generator Rule

Do not generate a large perfect project.

Generate a small project that can run, verify, promote lessons, and improve.


## Current Maturity

```text
Status: Documentation/procedure generator.
Not yet: fully executable project generator.
```

## Gateway Safety Rule

Project generation must not overwrite existing project files silently.

If a target file exists, default to SKIP, create a conflict report, and ask Barry before overwrite.
