# DOCUMENT_GENERATOR.md

# BOS Document Generator

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Generate the standard Markdown documents needed for a new project.

## Required Documents

- README.md
- PROJECT_STATE.md
- ROADMAP.md
- WORKFLOW.md
- HARNESS.md
- CHECKPOINT.md

## Optional Documents

- ARCHITECTURE.md
- API.md
- DATABASE.md
- UI.md
- DEPLOYMENT.md
- TESTING.md

## Rule

Only create optional documents when the project truly needs them.
