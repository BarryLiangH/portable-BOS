# OWNER.md

# BOS Owner Definition

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file restores the owner context required by HARNESS.md and MEMORY.md.

It defines Barry's engineering preferences so every AI working inside BOS understands the human architect before acting.

This file does not store private personal details.

It stores collaboration rules, engineering preferences, and decision principles.

## Owner

Barry

## Core Objective

Barry is building BOS so that a new idea can become a production-ready AI system faster than before.

The purpose is not to create more documentation.

The purpose is to compress experience into reusable capability.

## Barry's Current AI Development Evolution

Barry's AI journey moved through four levels:

```text
Sentence-to-sentence debugging
  ↓
Pattern recognition
  ↓
Block delegation
  ↓
Future production loop
```

BOS should help every new project start closer to block delegation instead of restarting at sentence-to-sentence debugging.

## Barry's Preferred Development Style

Barry prefers:

- visible prototypes over endless planning
- Markdown-first knowledge architecture
- usable systems that can be portable and improved
- block-level AI delegation
- clear verification before moving on
- checkpoints and resumable state
- copy-run scripts when implementation is needed
- practical output over abstract discussion
- reusable engineering rules
- fast-but-safe progress

## AI Collaboration Rule

AI should not only explain.

AI should produce usable artifacts.

AI should not keep listing plans when Barry asks for the product.

AI should challenge weak ideas respectfully.

AI should accept good ideas from other AI systems when they improve BOS.

## Decision Rule

When uncertain, ask:

> Will this make Barry more capable in the future?

If yes, preserve it.

If no, simplify it.

## BOS-Specific Decision Rule

When a lesson appears, classify it:

```text
Failure → FAILURE_LIBRARY.md
Success → SUCCESS_LIBRARY.md
Workflow → WORKFLOW.md
Harness rule → HARNESS.md
Project starter improvement → NEW_PROJECT_STARTER.md
Product experience → BPAIECO
```

## Block Delegation Preference

Barry wants AI to carry bounded blocks of work.

A block must have:

- clear goal
- files touched
- done condition
- risk statement
- verification method
- promotion step if new lessons are found

## Final Principle

The owner does not need BOS to be perfect.

The owner needs BOS to be usable early, tested in real projects, and improved through experience.
