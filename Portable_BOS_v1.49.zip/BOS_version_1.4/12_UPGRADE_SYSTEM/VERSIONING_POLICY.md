# VERSIONING_POLICY.md

## Purpose

Defines Portable BOS version numbering.

## Format

```text
MAJOR.MINOR.PATCH
```

## Meaning

```text
MAJOR:
Core BOS philosophy, activation model, or compatibility changes.

MINOR:
New branch, new subsystem, new upgrade path, or large workflow expansion.

PATCH:
Reference fixes, file name corrections, integrity fixes, documentation cleanup.
```

## Examples

```text
v1.3.3 → v1.4.0
Minor update because Upgrade System branch was added.

v1.4.0 → v1.4.1
Patch update for reference corrections.

v1.4.0 → v2.0.0
Major update if a real external memory engine becomes part of the system.
```
---

## External Release Naming v1.4.3

Use semantic versions internally and simple names externally.

```text
Internal version: 1.4.3
External ZIP: Portable_BOS_v1.43.zip
```

Do not include long patch descriptions in the external ZIP filename. Put change details in the Upgrade Journal, Patch Manifest, and Integrity Report.
