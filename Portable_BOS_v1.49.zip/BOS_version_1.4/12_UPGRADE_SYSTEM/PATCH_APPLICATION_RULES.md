# PATCH_APPLICATION_RULES.md

## Purpose

Defines the safe order for applying BOS patches.

## Patch Order

```text
1. Read BOS_UPGRADE_JOURNAL.md.
2. Read MODULE_REGISTRY.md.
3. Read patch proposal.
4. Apply file additions and replacements.
5. Archive old active files instead of deleting them.
6. Update MODULE_REGISTRY.md.
7. Update BOS_ACTIVATION_MANIFEST.md only if load order changes.
8. Update BOS_version_1.4/MANIFEST.md.
9. Update VERSION.txt.
10. Update BOS_UPGRADE_JOURNAL.md.
11. Run VERIFY_BOS_PACKAGE.ps1.
12. Run BOS_UPGRADE_MANAGER.ps1.
13. Build ZIP.
14. Generate SHA256.
15. Release only if all checks pass.
```

## Rule

No manual copy-paste upgrade should be treated as complete.

The package must be rebuilt and verified.

---
## User Content Survival Patch Rule v1.4.2

A BOS patch may change BOS package files inside the upgrade workspace, but must not silently change user project content outside that workspace.

Before a patch is released, verify:

```text
1. Any generator or gateway writes are non-destructive by default.
2. Existing project files are skipped unless Barry explicitly approves overwrite.
3. Any approved overwrite creates a timestamped backup.
4. A rerun/conflict report is created.
5. MANIFEST.md and MODULE_REGISTRY.md register the User Content Survival rule.
```

Patch releases must preserve the simple activation command.
---

## Package QA Gate v1.4.3

Before any package is released:

```text
1. Create or update PATCH_MANIFEST.
2. Confirm every runner-required file is included.
3. Extract the ZIP into a clean temporary folder.
4. Run verification from the extracted folder.
5. Release only after clean-install simulation passes.
```

Tests must avoid stale hard-coded version checks unless exact version is the feature being tested.
