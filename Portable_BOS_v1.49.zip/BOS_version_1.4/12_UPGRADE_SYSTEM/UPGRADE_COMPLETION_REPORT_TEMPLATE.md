# UPGRADE_COMPLETION_REPORT_TEMPLATE.md

## Purpose

Every BOS upgrade must produce a completion report.

## Template

```text
UPGRADE COMPLETED:

Version:
Package name:
Date:

Reason for upgrade:
Files added:
Files updated:
Files archived:
Files renamed:
Registry changes:
Manifest changes:
Script changes:
Journal updated:
Integrity result:
Checksum created:
Rollback target:
Known risks:
Release status:
```

## Required Release Status

Use one of:

```text
VERIFIED
FAILED
HOLD
ROLLBACK REQUIRED
```
