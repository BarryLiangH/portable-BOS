# PATCH_PROPOSAL_TEMPLATE.md

## Purpose

Use this template before changing BOS files, names, modules, scripts, or activation logic.

## Patch Proposal

```text
Patch ID:
Proposed version:
Date:
Reason:
Triggered by:
Affected module IDs:
Files to add:
Files to update:
Files to rename:
Files to archive:
Files to remove:
Registry changes:
Manifest changes:
Script changes:
Risk:
Rollback target:
Verification method:
```

## Rule

Do not apply a BOS patch unless the affected module IDs and registry changes are listed.
