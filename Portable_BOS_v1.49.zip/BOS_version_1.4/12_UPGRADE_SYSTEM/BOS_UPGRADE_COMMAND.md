# BOS_UPGRADE_COMMAND.md

## Purpose

Provide Barry's safe command format for future BOS upgrades.

## Standard Upgrade Command

```text
I uploaded the latest BOS ZIP.

Start BOS upgrade procedure.

First read:
1. 12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
2. MODULE_REGISTRY.md
3. BOS_ACTIVATION_MANIFEST.md

Then apply this change as a controlled BOS upgrade patch:
<describe the change>

Keep simple activation unchanged.
Do not release a new ZIP until:
1. all affected references are updated,
2. MODULE_REGISTRY.md is correct,
3. BOS_UPGRADE_JOURNAL.md has a new entry,
4. integrity check passes,
5. clean-install simulation from ZIP passes,
6. new verified ZIP and SHA256 are produced.
```

## Short Upgrade Command

```text
I uploaded the latest BOS ZIP.
Read BOS_UPGRADE_JOURNAL.md first, then MODULE_REGISTRY.md, then start the BOS upgrade.
Patch this change:
<change>
Keep simple activation unchanged and release only after integrity verification passes.
```
