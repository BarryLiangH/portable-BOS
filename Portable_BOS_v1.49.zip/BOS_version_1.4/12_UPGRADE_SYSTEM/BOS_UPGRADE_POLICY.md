# BOS_UPGRADE_POLICY.md

## Purpose

This policy defines how Portable BOS is upgraded without breaking activation, manifests, scripts, menus, or module references.

## Core Principle

```text
Core BOS loads logical roles.
MODULE_REGISTRY.md maps logical roles to physical files.
Upgrade System verifies the registry before any release is called VERIFIED.
```

## Upgrade Rule

No BOS patch is complete until these agree:

```text
1. MODULE_REGISTRY.md
2. BOS_ACTIVATION_MANIFEST.md
3. BOS_version_1.4/MANIFEST.md
4. BOS_UPGRADE_JOURNAL.md
5. VERIFY_BOS_PACKAGE.ps1
6. VERSION.txt
7. INTEGRITY_REPORT
```

## Simple Activation Protection

The simple activation command must not change unless Barry explicitly approves:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## No Manual Copy-Paste Patch Rule

For BOS system upgrades, avoid long manual copy-paste patching.

Preferred upgrade methods:

```text
1. Generate a new verified ZIP package.
2. Use BOS_UPGRADE_MANAGER.ps1 to verify registry, references, journal, and package integrity.
3. Keep the previous verified ZIP as rollback.
```

## Release Gate

A BOS package may only be labeled `VERIFIED` after:

```text
1. Required files exist.
2. Registry active paths exist.
3. Current version is recorded in BOS_UPGRADE_JOURNAL.md.
4. Scripts reference the correct core folder.
5. Archived files are not active.
6. SHA256 checksum is generated.
```
---

## Package QA Gate v1.4.3

An upgrade is not complete until the release ZIP is tested from a clean extraction.

Required release order:

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Apply controlled patch.
5. Update all affected references.
6. Update PATCH_MANIFEST.
7. Run source verification.
8. Build ZIP.
9. Extract ZIP to clean temporary folder.
10. Run verification from extracted folder.
11. Generate SHA256.
```
