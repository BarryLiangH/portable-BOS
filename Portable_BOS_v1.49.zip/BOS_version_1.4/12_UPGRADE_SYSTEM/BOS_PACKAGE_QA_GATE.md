# BOS_PACKAGE_QA_GATE.md

## Purpose

Prevent source-tested but user-broken BOS packages.

A package is not complete just because source files pass verification. A package is complete only after the ZIP itself is tested as an installable/reloadable package.

## Reason This Gate Exists

During HomeVisualizer Block 16.1 / 16.1C, redundant verification failures were caused by:

```text
1. test-version drift;
2. incomplete patch package contents;
3. patching the wrong verification file;
4. checking source files but not the exact installed package shape.
```

## Mandatory Clean-Install Simulation

Before releasing any future BOS package or BOS-generated patch ZIP:

```text
1. Source verification must pass.
2. PATCH_MANIFEST must exist.
3. Every added/changed file listed in the manifest must be present in the ZIP.
4. The ZIP must be extracted into a clean temporary folder.
5. Verification must run from the extracted folder.
6. Only the extracted ZIP verification result counts as release proof.
7. Generate SHA256 only after clean-install verification passes.
```

## Patch Manifest Requirement

Every release patch must include a manifest that lists:

```text
1. block or BOS version;
2. files added;
3. files changed;
4. files archived;
5. tests added or changed;
6. expected verification command;
7. expected verification result;
8. rollback target.
```

## Test-Version Drift Rule

Tests should verify behavior, not stale implementation details.

Bad:

```text
app.js?v=15.1
```

Better:

```text
app.js has a valid cache-busting version
```

Exact version checks are allowed only if the exact version itself is the feature under test.

## Package Completeness Rule

If the runner expects a file, the ZIP must include it.

Do not update a runner without packaging all new required files.

## Wrong-File Patch Prevention

When a verification run fails, patch the file named by the failing line, not a nearby related file.

## Final Rule

No release package is complete until clean-install simulation passes from the ZIP.
