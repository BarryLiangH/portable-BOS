# BOS_RELEASE_NAMING_STANDARD.md

## Purpose

Protect Portable BOS from naming drift.

Naming is not cosmetic in BOS. Naming affects file references, module registry paths, activation order, upgrade scripts, manifest matching, archive clarity, AI reading priority, and rollback safety.

## External Release Naming Rule

External release ZIP names must be simple:

```text
Portable_BOS_v1.49.zip
```

Do not put long patch descriptions in the external ZIP name.

## Internal Version Rule

Internal files may use the technical semantic version:

```text
1.4.9
v1.4.9
```

The upgrade journal explains what changed.

## Current Naming Mapping

```text
External release name: Portable_BOS_v1.49.zip
Internal BOS version: 1.4.9
Core folder: BOS_version_1.4
```

## Detailed Inside, Simple Outside

Use the ZIP filename only to identify the release.

Use internal files for details:

```text
VERSION.txt
MODULE_REGISTRY.md
BOS_UPGRADE_JOURNAL.md
PATCH_MANIFEST_v1.4.9.md
INTEGRITY_REPORT_v1.4.9.md
```

## Rename Rule

A file rename is a system-level patch. Any rename must update:

```text
MODULE_REGISTRY.md
BOS_ACTIVATION_MANIFEST.md
BOS_version_1.4/MANIFEST.md
BOS_UPGRADE_JOURNAL.md
INTEGRITY_REPORT
VERIFY_BOS_PACKAGE.ps1
BUILD_BOS_ACTIVATION_ZIP.ps1
README_START_HERE.md
BOS_MENU_BOOK
```

## Forbidden Naming Drift

Do not leave multiple active names for the same release role.

Bad:

```text
v1.4.2
v1.42
User_Content_Survival_Patch
```

Good:

```text
External: Portable_BOS_v1.49.zip
Internal: BOS_UPGRADE_JOURNAL.md explains v1.4.9 changes
```

## No-Suffix Corrective Release Rule (v1.4.6)

When a released package fails verification and must be corrected, the fix is
released as the NEXT PATCH VERSION, never as the same name with a suffix.

```text
Wrong:   Portable_BOS_v1.45_REPACK.zip / _R2.zip / _HOTFIX.zip / _FIXED.zip
Right:   Portable_BOS_v1.47.zip (internal 1.4.6), journal explains the correction
```

Reason: suffix names create multiple active names for one release role, break
mechanical version references, and make rollback targets ambiguous — exactly
the wrong-file-pointer failure class this standard exists to prevent. Two ZIPs
with the same base name and different content are equally forbidden.

Rule promoted after Barry corrected an AI-proposed "_REPACK" package name
during the v1.4.5 corrective release (2026-07-04).

## Final Rule

Simple outside. Detailed inside.
