# ROLLBACK_POLICY.md

## Purpose

Defines how to recover if a BOS upgrade breaks activation or logic integrity.

## Rollback Rule

Every verified package must identify the previous stable package.

The CURRENT rollback target is always recorded in the active patch manifest
(the file named by `PATCH_MANIFEST_ACTIVE` in MODULE_REGISTRY.md). Do not
record a "current" rollback target in this policy file — it drifts.

Historical example (v1.4.0):

```text
Rollback target:
Portable_BOS_version_1.3.3_Incubator_v1.1_Integrated_VERIFIED.zip
```

## Rollback Conditions

Rollback if:

```text
1. Simple activation fails.
2. MODULE_REGISTRY.md points to missing files.
3. Active Incubator cannot be loaded.
4. Activation manifest contradicts registry.
5. Verification script fails.
6. AI loads archived files as active files.
```

## Rule

Do not patch a broken release repeatedly without first identifying the last verified working version.
