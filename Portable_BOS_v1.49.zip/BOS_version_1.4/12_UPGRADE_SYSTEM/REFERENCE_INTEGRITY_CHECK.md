# REFERENCE_INTEGRITY_CHECK.md

## Purpose

Prevents BOS crashes caused by file-name drift.

## Required Checks

```text
1. Every active path in MODULE_REGISTRY.md exists.
2. No active manifest entry points to an archived file.
3. BOS_ACTIVATION_MANIFEST.md includes MODULE_REGISTRY.md early.
4. VERSION.txt matches the package version.
5. BOS_UPGRADE_JOURNAL.md contains the current version.
6. VERIFY_BOS_PACKAGE.ps1 checks the current active Incubator file.
7. Build script uses the correct core folder.
8. Activation script uses the correct core folder.
```

## High-Risk Changes

```text
1. Renaming active Incubator file.
2. Changing BOS core folder name.
3. Changing activation command.
4. Adding a new branch.
5. Removing an old file.
6. Moving files into archive.
```

## Rule

Any high-risk change requires a patch journal entry and verification report.

---
## User Content Survival Reference Check v1.4.2

The integrity check must confirm:

```text
1. USER_CONTENT_SURVIVAL_RULES.md exists.
2. MODULE_REGISTRY.md registers USER_CONTENT_SURVIVAL_RULES.md.
3. BOS_ACTIVATION_MANIFEST.md loads USER_CONTENT_SURVIVAL_RULES.md.
4. SAFE_FILE_GENERATION_RULES.md references User Content Survival.
5. CORE_CHANGE_CONTROL.md references User Content Survival.
6. PATCH_APPLICATION_RULES.md references User Content Survival.
7. Simple activation command remains unchanged.
```
---

## Package QA Reference Check v1.4.3

The integrity check must confirm:

```text
1. BOS_PACKAGE_QA_GATE.md exists.
2. BOS_RELEASE_NAMING_STANDARD.md exists.
3. PATCH_MANIFEST_TEMPLATE.md exists.
4. BOS_UPGRADE_COMMAND.md exists.
5. MODULE_REGISTRY.md registers active upgrade gate files.
6. Current root versioned files match the active version.
7. No active root registry entry points to v1.4.2 files.
```
