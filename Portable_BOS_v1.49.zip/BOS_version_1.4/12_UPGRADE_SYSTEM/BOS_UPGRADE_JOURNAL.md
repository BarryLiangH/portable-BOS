# BOS_UPGRADE_JOURNAL.md

## Purpose

This journal records BOS system upgrades, the reason for each update, key files changed, active module names, verification result, and rollback target.

The Upgrade System must read this journal before any release is considered verified.

---

# Version v1.3.3

Date: 2026-07-01  
Package: `Portable_BOS_version_1.3.3_Incubator_v1.1_Integrated_VERIFIED.zip`

## Reason For Update

Integrated Incubator v1.1 after the DeepSeek HomeVisualizer failure showed that a successful idea can still fail during coding if Builder Safety Handoff, Architecture Gate, Environment Reality Check, and File Verification are weak.

## Key Change

```text
Active Incubator became:
BOS_version_1.3/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

## Lesson

```text
A successful Incubator idea is not permission to code.
```

---

# Version v1.4.0

Date: 2026-07-01  
Package: `Portable_BOS_version_1.4.0_Upgrade_System_VERIFIED.zip`

## Reason For Update

Barry identified a system integrity risk: once BOS is a ZIP package with many linked files, renaming or replacing one file can break activation if other files still point to the old name.

The BOS therefore needs a controlled Upgrade System, similar to a lightweight Windows Update process.

## Key Changes

```text
1. Added MODULE_REGISTRY.md as the central active module map.
2. Added 12_UPGRADE_SYSTEM branch.
3. Added BOS_UPGRADE_POLICY.md.
4. Added BOS_UPGRADE_JOURNAL.md.
5. Added PATCH_PROPOSAL_TEMPLATE.md.
6. Added PATCH_APPLICATION_RULES.md.
7. Added REFERENCE_INTEGRITY_CHECK.md.
8. Added VERSIONING_POLICY.md.
9. Added ROLLBACK_POLICY.md.
10. Added UPGRADE_COMPLETION_REPORT_TEMPLATE.md.
11. Updated activation manifest to load the registry early.
12. Updated verification script to check registry paths.
13. Preserved simple activation command.
```

## Active Module Snapshot

```text
CORE_FOLDER = BOS_version_1.4
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
GOVERNANCE_ACTIVE = BOS_version_1.4/10_GOVERNANCE/BOS_GROWTH_GOVERNANCE.md
MEMORY_LAYER_ACTIVE = BOS_version_1.4/09_MEMORY/MEMORY_LAYER_PROCEDURE.md
UPGRADE_POLICY_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_POLICY.md
UPGRADE_JOURNAL_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
```

## Integrity Result

```text
PASS
```

## Rollback Version

```text
Portable_BOS_version_1.3.3_Incubator_v1.1_Integrated_VERIFIED.zip
```

## Permanent Lesson

```text
A BOS file rename is not a local edit. It is a system-level patch and must update the registry, manifest, menu, scripts, journal, and integrity report together.
```

---

# Version v1.4.1

Date: 2026-07-01  
Package: `Portable_BOS_version_1.4.1_Gateway_Safety_Patch_VERIFIED.zip`

## Reason For Update

A BOS integrity review found that the v1.4.0 workflow was ready for protocol use, but the Gateway installer still needed safety clarification and overwrite protection before being treated as routine automation.

## Key Changes

```text
1. Kept simple activation unchanged.
2. Added BOS_GATEWAY_LIMITATION_NOTICE_v1.4.1.md.
3. Clarified Gateway installer is optional and cautious.
4. Patched Gateway installer to skip existing project files by default.
5. Added project conflict report behavior.
6. Added installed absolute path report / installed registry behavior.
7. Clarified BOS maturity as Level 3.5 / Level 4 Candidate, not true autonomous Level 4.
8. Clarified Project Generator as documentation/procedure, not a full executable generator.
9. Added DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.1.md.
10. Updated registry, manifest, menu, version, and integrity report together.
```

## Integrity Result

```text
PASS
```

## Rollback Version

```text
Portable_BOS_version_1.4.0_Upgrade_System_VERIFIED.zip
```

## Permanent Lesson

```text
Simple activation is the primary BOS path. Installer automation must be optional, overwrite-safe, path-aware, and clearly marked by maturity level.
```

---

# Version v1.4.2

Date: 2026-07-01  
Package: `Portable_BOS_version_1.4.2_User_Content_Survival_Patch_VERIFIED.zip`

## Reason For Update

Codex review found that v1.4.1 protected some gateway/project files but did not clearly guarantee that all Barry/user-created content survives activation reruns, Gateway reruns, project generation reruns, or upgrade workflows.

## Key Changes

```text
1. Added USER_CONTENT_SURVIVAL_RULES.md.
2. Updated BOS_ACTIVATION_MANIFEST.md to load User Content Survival during activation.
3. Updated MODULE_REGISTRY.md with USER_CONTENT_SURVIVAL_ACTIVE.
4. Updated CORE_CHANGE_CONTROL.md.
5. Updated BOS_INTEGRITY_GATES.md with User Content Survival Gate.
6. Updated SAFE_FILE_GENERATION_RULES.md.
7. Updated PATCH_APPLICATION_RULES.md.
8. Updated REFERENCE_INTEGRITY_CHECK.md.
9. Added v1.4.2 Gateway notice, menu book, integrity map, and integrity report.
10. Preserved simple activation command.
```

## Main Rule

```text
User content must survive rerun.
```

## Protected Content

```text
README.md
PROJECT_STATE.md
project_journal.md
decision_log.md
architecture.md
user notes
raw ideas
Incubator handoff files
source materials
uploaded blueprints
photos
data files
custom templates
manual edits
generated project work
```

## Verification Result

PASS. Active references updated and package rebuilt with SHA256.
---

# Version v1.4.3

Date: 2026-07-02  
External package: `Portable_BOS_v1.43.zip`  
Internal package version: `1.4.3`

## Reason For Update

HomeVisualizer Block 16.1C revealed that source verification alone is insufficient. Repeated false failures were caused by test-version drift, incomplete patch contents, and patching the wrong verification file. Barry also formalized the naming rule that external release ZIP names must stay simple while internal documents carry the detailed change history.

## Key Changes

```text
1. Added BOS_RELEASE_NAMING_STANDARD.md.
2. Added BOS_PACKAGE_QA_GATE.md.
3. Added PATCH_MANIFEST_TEMPLATE.md.
4. Added BOS_UPGRADE_COMMAND.md.
5. Added PATCH_MANIFEST_v1.4.3.md.
6. Added DOMAIN_EXTENSION_INDEX.md while keeping Incubator general-purpose.
7. Added optional CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md as a domain extension, not core Incubator logic.
8. Updated MODULE_REGISTRY.md, BOS_ACTIVATION_MANIFEST.md, VERSION.txt, README_START_HERE.md, PORTABLE_BOS_SYSTEM_PROMPT.md, menu, scripts, manifest, and integrity files.
9. Archived v1.4.2 active root release files and v1.4.2 upgrade reports.
10. Preserved simple activation command.
```

## Active Module Snapshot

```text
CORE_FOLDER = BOS_version_1.4
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
DOMAIN_EXTENSION_INDEX_ACTIVE = BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
USER_CONTENT_SURVIVAL_ACTIVE = BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
RELEASE_NAMING_STANDARD_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
PACKAGE_QA_GATE_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
PATCH_MANIFEST_ACTIVE = PATCH_MANIFEST_v1.4.3.md
```

## Integrity Result

```text
PASS - source verification and clean ZIP extraction verification completed.
```

## Rollback Version

```text
Portable_BOS_v1.42.zip / internal v1.4.2 package
```

## Permanent Lesson

```text
A release is not complete until the delivered ZIP is extracted and verified. Tests should check behavior, not stale implementation details. External ZIP names stay simple; internal files record the detailed history.
```
---

# Version v1.4.4

Date: 2026-07-03  
External package: `Portable_BOS_v1.44.zip`  
Internal package version: `1.4.4`

## Reason For Update

HomeVisualizer product development recorded two reusable process ideas in `docs/BOS_REVISION_BACKLOG.md` without interrupting active product work:

```text
1. User-Facing Design Review Gate - technical wording (e.g. "Save JSON") reached a
   normal user before it was reviewed from a non-technical perspective.
2. Fast UI Polish Mode - full regression verification is unnecessarily heavy for
   small wording/label/low-risk layout changes.
```

This is the scheduled BOS maintenance checkpoint that promotes both into core BOS, per Barry's approval.

## Key Changes

```text
1. Added BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md.
2. Added BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md.
3. Added PATCH_MANIFEST_v1.4.4.md.
4. Updated MODULE_REGISTRY.md (root and 12_UPGRADE_SYSTEM copies), BOS_ACTIVATION_MANIFEST.md,
   BOS_version_1.4/MANIFEST.md, VERSION.txt, README_START_HERE.md, PORTABLE_BOS_SYSTEM_PROMPT.md,
   00_FIRST_READ_ME.md, ACTIVATE_BOS_FROM_ZIP.md, menu book, scripts, and integrity files.
5. Archived v1.4.3 active root release files (Menu Book, Integrity Map, Integrity Report,
   Gateway Limitation Notice) to archive/v1.4.3_root_release_files/.
6. Archived v1.4.3 dated upgrade-system reports (Deep Integrity Verifier Scope,
   Upgrade Completion Report) to BOS_version_1.4/07_ARCHIVE/v1.4.3_upgrade_reports/.
7. Preserved simple activation command.
8. Did not touch HomeVisualizer or any other user project folder.
```

## Active Module Snapshot

```text
CORE_FOLDER = BOS_version_1.4
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
DOMAIN_EXTENSION_INDEX_ACTIVE = BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
USER_CONTENT_SURVIVAL_ACTIVE = BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
RELEASE_NAMING_STANDARD_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
PACKAGE_QA_GATE_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
USER_FACING_DESIGN_REVIEW_GATE_ACTIVE = BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md
FAST_UI_POLISH_MODE_ACTIVE = BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md
PATCH_MANIFEST_ACTIVE = PATCH_MANIFEST_v1.4.4.md
```

## Integrity Result

```text
PASS - source verification and clean ZIP extraction verification completed.
```

## Rollback Version

```text
Portable_BOS_v1.43.zip / internal v1.4.3 package
```

## Permanent Lesson

```text
Process rules discovered mid-product (naming, review gates, verification modes) should be
captured as sidecar notes and promoted to core BOS at a planned maintenance checkpoint,
not mixed into an active product block.
```
---

# Version v1.4.5

Date: 2026-07-04  
External package: `Portable_BOS_v1.45.zip`  
Internal package version: `1.4.5`

## Reason For Update

Barry requested a high-level architecture review of BOS. The review found seven issues (W1-W7) and Barry approved fixing all of them in one combined release:

```text
W1. Duplicate "Gate 6" numbering inside BOS_INTEGRITY_GATES.md.
W2. Per-file package version headers drifted every release (dozens still said 1.4.2).
W3. Verification checked file existence only, not file content.
W4. Two hand-maintained MODULE_REGISTRY.md copies with no identity check.
W5. FAILURE_LIBRARY.md degrading: mixed formats, no index, unnumbered entry.
W6. Activation loads ~38 files with no compact constraint summary.
W7. Two universal design rules from HomeVisualizer still awaiting promotion.
```

## Key Changes

```text
1. Gate renumber: User Content Survival Gate is now Gate 7 (W1).
2. Version Header Rule: per-file package version headers retired in 45 core
   files; VERSION.txt is the single version source; rule documented in
   MARKDOWN_STANDARD.md (W2).
3. PACKAGE_CHECKSUMS.txt: BUILD script generates per-file SHA256; VERIFY
   script verifies every listed file exists and matches (W3).
4. Registry identity check: VERIFY script confirms root and 12_UPGRADE_SYSTEM
   MODULE_REGISTRY.md are byte-identical (W4).
5. FAILURE_LIBRARY.md: Index added, Entry Rules added, "Failure Case 001"
   renumbered to F010 (W5).
6. BOS_CORE_DIGEST.md added to 00_BOOTSTRAP and loaded early in the
   activation order (W6).
7. BOS_INTERACTION_EDIT_SESSION_RULE.md and BOS_WORKSPACE_FIRST_LAYOUT_RULE.md
   promoted into 06_STANDARDS with adoption footers updated (W7).
8. Registry (both copies), activation manifest, core manifest, VERSION.txt,
   README files, system prompt, menu, scripts, and integrity files updated.
9. v1.4.4 dated root release files and dated reports archived.
10. Simple activation preserved. No user project folders touched.
```

## Active Module Snapshot

```text
CORE_FOLDER = BOS_version_1.4
CORE_DIGEST_ACTIVE = BOS_version_1.4/00_BOOTSTRAP/BOS_CORE_DIGEST.md
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
USER_CONTENT_SURVIVAL_ACTIVE = BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
RELEASE_NAMING_STANDARD_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
PACKAGE_QA_GATE_ACTIVE = BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
USER_FACING_DESIGN_REVIEW_GATE_ACTIVE = BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md
FAST_UI_POLISH_MODE_ACTIVE = BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md
INTERACTION_EDIT_SESSION_RULE_ACTIVE = BOS_version_1.4/06_STANDARDS/BOS_INTERACTION_EDIT_SESSION_RULE.md
WORKSPACE_FIRST_LAYOUT_RULE_ACTIVE = BOS_version_1.4/06_STANDARDS/BOS_WORKSPACE_FIRST_LAYOUT_RULE.md
PACKAGE_CHECKSUMS_ACTIVE = PACKAGE_CHECKSUMS.txt
PATCH_MANIFEST_ACTIVE = PATCH_MANIFEST_v1.4.5.md
```

## Integrity Result

```text
PASS - source verification, checksum verification, and clean ZIP extraction
verification completed.
```

## Rollback Version

```text
Portable_BOS_v1.44.zip / internal v1.4.4 package
```

## Packaging Correction (2026-07-04)

Barry's on-machine verification of the first v1.4.5 package failed:

```text
Missing: BOS_version_1.4\12_UPGRADE_SYSTEM\UPGRADE_COMPLETION_REPORT_v1.4.4.md
```

Root cause: a stale entry in the VERIFY_BOS_PACKAGE.ps1 required-file list, caused
by an unchecked scripted replacement whose match context had been changed by an
earlier replacement. The build-side verification emulation used a parallel
hand-written required list instead of parsing the real script, so it could not
catch the divergence. Fixed in the R2 repack; lesson promoted as F011; checksums
regenerated; R2 verification parses the real script's required list.

Barry rejected the initially proposed "_REPACK" package name as a violation of
the Release Naming Standard. The correction ships as internal v1.4.6 /
Portable_BOS_v1.46.zip, and the No-Suffix Corrective Release Rule was promoted
into BOS_RELEASE_NAMING_STANDARD.md. The first v1.45 ZIP was never accepted and
is superseded.

## Permanent Lesson

```text
Existence checks are not content checks. A verifier that only tests file
presence cannot catch stale or corrupted content; checksums can. And any
value maintained by hand in more than one place (version headers, registry
copies) will eventually drift - eliminate the duplication or verify it
mechanically.
```

---

# Version v1.4.6

Date: 2026-07-04  
External package: `Portable_BOS_v1.46.zip`  
Internal package version: `1.4.6`

## Reason For Update

Corrective release. The first v1.4.5 package failed Barry's on-machine verification with a stale required-entry in VERIFY_BOS_PACKAGE.ps1. Barry rejected an AI-proposed "_REPACK" corrective package name as a Release Naming Standard violation: corrective releases must advance to the next PATCH version, never reuse a name or add a suffix.

## Key Changes

```text
1. Full v1.4.5 scope carried forward and accepted (W1-W7).
2. VERIFY_BOS_PACKAGE.ps1 stale required-entry fixed (file named by the
   failing verification line).
3. F011 promoted to FAILURE_LIBRARY.md: assert every scripted replacement,
   re-scan for stale version strings after edits, and verification emulations
   must parse the real script rather than a parallel hand-written list.
4. No-Suffix Corrective Release Rule promoted into
   BOS_RELEASE_NAMING_STANDARD.md.
5. All dated files re-issued as v1.4.6; v1.4.5 dated files archived;
   PATCH_MANIFEST_v1.4.5.md retained at root as historical record.
6. PACKAGE_CHECKSUMS.txt regenerated.
7. Simple activation preserved. No user project folders touched.
```

## Integrity Result

```text
PASS - source verification (parsing the real verify script), checksum
verification, and clean ZIP extraction verification completed.
```

## Rollback Version

```text
Portable_BOS_v1.44.zip / internal v1.4.4 package
(last release verified on Barry's machine)
```

## Permanent Lesson

```text
A corrective release is a new version, not a renamed file. Suffixes like
REPACK create two active names for one release role and recreate the exact
wrong-file-pointer failure the Naming Standard exists to prevent. And the
verifier of record is the shipped script itself - build-side checks must
parse it, never mirror it by hand.
```

---

# Version v1.4.7

Date: 2026-07-04  
External package: `Portable_BOS_v1.47.zip`  
Internal package version: `1.4.7`

## Reason For Update

Barry uploaded an external review of the delivered v1.4.6 ZIP that found present-tense drift: PROJECT_STATE.md still claimed the v1.4.2 VERIFIED zip as the Current Active Package, and other body sections described v1.4.2 as current, while the header said v1.4.6. Root cause: releases (including the AI's own v1.4.5-v1.4.6 work) updated headers and appended checkpoints without re-reading present-tense body claims.

## Key Changes

```text
1. PROJECT_STATE.md: Current Active Package now single-sourced to the registry
   PACKAGE_NAME; v1.4.2 narrative re-labelled Historical; capability level and
   activation test made version-agnostic.
2. WORKFLOW.md Level 3.5 de-versioned (version lives in VERSION.txt).
3. ROLLBACK_POLICY.md: current rollback target defers to the active patch
   manifest; v1.4.0 block labelled a historical example.
4. VERIFY_BOS_PACKAGE.ps1: Present-Tense Drift check added — PROJECT_STATE.md
   must name the current PACKAGE_NAME and must not name an old VERIFIED zip.
5. F012 promoted to FAILURE_LIBRARY.md.
6. Dated files re-issued as v1.4.7; v1.4.6 dated files archived; checksums
   regenerated. Simple activation preserved. No user project folders touched.
```

## Integrity Result

```text
PASS - source verification (parsing the real verify script including the new
drift guard), checksum verification, and clean ZIP extraction verification.
```

## Rollback Version

```text
Portable_BOS_v1.46.zip / internal v1.4.6 package
```

## Permanent Lesson

```text
Appending history is not updating state. Every release must re-read
present-tense claims, not only bump headers - and the highest-value claim
must be checked by the verifier, not by discipline alone.
```

---

# Version v1.4.8

Date: 2026-07-04  
External package: `Portable_BOS_v1.48.zip`  
Internal package version: `1.4.8`

## Reason For Update

Barry approved seven developing-procedure improvements ("Efficient Block Round Rules") after observing that one HomeVisualizer block could cost 4-5 download/install/debug cycles and that he was effectively the first real tester of every package.

## Key Changes

```text
1. Added BOS_version_1.4/02_ENGINEERING/EFFICIENT_BLOCK_ROUND_RULES.md:
   R1 Pre-Delivery Execution Gate; R2 Clean-Extract Package Test Gate
   (restated from v1.4.3); R3 DOM Smoke Gate; R4 Screenshot-First Layout
   Protocol; R5 Two-Strike Diagnosis Rule; R6 Debug Loop vs Release Loop
   Rule; R7 Optional Local AI Coding Mode with CLAUDE.md skeleton.
2. Registered the module (both registries, activation load order, core
   manifest, verify script required list).
3. Block Format extended with PRE-DELIVERY EXECUTION RESULT.
4. Dated files re-issued as v1.4.8; v1.4.7 dated files archived; checksums
   regenerated. v1.4.7 was released but never installed by Barry; installing
   v1.4.8 covers the v1.4.7 drift correction and this release.
5. Simple activation preserved. No user project folders touched.
6. Build note: the F012 drift guard caught an incomplete edit during this
   release build (PROJECT_STATE not yet naming v1.4.8) and blocked
   verification until corrected - the guard works.
```

## Integrity Result

```text
PASS - source verification (parsing the real verify script), checksum
verification, drift guard, and clean ZIP extraction verification.
```

## Rollback Version

```text
Barry-designated rollback target: Portable_BOS_v1.44.zip.
Nearest machine-verified intermediate: Portable_BOS_v1.46.zip.
```

## Permanent Lesson

```text
The user's round is the most expensive resource in the loop. Every check
the AI can execute before delivery is a round the user does not pay for.
```


---

# Version v1.4.9

Date: 2026-07-04  
External package: `Portable_BOS_v1.49.zip`  
Internal package version: `1.4.9`

## Reason For Update

Barry directed the Incubator to serve universal project planning with
daily-use basics planned before build (HomeVisualizer display/size and
DocAgent font/folder/redo cases), an office-document domain extension
with litigation/financial advisories (DocAgent / IntelliDoc Advisor
line), standing delivery defaults (the C:\BOS\By chatgpt case), and
the proven 12-section block delivery procedure (HomeVisualizer Block 37
reference) as a BOS-wide standard.

## Key Changes

```text
1. Added 06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md; Incubator gains
   mandatory Step 12B gate (every item INCLUDED / DEFERRED / N-A).
2. Added 08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md;
   DOMAIN_EXTENSION_INDEX.md gains a loading rule.
3. Added 03_INTELLIGENCE/DELIVERY_PROFILE.md; Incubator Step 12 states
   its defaults as assumptions instead of re-asking Barry.
4. Added 02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md: 12-section block
   delivery contract with standard auto-locate install batch (checks
   C:\BOS\By chatgpt first, then Downloads/Desktop/OneDrive, copies in).
5. Five module IDs registered (both registries); activation load order,
   core manifest, and verify script required list extended; verify
   script gains four manifest gates; drift guard advanced to v1.4.8.
6. Dated files re-issued as v1.4.9; v1.4.8 dated files archived;
   checksums regenerated.
7. Simple activation preserved. No user project folders touched.
```

## Integrity Result

```text
PASS - emulated verification parsing the real verify script (required
list, registry paths and identity, journal, naming, drift guard, four
new manifest gates, checksums, PROJECT_STATE drift), plus clean ZIP
extraction re-verification. Confirming Windows run by Barry pending.
```

## Rollback Version

```text
Rollback target: Portable_BOS_v1.48.zip (machine-verified, installed
by Barry).
```

## Permanent Lesson

```text
A basic control the user has to request twice is a planning defect.
Daily-use basics and delivery defaults belong to the plan, not to the
user's testing rounds.
```
