# PATCH_MANIFEST_TEMPLATE.md

## Patch Identity

```text
Patch / Version:
External ZIP name:
Internal version:
Date:
Rollback target:
```

## Reason For Patch

```text
Describe the problem and why this is a controlled patch.
```

## Files Added

```text
- path/to/new_file.md
```

## Files Changed

```text
- path/to/changed_file.md
```

## Files Archived

```text
- old/path -> archive/path
```

## Files Removed From Active Role

```text
- path/no_longer_active.md
```

## Registry / Manifest Impact

```text
MODULE_REGISTRY.md updated: yes/no
BOS_ACTIVATION_MANIFEST.md updated: yes/no
BOS_version_1.4/MANIFEST.md updated: yes/no
```

## Verification Plan

```text
1. Run source verification.
2. Check file completeness.
3. Extract ZIP into clean temp folder.
4. Run verification from extracted folder.
5. Generate SHA256.
```

## Expected Result

```text
PACKAGE VERIFICATION PASSED
BOS UPGRADE MANAGER PASSED
Clean ZIP extraction verification passed
```

## User Content Survival Check

```text
Does the patch touch user project folders? yes/no
If yes, backup and skip/overwrite rules:
```
