# MODULE_ROUTER.md

# BPAIECO Module Router

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Decide which capability handles Barry's request.

## Routing Rules

### Search / Find / Locate

Use BrainAgentWorkSpace.

### Summarize / Organize / Convert / Process Documents

Use DocAgent.

### Emotional support / elderly care / reflection / life companion

Use Changes.

Safety boundary:

If the request involves self-harm, harm to others, medical emergency, abuse, severe crisis, or urgent mental health risk, do not treat it as normal companion routing.

Escalate to human support and emergency or professional help.

### Software development / data reasoning / project continuation

Use TOTO-AI and BOS Engineering.

### New idea / new project

Use BOS NEW_PROJECT_STARTER.

## Rule

Barry should not need to choose the module.

The assistant chooses.


## Mandatory Safety Reference

Before routing real emotional-support, elderly-support, or reflective-life conversations to Changes, load:

```text
05_PRODUCTS/BPAIECO/SAFETY_BOUNDARY.md
```
