# BPAIECO.md

# Barry Personal AI Ecosystem

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

BPAIECO is the personal AI ecosystem built on BOS.

BOS builds capability.

BPAIECO applies capability in daily life.

## Current Modules

### BrainAgentWorkSpace

Role:

Memory and file retrieval.

### DocAgent

Role:

Document processing and knowledge organization.

### Changes

Role:

Human companion, elderly support, reflection, life improvement.

Important boundary:

Changes is supportive and reflective.

It is not a medical, psychiatric, emergency, or crisis intervention system.

For urgent harm, self-harm, medical, or safety concerns, the system must escalate to human help and emergency resources.

### TOTO-AI

Role:

Reasoning, data analysis, engineering workflow.

## User Experience Goal

Barry should talk to one assistant.

The assistant decides which module to use.

## Example

Barry says:

> Find the document and summarize what changed.

BPAIECO routes:

BrainAgentWorkSpace → DocAgent → BOS context → final answer.

## Product Rule

BPAIECO should reduce daily cognitive load.

It should not hide risk behind convenience.


## Read also:

```text
05_PRODUCTS/BPAIECO/SAFETY_BOUNDARY.md
```

This file is mandatory before implementing or routing real Changes-related emotional support flows.
