# MARKDOWN_STANDARD.md

# BOS Markdown Standard

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Rules

1. One file, one responsibility.
2. Every file must stand alone.
3. Use simple headings.
4. Write for human and AI readers.
5. Prefer operational rules over vague inspiration.
6. Do not put package version numbers in individual module files; VERSION.txt is the single version source (rule updated in v1.4.5).
7. Keep project-specific content out of BOS core.
8. Promote reusable project lessons into BOS.
9. Avoid duplicate canonical fields across multiple files.

## Required Header

```text
# FILE_NAME.md

# Title
```

## Version Header Rule (v1.4.5)

Per-file package version headers are retired. They drifted every release
because they were hand-maintained in dozens of places.

```text
1. VERSION.txt is the single source of the package version.
2. Module files must not carry "Version: 1.x.y" package headers.
3. A file MAY carry "Last materially changed: v1.x.y" but only when its
   content actually changes, and the release patch must update it.
4. Dated release files (menu book, integrity map/report, patch manifest,
   gateway notice, verifier scope, completion report) keep versioned
   FILENAMES — that is release identity, not a per-file header.
5. Document-internal versions for self-versioned procedures (for example
   IDEA_INCUBATOR_v1.1.md) are allowed; they version the procedure, not
   the package.
```
