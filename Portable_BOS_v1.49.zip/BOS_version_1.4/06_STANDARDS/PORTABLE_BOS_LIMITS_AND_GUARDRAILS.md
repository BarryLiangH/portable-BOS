# PORTABLE_BOS_LIMITS_AND_GUARDRAILS.md

# Portable BOS Limits and Guardrails
## Honest Review of the Portable BOS Idea

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)
---

# 1. Purpose

Portable BOS is useful, but it has limits.

This file records the disadvantages and protection rules so future AI assistants do not over-trust the package.

Portable BOS should be treated as:

```text
A reusable AI operating protocol + project-starting harness
```

not as:

```text
A fully autonomous software factory
```

---

# 2. Main Disadvantages

## D001 — Version Drift

If Barry keeps several ZIP files, different AIs may load different BOS versions.

Risk:

```text
AI A uses BOS version 1.3
AI B uses BOS version 1.3.1
Barry forgets which one is active
```

Guardrail:

```text
Always use the highest verified package version.
Always check README_START_HERE.md and INTEGRITY_REPORT before starting.
```

---

## D002 — Files Are Portable, But Behavior Is Not Guaranteed

An AI can read the package, but it may still miss intent, skip files, or ignore the block protocol.

Risk:

```text
AI extracts BOS but drifts back to normal chat help.
```

Guardrail:

```text
Every BOS interaction must produce checkable artifacts:
- Project Seed
- Block template
- Verification result
- Promotion decision
- Project-state update
```

---

## D003 — BOS Is Still a Protocol, Not an Engine

The package can initialize structure and rules, but it does not build complete systems by itself.

Risk:

```text
Barry expects one idea to become a finished product automatically.
```

Guardrail:

```text
BOS v1.4.2 is Level 3.5 / Level 4 Candidate.
It supports structured protocol activation, Incubator v1.1, Governance, Memory readiness, Upgrade System, and Gateway Safety Patch.
It is not yet a fully autonomous Level 4 software factory.
```

---

## D004 — Executable Scripts Are the Highest-Risk Layer

The PowerShell boot script is the only executable part of the package.

Risk:

```text
A script bug can create wrong folders, nested folders, overwritten files, or confusing state.
```

Guardrail:

```text
Boot scripts must be readable, re-run safe, backed up, and verified.
Avoid giant here-string copy-paste scripts in chat.
```

---

## D005 — Windows Path Assumption

The current boot script assumes Windows and `C:\BOS`.

Risk:

```text
The portable package is not fully cross-platform yet.
```

Guardrail:

```text
Mark Windows as the current supported boot environment.
Future versions may add macOS/Linux boot scripts separately.
```

---

## D006 — Universal Core and Barry Experience Pack Are Still Mixed

BOS currently contains both general AI operating rules and Barry-specific lessons.

Risk:

```text
Future projects may inherit rules that are useful for Barry but not universal.
```

Guardrail:

```text
Future BOS version 2 should split:
1. BOS Core
2. Barry Experience Pack
3. Project-specific rules
```

---


## D007 — Gateway Installer Is Optional And Must Not Overwrite User Projects

The simple ZIP activation is the preferred path.

The Gateway installer is only a helper for local installation and project scaffolding.

Risk:

```text
An installer may overwrite existing project README.md or PROJECT_STATE.md, or may use registry paths incorrectly after installation.
```

Guardrail:

```text
Gateway scripts must default to SKIP for existing project files.
If conflicts exist, create a conflict report and require Barry approval before replacement.
Installed registry/path reports must use absolute resolved paths.
```

# 3. Design Direction for Future BOS

The next improvement should not only add more Markdown.

The next improvement should make BOS more executable and more verifiable.

Priority:

```text
1. More checkable artifacts
2. More deterministic scripts
3. Less dependence on AI self-report
4. Clear split between universal BOS and Barry-specific experience
```

---

# 4. One-Sentence Warning

```text
Portable BOS proves the protocol can travel; BOS v2 must reduce how much success depends on the AI choosing to follow the protocol.
```


---

## User Content Survival Guardrail v1.4.2

```text
User content must survive rerun.
```

No activation, gateway, generator, or upgrade rerun may silently overwrite or delete user-created content.
