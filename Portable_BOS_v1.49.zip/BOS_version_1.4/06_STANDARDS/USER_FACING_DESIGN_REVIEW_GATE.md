# USER_FACING_DESIGN_REVIEW_GATE.md

## Origin

Promoted from `docs/BOS_REVISION_BACKLOG.md` during the HomeVisualizer product line, BOS v1.4.4 maintenance checkpoint.

Reason: technical wording such as `Save JSON` and `Load JSON` reached a normal user before it was reviewed from a non-technical perspective. The AI should have caught this before packaging the UI block.

## Purpose

Prevent implementation language, internal error text, and developer-facing terms from reaching end users of any BOS-built product.

## Rule

Before packaging any UI-facing block or patch:

```text
1. Review every user-visible label, button, message, and error string from a non-technical user's perspective.
2. Prefer action/purpose language over implementation language.
3. Hide file formats, code terms, internal system names, and internal identifiers unless the user explicitly needs them.
4. Any raw exception, stack trace, or internal variable name reaching the UI is treated as a regression, not acceptable output.
```

## Examples

```text
Save JSON                              -> Save Design
Load JSON                              -> Open Design
Rejected: roomGeometrySnapshot is not defined -> explain the affected action in
                                           user terms, then fix as a regression
```

## Scope

Applies to any product built or maintained under Portable BOS with a user-facing interface: labels, buttons, tooltips, menu items, status text, and error/rejection messages.

Does not apply to internal logs, developer documentation, patch manifests, or code comments.

## Gate Placement

This is a standards-level gate. It runs alongside, not instead of, existing verification:

```text
- Fast UI Polish Mode blocks: required before packaging.
- Full Safety Mode blocks: required as part of the standard UI review step, in addition to full verification.
```

## Failure Handling

If user-facing wording is found to violate this gate after release, treat it as a hotfix under the standard patch process, not a silent future fix.
