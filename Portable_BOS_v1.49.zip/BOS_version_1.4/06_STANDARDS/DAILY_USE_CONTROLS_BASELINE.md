# DAILY_USE_CONTROLS_BASELINE.md

## Origin

Promoted from Barry's direct review during BOS v1.4.9 planning.

Reason: during HomeVisualizer development, display location, size adjustment,
and empty-area corrections required several manual testing rounds. During
DocAgent development, font size adjustment, folder searching, and redo
function buttons had to be requested by Barry instead of being planned by
the AI. These are daily-use basics, not advanced features. The AI must
cover them in the plan before the first build, so Barry never has to
discover a missing basic control by manual testing.

## Purpose

Define the mandatory set of everyday usability controls that every
BOS-built product plan must answer before it is builder-ready.

This is a planning gate, not a style suggestion.

## Rule

Before any Incubator handoff or Block 1 approval, the plan must answer
every item below with one of exactly three answers:

```text
INCLUDED   - the plan states where and how it appears
DEFERRED   - explicitly out of v0.1 scope, with the version it moves to
N/A        - genuinely not applicable, with a one-line reason
```

A silent or missing answer means the plan is not builder-ready.

## Baseline Checklist

### 1. Text and Readability

```text
1.1 Font size is user-adjustable (or at minimum, chosen for comfortable
    daily reading and stated in the plan).
1.2 No text is clipped, truncated, or overlapped at default window size.
1.3 Language of all user-facing text follows the User-Facing Design
    Review Gate (action language, not implementation language).
```

### 2. Files and Paths

```text
2.1 Anywhere a file or folder path is needed, a Browse button or folder
    picker exists. Typing a raw path must never be the only way.
2.2 Recently used files/folders are offered where repeat use is expected.
2.3 Default output folder is stated in the plan and pre-filled in the UI.
2.4 The user can open the output folder from the app after a result is
    produced (an "open folder" action or equivalent).
```

### 3. Editing Safety

```text
3.1 Any editing surface has Undo and Redo.
3.2 Destructive actions (delete, clear, overwrite) confirm first or are
    undoable.
3.3 Unsaved-work protection exists: warn before close/discard, or
    autosave, and the plan states which one.
```

### 4. Layout and Space

```text
4.1 The Workspace-First Layout Rule applies: the main work result
    dominates; no large unnecessary empty areas.
4.2 The window resizes sanely: the workspace grows, panels stay usable.
4.3 Controls are grouped by task frequency and workflow order, not
    alphabetically and not in the order they were coded.
```

### 5. Feedback and State

```text
5.1 Long operations show progress or at least a busy state.
5.2 Success and failure are both clearly reported in user language.
5.3 The user can always tell what mode/state the app is in.
```

### 6. Session Convenience

```text
6.1 The app remembers reasonable settings between sessions (window
    size, last folder, font size choice) unless the plan states why not.
6.2 Common actions have an obvious one-click path; frequent multi-step
    chores are candidates for a single button.
```

## Output Format

The Incubator (or any planning session) must produce this table in the
plan:

```text
DAILY-USE CONTROLS BASELINE

1.1 Font size            : INCLUDED / DEFERRED to vX / N/A (reason)
1.2 No clipped text      : ...
2.1 Browse buttons       : ...
2.2 Recent items         : ...
2.3 Default output folder: ...
2.4 Open output folder   : ...
3.1 Undo/Redo            : ...
3.2 Destructive confirm  : ...
3.3 Unsaved protection   : ...
4.1 Workspace-first      : ...
4.2 Sane resize          : ...
4.3 Logical grouping     : ...
5.1 Progress feedback    : ...
5.2 Clear success/fail   : ...
5.3 Visible state        : ...
6.1 Remember settings    : ...
6.2 One-click common path: ...
```

## Gate Placement

```text
- Incubator: runs as Step 12B (Daily-Use Controls Baseline Gate) before
  Builder Safety Handoff.
- Existing products: any new UI-facing block must not remove or regress
  a baseline item that was INCLUDED.
- Fast UI Polish Mode blocks: check only the items the block touches.
```

## Relationship To Other Standards

```text
BOS_WORKSPACE_FIRST_LAYOUT_RULE.md  - governs layout priority (item 4.1).
USER_FACING_DESIGN_REVIEW_GATE.md   - governs wording (item 1.3).
This file                           - governs presence of everyday controls.
```

## Failure Handling

If Barry discovers a missing baseline item during his confirming test,
it is treated as a planning failure, not a feature request:

```text
1. Fix as a standard block under the normal patch process.
2. Record the miss in FAILURE_LIBRARY.md if a new pattern is involved.
3. If the same item is missed twice across projects, this file gains a
   new checklist entry or a stronger wording for that item.
```

## Final Rule

```text
Barry should never be the person who discovers a missing Undo button.
Daily-use basics are planned, not patched.
```
