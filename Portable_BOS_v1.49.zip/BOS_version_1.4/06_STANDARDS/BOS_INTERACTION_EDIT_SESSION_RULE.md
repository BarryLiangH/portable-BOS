# BOS Interaction Edit Session Rule

## Purpose

Prevent over-aggressive auto-deselect behaviour after every tiny adjustment.

This rule was created during HomeVisualizer development after discovering that releasing furniture selection after each adjustment was not practical for real design work.

---

## Universal Rule

When a user selects an editable object, the system should enter an **edit session** rather than a one-step action mode.

```text
Select object
→ enter edit session
→ allow multiple related adjustments
→ user explicitly or contextually finishes editing
→ release selection
→ return to ready state
```

---

## Required Behaviour

A selected object should normally remain selected while the user performs a series of related edits such as:

- move,
- resize,
- rotate,
- align,
- rename,
- change property values,
- transfer between containers / rooms / groups,
- fine incremental correction.

The system should release the selection only when the editing session is complete.

---

## Recommended Release Triggers

Adopt one or more of these triggers according to product type:

1. **Done / Finish Editing** button,
2. click empty canvas / background / workspace,
3. `Esc` key,
4. switching to another primary tool or mode,
5. selecting a different object,
6. committing a multi-step workflow that clearly ends the session.

---

## Anti-Pattern To Avoid

Do **not** automatically release the selection after every single small adjustment when real-world usage normally requires multiple consecutive edits.

Example anti-pattern:

```text
select object
move once
selection releases
select object again
move again
selection releases
```

This creates unnecessary repeated work.

---

## Correct Pattern

```text
select object
move
rotate
resize
adjust property
move again
click Done editing
selection releases
```

---

## Why This Matters

This rule improves:

- daily-use speed,
- editing comfort,
- precision adjustment,
- predictable object state,
- reduced re-selection fatigue,
- professional UI behaviour.

---

## Universal Applicability

Use this rule for:

- floor-plan tools,
- diagram editors,
- image editors,
- dashboard builders,
- map tools,
- CAD-like systems,
- slide/layout editors,
- content builders,
- object property editors.

---

## HomeVisualizer Application

For HomeVisualizer:

- furniture remains selected across repeated move / resize / rotate / property edits,
- the user clicks **Done editing** when finished,
- empty canvas / Esc / tool switch can also release selection,
- this keeps furniture editing practical and avoids repeated selection.

---

## BOS Adoption

Adopted into core Portable BOS in v1.4.5 as a universal interaction-design standard (06_STANDARDS). Originally created during HomeVisualizer development.
