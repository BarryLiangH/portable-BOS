# BOS Workspace-First Layout Rule

## Purpose

Ensure visual design, editing, map, CAD, floor-plan, diagram, dashboard, and builder systems give the primary work result the largest and clearest area of the screen.

This rule was created during HomeVisualizer development after several layout attempts left too much empty space and made the 2D design canvas feel secondary.

---

## Universal Rule

For systems where users create, arrange, edit, inspect, or design visual content:

```text
The main work result must dominate the page.
Tools and information panels must support the workspace, not compete with it.
```

---

## Correct Screen Priority

Use this hierarchy:

```text
1. Top: tools / commands / workflow actions
2. Main center or left: large working canvas / result / preview
3. Right or side: properties / measurement / context
4. Secondary area: diagnostics / logs / verification / help
5. Bottom: lightweight notes or collapsible support only
```

---

## Workspace Requirements

The primary workspace should:

- use the largest practical area,
- avoid unnecessary blank zones,
- avoid being pushed far down the page,
- avoid being clipped by container edges,
- align logically with important side panels,
- remain comfortable without browser zoom changes,
- make the user’s actual work easy to see and manipulate.

---

## Tool and Panel Requirements

Tools should be:

- grouped logically,
- compact,
- readable,
- above or beside the work area,
- not scattered randomly,
- not causing excessive vertical scrolling.

Information panels should:

- support the current task,
- stay near the workspace,
- avoid dominating the page,
- be collapsible if secondary,
- not steal space from the main work result.

---

## Diagnostics and Verification Panels

Diagnostics, logs, live checks, and verification panels should not dominate daily-use screens.

They should be:

```text
compact,
collapsible,
scrollable,
or visually secondary.
```

They are support information, not the main work area.

---

## Anti-Patterns To Avoid

Avoid:

- huge empty spaces around the canvas,
- small canvas with large side panels,
- long vertical stacking that requires constant scrolling,
- putting diagnostics where the main work result should be,
- stretching containers without anchoring the actual work result,
- forcing users to use browser zoom for normal operation.

---

## Layout Review Questions

Before shipping a layout block, ask:

```text
Does the main workspace dominate?
Is the user’s actual work result easy to see?
Are tools easy to find?
Are support panels helpful but not overpowering?
Is there unnecessary blank space?
Can the user work without browser zoom adjustment?
Does the layout match real daily use?
```

---

## HomeVisualizer Application

For HomeVisualizer:

- the 2D floor-plan canvas should be the main visual focus,
- tools should stay compact at the top,
- measurement / room properties / furniture properties should support the canvas,
- live checks should be secondary,
- empty space below or beside the canvas should be minimized,
- the drawing should not feel clipped by the canvas edge.

---

## BOS Adoption

Adopted into core Portable BOS in v1.4.5 as a universal UI/layout design standard (06_STANDARDS). Originally created during HomeVisualizer development.
