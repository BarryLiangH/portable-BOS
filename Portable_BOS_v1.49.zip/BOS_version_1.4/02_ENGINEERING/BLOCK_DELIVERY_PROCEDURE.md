# BLOCK_DELIVERY_PROCEDURE.md

## Origin

Promoted in BOS v1.4.9 from the working HomeVisualizer block procedure
(reference example: Block 37, "3D Preview Shell Foundation"). Barry
requested this become a BOS standard so every AI delivers blocks the
same way and his file drag-and-copy time is removed.

## Purpose

Define the standard block delivery format and the standard auto-locate
install batch, so that:

```text
1. Every block from any AI arrives in the same 12-section shape.
2. Barry's only manual steps are: download ZIP, copy-run one batch,
   paste back the result. No manual file moving.
```

## The 12-Section Block Delivery Format

Every delivered block must contain, in this order:

```text
 1. Block completed sentence
    - includes: latest user-confirmed installed block, confirmed
      result pasted by Barry, and the current block number.
 2. Download ZIP + SHA256
    - ZIP file and a .sha256.txt with the hash.
 3. Block title
 4. Purpose
    - what this block adds and where it sits in the roadmap flow.
 5. What changed
    - Updated files list and Added files list, exact paths.
 6. Safety limits
    - explicit list of what this block does NOT touch or change.
 7. Verification completed before delivery
    - AI-side working-folder verification result (command + summary +
      exit code), AND clean-extracted final ZIP verification result.
      (Efficient Block Round Rules R1 and R2.)
 8. Full PowerShell install batch
    - one copy-run block following the Standard Install Batch below.
 9. Expected result
    - the exact success line and expected verification summary.
10. Browser / app check
    - what Barry should see, what must remain unchanged, and any
      access rules (correct port, no file:/// testing, Ctrl+F5).
11. Checkpoint sentence
12. Next approval sentence
    - proposed next block; wait for Barry's approval.
```

A block missing any section is not delivery-ready.

## Standard Install Batch Requirements

The Section 8 batch must implement all of the following, in order:

```text
 1. $ErrorActionPreference = "Stop".
 2. Declare: zip name, zip folder (C:\BOS\By chatgpt), target project
    root, tool paths, timestamp, backup root under C:\BOS\Backups,
    temp extract root.
 3. AUTO-LOCATE ZIP (the drag-and-copy killer):
    a. Ensure C:\BOS\By chatgpt exists (create if missing).
    b. If the ZIP is not already there, search in order:
       - %USERPROFILE%\Downloads
       - %USERPROFILE%\Desktop
       - %USERPROFILE%\OneDrive\Desktop
       - %USERPROFILE%\OneDrive\Downloads
    c. Copy the first match into C:\BOS\By chatgpt and continue.
    d. If still not found, stop with a clear message naming the
       preferred folder.
 4. Precondition checks: target project root exists; required tools
    (for example node.exe) exist. Stop with clear messages otherwise.
 5. Extract to a temp folder and validate the expected top-level
    package folder exists (invalid structure stops the install).
 6. Backup every file that will be overwritten, preserving relative
    paths, into the timestamped backup folder. Backup before install,
    never after.
 7. Install files, creating target directories as needed.
 8. Run the project verification suite; echo full output.
 9. On failure: surface the FIRST FAIL line explicitly and instruct
    Barry to paste it back to the AI. Stop.
10. On success: restart any local server via the project's control
    script, then print:
    - the SUCCESS line with expected verification summary,
    - the URL / app entry point and refresh instruction,
    - the ZIP location,
    - the backup folder path.
```

## Delivery Rules

```text
1. Section 7 must show real executed results, not intentions. An
   unexecuted verification is a missing section (F010, F011).
2. The expected verification summary in Section 9 must equal the
   actual summary from Section 7.
3. Safety limits (Section 6) are checked against Section 5: any file
   changed but not explainable within the block purpose is a stop.
4. Paths in the batch come from 03_INTELLIGENCE/DELIVERY_PROFILE.md.
   Do not re-ask Barry for paths the profile already answers.
5. One block per delivery. No bundled multi-block ZIPs unless Barry
   asked for a package chain explicitly.
```

## Relationship To Other Modules

```text
EFFICIENT_BLOCK_ROUND_RULES.md - gates R1/R2 feed Section 7.
CHECKPOINT.md                  - Section 11 sentence format.
SAFE_FILE_GENERATION_RULES.md  - file writing safety inside the batch.
DELIVERY_PROFILE.md            - canonical paths and delivery defaults.
```

## Final Rule

```text
Barry's manual work per block is: download, copy-run, paste result.
Anything more is a procedure defect, not a user task.
```
