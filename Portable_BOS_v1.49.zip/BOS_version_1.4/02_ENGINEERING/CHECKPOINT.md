# CHECKPOINT.md

# BOS Checkpoint Standard

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Checkpoint prevents project memory loss.

## When To Checkpoint

Create a checkpoint after:

- project seed created
- first working prototype
- major bug fixed
- architecture changed
- new reusable rule discovered
- project paused

## Checkpoint Format

```text
Checkpoint ID:
Date:
Project:
Completed:
Verified:
Files changed:
New lessons:
Promotion completed:
Next step:
Resume instruction:
```

## Resume Rule

A checkpoint is valid only if another AI can continue from it.
