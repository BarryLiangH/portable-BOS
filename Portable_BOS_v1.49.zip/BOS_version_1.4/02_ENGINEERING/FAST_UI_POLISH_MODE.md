# FAST_UI_POLISH_MODE.md

## Origin

Promoted from `docs/BOS_REVISION_BACKLOG.md` during the HomeVisualizer product line, BOS v1.4.4 maintenance checkpoint.

Reason: full regression verification is valuable for geometry, persistence, and data-model changes, but it is unnecessarily heavy for small wording, label, and low-risk layout changes, and slows down legitimate product progress.

## Purpose

Give BOS-built products a lightweight, still-safe path for UI wording, labels, tooltips, and low-risk layout polish, distinct from Full Safety Mode.

## When To Use Fast UI Polish Mode

```text
Use for: wording, labels, tooltips, grouping, spacing, and non-logic display polish.
Do not use for: geometry, data-model, persistence, validation, transform, or any
behavioural/logic change.
```

If a change touches both wording and logic, the block runs under Full Safety Mode.

## Required Steps

```text
1. Backup touched files.
2. Patch only UI-facing files and their targeted tests.
3. Run a syntax check.
4. Run targeted UI wording/layout verification (not the full geometry/data-model suite).
5. Apply the User-Facing Design Review Gate (see 06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md).
6. Browser check.
7. Deliver with the standard block/patch delivery contract: checkpoint sentence and next approval sentence still required.
```

## Explicitly Not Required In This Mode

```text
- Full geometry/data-model regression suite, unless geometry/data/model files were changed.
- Re-verification of subsystems the patch did not touch.
```

## Relationship To Full Safety Mode

Fast UI Polish Mode does not replace Full Safety Mode. It is a narrower, faster lane for a narrower class of change. Any block that is ambiguous between the two defaults to Full Safety Mode.
