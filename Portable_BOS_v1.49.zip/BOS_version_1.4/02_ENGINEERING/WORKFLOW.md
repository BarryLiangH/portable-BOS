# WORKFLOW.md

# BOS Workflow

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Workflow defines how an idea becomes production through BOS.

## Idea-To-Production Workflow

```text
Idea
  ↓
NEW_PROJECT_STARTER
  ↓
Project Seed
  ↓
First Block
  ↓
Implementation
  ↓
Verification
  ↓
Promotion
  ↓
Project State Update
  ↓
Next Block
```

## Development Levels

### Level 1 — Sentence Debugging

Barry explains each error.

Use only during discovery.

### Level 2 — Guided Task

Barry gives one task.

AI implements with frequent confirmation.

### Level 3 — Block Delegation

Barry approves a block.

AI completes it, verifies it, promotes lessons, and reports.

### Level 3.5 — Structured Portable Protocol

Current status (active release version lives in VERSION.txt; do not embed it here).

BOS can activate from ZIP, load registry-based modules, run Incubator v1.1, enforce Governance and Integrity Gates, and manage controlled upgrades.

Gateway installer automation remains optional and cautious.

### Level 4 — Production Loop

BOS generates project structure, blocks, tests, promotion rules, and repeatable delivery.

Target state for future projects:

Level 3 on day one.

Level 4 after BOS matures.
