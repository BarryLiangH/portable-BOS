# SAFE_FILE_GENERATION_RULES.md

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file protects Barry's Windows workflow from corrupted file generation and unsafe mixed-language scripts.

## Core Rule

For multi-file projects, do not ask Barry to manually assemble many separate files unless there is no better option.

Preferred output methods:

```text
1. downloadable ZIP package;
2. safe PowerShell generator script;
3. COPY-RUN command with backup and verification.
```

## PowerShell Safety Rules

When generating PowerShell that writes HTML, JavaScript, CSS, JSON, or Markdown:

```text
1. Quote here-strings correctly.
2. Do not allow browser JavaScript to be parsed as PowerShell.
3. Create parent folders before writing files.
4. Use UTF-8 output.
5. Verify every expected file exists.
6. Include a completion report.
7. Never report success before the script has run.
```

## Required Verification

After file generation, verify:

```text
1. folder exists;
2. expected files exist;
3. file sizes are non-zero;
4. syntax check or smoke test is available;
5. rollback or backup exists when overwriting.
```

## Forbidden

```text
Do not claim local file creation from a text-only chat.
Do not claim tests passed without output.
Do not dump unescaped multi-language code into unsafe scripts.
```


## Gateway Installer File Safety

Gateway scripts must not silently overwrite existing project files.

For existing project files, default behavior is:

```text
1. SKIP existing file;
2. record the skipped file in a conflict report;
3. create backup only when a write is explicitly approved;
4. never replace README.md or PROJECT_STATE.md without Barry approval.
```

## Registry Installation Safety

Package `MODULE_REGISTRY.md` is package-root relative.

When installing BOS to another root, the installer must create an installed path report or installed registry using absolute resolved paths.

Do not rely on package-relative registry paths after installation.

---
## User Content Survival Rule v1.4.2

For every file-generation method, including ZIP packages, PowerShell generators, project scaffolding, and upgrade scripts:

```text
1. Do not silently overwrite existing user files.
2. Detect existing files first.
3. Default to SKIP.
4. Create timestamped backups before approved overwrite.
5. Record skipped, created, backed-up, overwritten, and failed files in a report.
6. Never treat rerun as permission to replace user work.
```

This rule applies to all project content, not only README.md and PROJECT_STATE.md.
---

## Package QA Rule v1.4.3

When generating a deliverable ZIP, verify the ZIP itself, not only the source workspace.

```text
Source passes + ZIP extracted cleanly + verification passes from extracted ZIP = deliverable allowed.
```
