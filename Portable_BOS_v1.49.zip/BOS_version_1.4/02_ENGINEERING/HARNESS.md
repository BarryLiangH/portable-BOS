# HARNESS.md

# BOS Harness

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Harness protects BOS from AI drift, repeated failure, unsafe changes, and false completion.

## Core Rules

1. Load OWNER.md, VISION.md, PROJECT_STATE.md, and relevant starter files first.
2. Do not start coding before defining the block.
3. Do not exceed the 3-Strike Rule.
4. Do not overwrite without backup or explicit approval.
5. Do not silently skip verification.
6. Do not call a project done unless DONE WHEN is satisfied.
7. Promote reusable lessons before closing a block.
8. Do not route emotional support modules without safety boundaries.

## Human Approval Required

- mission change
- major architecture change
- deleting files
- changing project name
- changing target classification
- adding risky dependencies
- changing safety boundaries for Changes or health-related modules

## AI Must Stop When

- same error repeats
- scope expands uncontrollably
- verification cannot be run
- user goal becomes unclear
- AI is guessing instead of knowing
- user expresses serious self-harm, harm-to-others, or medical emergency content

## BOS Harness Motto

Reliable AI is not created by trust.

Reliable AI is created by constraints plus verification.


## Release Integrity Check

Before releasing any BOS version:

1. Regenerate MANIFEST.md.
2. Confirm MANIFEST.md lists itself.
3. Confirm every listed file exists.
4. Confirm every Markdown file on disk appears in MANIFEST.md.
5. Search for references to missing `.md` files.
6. Fix or explicitly classify every dangling reference before release.

This rule exists because BOS v1.1 restored OWNER.md after a broken reference was discovered.
