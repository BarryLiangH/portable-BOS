# EFFICIENT_BLOCK_ROUND_RULES.md

## Purpose

Reduce the number of download → install → test → feedback rounds per development block. Barry must not be the first real tester of a package, and a single block must not cost 4-5 cycles when the AI is trapped in a wrong hypothesis.

Origin: approved by Barry on 04/07/2026 after the HomeVisualizer Block 28.x layout saga (5 rounds) and the Block 14.2-15 furniture-resize saga (4 rounds).

---

## Rule 1 — Pre-Delivery Execution Gate

No package with an executable test suite is delivered unless the AI has ACTUALLY EXECUTED the suite in its own environment against the assembled package.

```text
1. The delivery must paste the real SUMMARY line and exit code from the
   AI-side execution — never a predicted or claimed result.
2. "My environment cannot run it" is only acceptable when true (e.g. pure
   Windows PowerShell behaviour); in that case the delivery must state
   exactly what was executed, what was emulated, and what remains untested
   on Barry's machine.
3. Emulations must parse the real scripts (F011); parallel hand-written
   copies of test logic are forbidden.
```

Result: Barry's install run becomes a CONFIRMING test, not the first test.

## Rule 2 — Clean-Extract Package Test Gate

Already law since v1.4.3: see `12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md`. Restated here for the block loop: the suite in Rule 1 runs against the CLEAN-EXTRACTED ZIP, not the source folder. Only the extracted-ZIP result counts as release proof.

## Rule 3 — DOM Smoke Gate (browser apps)

For any block touching a browser application's HTML/JS, before delivery the AI must additionally run a DOM-level smoke check (e.g. jsdom) against the packaged files:

```text
1. The page parses without error.
2. Scripts load without throwing.
3. Expected key elements exist (toolbar buttons, canvas/SVG layers,
   panels named in the block's DONE WHEN).
```

Honest limit: DOM smoke checks parse and structure, not rendered pixels. Visual layout quality still requires Barry's eyes — that is what Rule 4 is for.

## Rule 4 — Screenshot-First Layout Protocol

For any layout / visual-design block:

```text
1. BEFORE building: Barry pastes a screenshot of the current state; the AI
   must restate in words what it sees and what will change, and get
   confirmation before packaging.
2. AFTER installing: Barry pastes the after-screenshot; the block is not
   closed on text descriptions of visual results.
3. Text descriptions of layout problems are treated as low-bandwidth
   evidence; a screenshot outranks them.
```

One screenshot replaces multiple "the canvas still feels short" rounds.

## Rule 5 — Two-Strike Diagnosis Rule

Tightens the 3-Strike Rule for the block loop, where every strike costs Barry a full round:

```text
After 2 failed rounds on the SAME symptom, the next delivery must be a
DIAGNOSIS BLOCK, not another fix attempt. A diagnosis block contains:
1. the competing hypotheses, stated plainly;
2. what evidence would distinguish them;
3. ONE targeted request to Barry (a console output, a computed style,
   a screenshot, a specific test result) — not another package.
Fix attempt #3 is only permitted after the evidence arrives.
```

Case study: Blocks 14.2-14.5 patched the same symptom four times; the Block 15 split-layer architecture would have arrived two rounds earlier under this rule.

## Rule 6 — Debug Loop vs Release Loop Rule

The two loops are different procedures and must not be mixed:

```text
DEBUG LOOP (inside a block): fastest safe iteration. Local AI coding mode
(Rule 7) if available; otherwise smallest possible targeted hotfix packages.
No ceremony beyond backup + targeted verification.

RELEASE LOOP (block completion): full BOS discipline — package, manifest,
checksums, clean-extract verification, install batch, checkpoint sentence,
next approval sentence. Every completed block still produces a verified ZIP
checkpoint for records, rollback, and cross-AI portability.
```

Rule: iteration speed must never erode release discipline, and release ceremony must never slow down iteration.

## Rule 7 — Optional Local AI Coding Mode

When a local AI coding agent is available on Barry's machine (Claude Code in VS Code / terminal, or an equivalent agent), the DEBUG LOOP may run locally:

```text
1. The agent edits the canonical project folder directly
   (e.g. C:\Apps\HomeVisualizer), runs the verification suite itself,
   and restarts the local server itself; Barry only refreshes the browser.
2. BOS discipline is carried into the agent via a project rules file
   (CLAUDE.md or equivalent) containing at minimum: the block approval rule,
   backup-before-overwrite, the verification command and expected SUMMARY,
   the canonical paths and prohibited routes, the Design Review Gate, and
   the Two-Strike Diagnosis Rule.
3. Local mode is OPTIONAL and per-block: Barry chooses it when approving
   the block. Chat+ZIP remains the default and is always used for the
   RELEASE LOOP checkpoint at block completion.
4. The local agent must never modify BOS package folders — BOS upgrades
   always go through the Upgrade System.
```

### Minimal CLAUDE.md skeleton for local mode

```text
# Project rules (BOS-derived)
- No coding until the current block is stated and approved by Barry.
- Backup any file before overwrite (timestamped folder under archive\).
- Verify with: <node path> .\tests\run_all_verification.js
  Expected: SUMMARY <N>/<N>, exit code 0. Never claim an unrun result.
- Canonical paths: <project path>, server <approved route>.
  Prohibited: <prohibited routes / legacy folders>.
- UI wording passes the User-Facing Design Review Gate before commit.
- After 2 failed attempts on one symptom: stop, state hypotheses,
  ask Barry for one piece of distinguishing evidence.
- At block completion, hand back to the chat Release Loop for the
  verified ZIP checkpoint.
```

---

## Adoption

Adopted into core Portable BOS in v1.4.8. Applies to HomeVisualizer immediately and to all future BOS-governed products from Block 1.
