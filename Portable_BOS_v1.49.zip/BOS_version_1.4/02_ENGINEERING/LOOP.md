# LOOP.md

# BOS Loop

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Inner Loop

For one block:

```text
Understand
  ↓
Execute
  ↓
Verify
  ↓
Promote
  ↓
Report
```

## Outer Loop

For BOS learning:

```text
Project Experience
  ↓
Extract Failure / Success
  ↓
Promote Rule
  ↓
Update BOS
  ↓
Apply To Next Project
```

## Stop Conditions

Stop when:

- done condition met
- verification fails repeatedly
- human approval required
- risk unclear
- loop becomes repetitive

## BOS Loop Principle

A loop is successful only if it either completes work or improves BOS.
