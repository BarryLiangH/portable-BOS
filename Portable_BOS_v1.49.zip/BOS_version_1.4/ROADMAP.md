# ROADMAP.md

# Portable BOS Roadmap

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)
Last Updated: 2026-06-29

## v1.2.3

Portable Release.

Main achievement:

- stable Markdown BOS package
- verified file integrity
- boot scripts
- quick start package
- failure/success libraries
- block delegation protocol

## v1.3.0

Gateway Release.

Main achievement:

- one ZIP activation model
- activation manifest
- Incubator Branch
- Memory Branch
- Governance Branch
- BOS Architect & Growth Partner persona
- small PowerShell scripts for activation and package rebuild

## v1.3.1 Target

Test with a real incubator-generated idea.

Expected output:

- activated BOS in a new chat
- Project Seed created
- Block 1 proposed
- no premature coding
- governance classification applied
- memory files prepared

## v1.4 Target

Improve automation:

- stronger load-pack builder
- project-specific handoff zip
- generated project documents
- verification report generator

## v2.0 Target

Executable project generator:

```text
idea.md
  ↓
BOS project generator
  ↓
ready project folder
  ↓
AI load pack
  ↓
verified Block 1
```
