# KNOWLEDGE.md

# BOS Knowledge

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Knowledge is structured experience.

BOS knowledge must be readable by humans and AI.

## Knowledge Flow

```text
Raw Experience
  ↓
Observation
  ↓
Rule
  ↓
Markdown
  ↓
Reusable Capability
```

## Knowledge Quality Test

A knowledge item is useful if it can change the next AI action.

If it does not change action, it is only a note.
