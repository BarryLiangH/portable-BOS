# CONTEXT.md

# BOS Context Strategy

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Context strategy tells AI what to load before acting.

## Minimum BOS Context

For new projects:

1. OWNER.md
2. README.md
3. VISION.md
4. PROJECT_STATE.md
5. 00_BOOTSTRAP/NEW_PROJECT_STARTER.md
6. 01_EXPERIENCE/FAILURE_LIBRARY.md
7. 02_ENGINEERING/HARNESS.md
8. 02_ENGINEERING/WORKFLOW.md

## Rule

Load only what is needed.

More context can cause drift.

## Anti-Drift Recovery

If AI becomes confused:

1. stop
2. reload OWNER.md
3. reload PROJECT_STATE.md
4. reload VISION.md
5. restate current block
6. continue or ask Barry
