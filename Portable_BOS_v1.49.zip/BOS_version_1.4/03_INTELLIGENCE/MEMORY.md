# MEMORY.md

# BOS Memory

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Memory is not just storing facts.

Memory is making past experience useful for future work.

## Memory Types

### Owner Memory

OWNER.md.

Defines Barry's engineering preferences and decision rules.

### Project Memory

PROJECT_STATE.md, checkpoints, journals.

### Failure Memory

FAILURE_LIBRARY.md.

### Success Memory

SUCCESS_LIBRARY.md.

### Product Memory

BPAIECO module documents.

## Rule

Memory must be retrievable at the moment it prevents repeated work.

If a memory does not change future behavior, it is only an archive note.
