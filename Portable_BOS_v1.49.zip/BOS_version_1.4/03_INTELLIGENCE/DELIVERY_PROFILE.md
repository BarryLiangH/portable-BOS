# DELIVERY_PROFILE.md

## Origin

Created in BOS v1.4.9 from a real case: Barry had to tell an AI
mid-project to make the ZIP flow land in `C:\BOS\By chatgpt` so he could
copy-run the install script without manual file moving. The AI should
have applied this before Barry spent a round asking.

## Purpose

Hold Barry's standing delivery and environment defaults in one file, so
every AI states them as assumptions instead of extracting them from
Barry by questions or complaints.

## Rule

```text
Any AI operating under BOS must read this profile before proposing an
Environment Reality Check or a delivery method. The profile is the
default. The AI asks only when a project genuinely needs a different
answer, and records approved changes here.
```

## Standing Defaults

### Platform

```text
OS: Windows 11
Shell: PowerShell (copy-run full batch scripts; batch launcher preferred
       over loose commands due to execution policy history)
Python: system Python 3.13 era; GUI stack customtkinter where used
Node:  C:\Tools\node-v24.18.0-win-x64\node.exe (HomeVisualizer line)
```

### Canonical Paths

```text
BOS package root:        C:\BOS\Portable_BOS
Incoming AI ZIPs:        C:\BOS\By chatgpt
Backups root:            C:\BOS\Backups
HomeVisualizer project:  C:\Apps\HomeVisualizer
```

### Delivery Method

```text
1. Work is delivered as a downloadable ZIP plus a SHA256 checksum file.
2. Install/apply is a single full PowerShell batch Barry copy-runs.
3. The batch must auto-locate the ZIP: check C:\BOS\By chatgpt first,
   then Downloads, Desktop, OneDrive\Downloads, OneDrive\Desktop, and
   copy the found ZIP into C:\BOS\By chatgpt before proceeding.
   (See 02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md.)
4. The batch backs up touched files to a timestamped folder under
   C:\BOS\Backups before overwriting anything.
5. The batch runs verification and stops with the first FAIL line
   surfaced for pasting back to the AI.
```

### Interaction Style

```text
1. Step-by-step with visual confirmation; one block per round.
2. Checkpoint sentence and next-approval sentence end every block.
3. Barry is the confirming tester, never the first tester
   (EFFICIENT_BLOCK_ROUND_RULES.md).
4. No claimed results without proof (checksums, terminal output,
   downloadable files).
```

## Change Rule

```text
This profile changes only by Barry's explicit instruction. When Barry
corrects a delivery detail twice, the correction is promoted into this
file so it never needs a third telling.
```

## Final Rule

```text
Defaults are stated, not asked.
A repeated correction becomes a standing default.
```
