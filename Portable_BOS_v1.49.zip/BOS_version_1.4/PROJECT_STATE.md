# PROJECT_STATE.md

# Portable BOS Project State

Version: 1.4.9 Universal Incubation Upgrade

Last Updated: 2026-07-04

## Current State

Portable BOS v1.4.9 adds the Universal Incubation Upgrade (Daily-Use Controls Baseline, Office Document Processing Extension, Delivery Profile, and Block Delivery Procedure) on top of the v1.4.8 Efficient Block Round Rules, the v1.4.7 present-tense drift correction and v1.4.6, which (as corrective release of the v1.4.5 scope) adds checksum-based content verification, a Core Digest, integrity fixes, and two universal design standards on top of the v1.4.4 User-Facing Design Review Gate + Fast UI Polish Mode, the v1.4.3 Package QA Gate + Release Naming Standard, the v1.4.2 User Content Survival Patch, the v1.4.1 Gateway Safety Patch, and the v1.4.0 Upgrade System.

## Current Active Package

```text
Portable_BOS_v1.49.zip
```

Rule (v1.4.7): this section must always match `PACKAGE_NAME` in MODULE_REGISTRY.md and is mechanically checked by VERIFY_BOS_PACKAGE.ps1. Any release that changes the package name must update this section in the same patch.

## Permanent Main Rule

```text
User content must survive rerun.
```

## Historical: v1.4.2 Release Purpose

The v1.4.2 release protected Barry/user-created content during BOS activation reruns, Gateway installer reruns, project generation, and upgrade workflows.

### What v1.4.2 Corrected

Codex review identified that v1.4.1 protected some project files but did not clearly guarantee that all user-created content survives rerun.

v1.4.2 broadens the protection beyond `README.md` and `PROJECT_STATE.md` to include:

```text
journals
decision logs
user notes
raw ideas
Incubator handoff files
source materials
uploaded blueprints
photos
data files
custom templates
manual edits
generated project work
```

## Current Capability Level

Level 3.5 — Structured Portable Protocol (see VERSION.txt for the active release; capabilities now include the Upgrade System, Gateway Safety, User Content Survival, Package QA Gate, Release Naming Standard, Design Review Gate, Fast UI Polish Mode, Core Digest, per-file checksum verification, and universal design standards).

Level 4 Candidate — not yet a fully autonomous production loop.

Reason:

```text
The workflow, Incubator, block system, architecture gates, verification rules, Memory Branch, Governance Branch, Upgrade System, and the protection gates above are active.

However, the Gateway installer remains optional and cautious, the Project Generator is still documentation/procedure rather than a complete executable generator, and deep Markdown contradiction/reference verification is only partially automated (checksums and the Current Active Package check are mechanical; full present-tense contradiction scanning is not).
```

## Active Branches

```text
1. Core BOS
2. Incubator Branch
3. Memory Branch
4. Governance Branch
5. User Content Survival protection
6. Persona Branch
7. Upgrade System Branch
```

## Active Incubator

```text
08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Do Not Change Without Approval

```text
1. Simple activation command
2. Module Registry structure
3. Active Incubator path
4. Upgrade Journal requirement
5. Integrity verification requirement
6. User Content Survival rule
7. Owner approval rule
```

## Standard Activation Test (version-agnostic)

1. Upload the current release ZIP named in `## Current Active Package` above.
2. Say: `I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.`
3. Confirm activation states the version recorded in VERSION.txt.
4. Confirm it asks for Incubator idea / Project Seed.
5. Confirm it does not code before Block 1 approval.
6. Confirm any rerun/project generation action defaults to SKIP existing user files.
---

## Checkpoint: Portable BOS v1.4.3 Package QA Gate + Release Naming Standard

Date: 2026-07-02

External release name:

```text
Portable_BOS_v1.43.zip
```

Internal version:

```text
1.4.3
```

Reason:
HomeVisualizer Block 16.1C showed that package verification must check the delivered ZIP, not only source files. Naming also needed formal protection to avoid slow reference drift.

Key lessons:

```text
1. Simple outside, detailed inside.
2. Package is not complete until clean-install simulation passes.
3. Tests should verify behavior, not stale implementation details.
4. Runner-required files must be included in the ZIP.
5. Patch the file named by the failing verification, not a guessed nearby file.
```

---

## Checkpoint: Portable BOS v1.4.4 User-Facing Design Review Gate + Fast UI Polish Mode

Date: 2026-07-03

External release name:

```text
Portable_BOS_v1.44.zip
```

Internal version:

```text
1.4.4
```

Reason:
HomeVisualizer product development recorded two reusable process ideas in `docs/BOS_REVISION_BACKLOG.md` without interrupting active product work. This checkpoint promotes both into core BOS.

Key changes:

```text
1. Added BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md.
2. Added BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md.
3. Updated MODULE_REGISTRY.md (root and 12_UPGRADE_SYSTEM copies), BOS_ACTIVATION_MANIFEST.md,
   BOS_version_1.4/MANIFEST.md, VERSION.txt, README_START_HERE.md, PORTABLE_BOS_SYSTEM_PROMPT.md,
   menu, scripts, and integrity files.
4. Archived v1.4.3 active root release files and dated upgrade-system reports.
5. Preserved simple activation command.
6. Did not touch any HomeVisualizer product files.
```

Deferred to a future checkpoint:

```text
BOS_INTERACTION_EDIT_SESSION_RULE.md and BOS_WORKSPACE_FIRST_LAYOUT_RULE.md, flagged as
universal reusable rules in HOMEVISUALIZER_CREATED_FILES_INDEX.md.
```

---

## Checkpoint: Portable BOS v1.4.5 Integrity, Checksums, Core Digest, Universal Design Rules

Date: 2026-07-04

External release name:

```text
Portable_BOS_v1.45.zip
```

Internal version:

```text
1.4.5
```

Reason:
Barry requested a high-level BOS architecture review; seven findings (W1-W7) were approved as one combined release.

Key changes:

```text
W1. Gate 7 renumber (duplicate Gate 6 fixed).
W2. Per-file version headers retired; VERSION.txt is single version source.
W3. PACKAGE_CHECKSUMS.txt per-file SHA256 verification.
W4. Registry copy identity check.
W5. FAILURE_LIBRARY.md index, entry rules, F010 renumbering.
W6. BOS_CORE_DIGEST.md loaded early at activation.
W7. Interaction Edit Session and Workspace-First Layout rules promoted to 06_STANDARDS.
```

No user project folders touched. Simple activation preserved.


---

## Checkpoint: Portable BOS v1.4.6 Corrective Release

Date: 2026-07-04

External release name:

```text
Portable_BOS_v1.46.zip
```

Internal version:

```text
1.4.6
```

Reason:
The first v1.4.5 package failed Barry's on-machine verification (stale required-entry in VERIFY_BOS_PACKAGE.ps1) and was never accepted. Barry rejected a suffix-named corrective package; per the new No-Suffix Corrective Release Rule, the correction ships as the next PATCH version.

Key changes on top of the v1.4.5 scope:

```text
1. VERIFY_BOS_PACKAGE.ps1 stale required-entry fixed.
2. F011 promoted (Unchecked String Replacement and Emulated Verification Divergence).
3. No-Suffix Corrective Release Rule promoted into BOS_RELEASE_NAMING_STANDARD.md.
4. Build-side verification now parses the real verify script instead of a parallel list.
```


---

## Checkpoint: Portable BOS v1.4.7 Present-Tense Drift Correction

Date: 2026-07-04

External release name:

```text
Portable_BOS_v1.47.zip
```

Internal version:

```text
1.4.7
```

Reason:
An external review of the delivered v1.4.6 ZIP, uploaded by Barry, found that this file still claimed the v1.4.2 VERIFIED zip as the Current Active Package while the header said v1.4.6.

Key changes:

```text
1. Current Active Package single-sourced and mechanically checked by the verifier.
2. v1.4.2 narrative re-labelled Historical; capability level and activation
   test made version-agnostic.
3. WORKFLOW.md and ROLLBACK_POLICY.md de-versioned.
4. F012 promoted (Present-Tense Drift in State Documents).
```


---

## Checkpoint: Portable BOS v1.4.8 Efficient Block Round Rules

Date: 2026-07-04

External release name:

```text
Portable_BOS_v1.48.zip
```

Internal version:

```text
1.4.8
```

Reason:
Barry approved seven developing-procedure rules so he is a confirming tester, not the first tester, and a block cannot silently cost 4-5 download/install/debug cycles.

Key changes:

```text
1. 02_ENGINEERING/EFFICIENT_BLOCK_ROUND_RULES.md added and registered:
   Pre-Delivery Execution Gate, Clean-Extract Package Test Gate (restated),
   DOM Smoke Gate, Screenshot-First Layout Protocol, Two-Strike Diagnosis
   Rule, Debug Loop vs Release Loop Rule, Optional Local AI Coding Mode.
2. Block Format extended with PRE-DELIVERY EXECUTION RESULT.
3. v1.4.7 (drift correction) carried forward; it was released but not
   installed, so installing v1.4.8 covered both.
```

---

## Checkpoint: Portable BOS v1.4.9 Universal Incubation Upgrade

Date: 2026-07-04

External release name:

```text
Portable_BOS_v1.49.zip
```

Internal version:

```text
1.4.9
```

Reason:
Barry directed the Incubator to serve universal project planning with daily-use basics planned before build, an office-document domain extension, standing delivery defaults, and the proven 12-section block delivery procedure as a BOS standard.

Key changes:

```text
1. 06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md added: mandatory
   INCLUDED/DEFERRED/N-A checklist (font size, folder pickers,
   undo/redo, layout, feedback, remembered settings); Incubator gains
   Step 12B gate.
2. 08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md
   added: analysis depth layers, litigation/financial advisory rules,
   bilingual handling, acceptance tests.
3. 03_INTELLIGENCE/DELIVERY_PROFILE.md added: standing environment and
   delivery defaults (C:\BOS\By chatgpt auto-locate, canonical paths).
4. 02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md added: 12-section block
   delivery contract with standard auto-locate install batch
   (promoted from HomeVisualizer Block 37 procedure).
5. Incubator Step 12 now reads the Delivery Profile first.
```
