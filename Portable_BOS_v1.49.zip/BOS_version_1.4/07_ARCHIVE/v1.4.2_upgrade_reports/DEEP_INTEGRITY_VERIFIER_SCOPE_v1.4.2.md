# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.2.md

## Purpose

Defines the deep integrity checks required for Portable BOS v1.4.2 User Content Survival Patch.

## Required Checks

```text
1. Simple activation command is unchanged.
2. VERSION.txt says v1.4.2.
3. MODULE_REGISTRY.md says v1.4.2.
4. BOS_ACTIVATION_MANIFEST.md says v1.4.2.
5. BOS_UPGRADE_JOURNAL.md contains a v1.4.2 entry.
6. USER_CONTENT_SURVIVAL_RULES.md exists.
7. MODULE_REGISTRY.md registers USER_CONTENT_SURVIVAL_RULES.md.
8. Activation Manifest loads USER_CONTENT_SURVIVAL_RULES.md.
9. SAFE_FILE_GENERATION_RULES.md references User Content Survival.
10. CORE_CHANGE_CONTROL.md references User Content Survival.
11. PATCH_APPLICATION_RULES.md references User Content Survival.
12. Gateway scripts default to SKIP existing project files.
13. Gateway scripts create conflict/rerun reports.
14. No active registry path points to archive.
15. Every active registry path exists.
```

## Verification Meaning

A package is not verified if it protects BOS files but risks destroying user project content.

## Final Rule

```text
User content must survive rerun.
```
