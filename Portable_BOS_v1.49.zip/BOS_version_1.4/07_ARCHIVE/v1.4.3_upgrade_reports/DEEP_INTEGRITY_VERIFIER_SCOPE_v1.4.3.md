# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.3.md

## Scope

The v1.4.3 verifier must check:

```text
1. all active registry paths exist;
2. simple activation command is unchanged;
3. BOS_UPGRADE_JOURNAL.md contains v1.4.3;
4. root active versioned files use v1.4.3;
5. old v1.4.2 root release files are archived, not active;
6. BOS_RELEASE_NAMING_STANDARD.md exists and is registered;
7. BOS_PACKAGE_QA_GATE.md exists and is registered;
8. PATCH_MANIFEST_TEMPLATE.md exists;
9. PATCH_MANIFEST_v1.4.3.md exists;
10. clean-install simulation rule is present;
11. optional domain extension index is present;
12. User Content Survival remains registered and loaded.
```
