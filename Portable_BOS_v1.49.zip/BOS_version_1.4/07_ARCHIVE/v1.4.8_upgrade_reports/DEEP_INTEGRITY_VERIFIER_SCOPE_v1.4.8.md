# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.8.md

## Scope

The v1.4.8 verifier must check:

```text
1. all active registry paths exist;
2. simple activation command is unchanged;
3. BOS_UPGRADE_JOURNAL.md contains v1.4.8;
4. root active versioned files use v1.4.8;
5. v1.4.7 dated files are archived, not active;
6. both MODULE_REGISTRY.md copies are byte-identical;
7. PACKAGE_CHECKSUMS.txt: every listed file exists and matches its SHA256;
8. PROJECT_STATE.md Current Active Package matches registry PACKAGE_NAME
   and names no old VERIFIED zip;
9. EFFICIENT_BLOCK_ROUND_RULES.md is registered and in the load order;
10. the verify script's own required list contains no prior-version entries;
11. PATCH_MANIFEST_v1.4.8.md exists;
12. clean-install simulation passes from the ZIP.
```
