# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.6.md

## Scope

The v1.4.6 verifier must check:

```text
1. all active registry paths exist;
2. simple activation command is unchanged;
3. BOS_UPGRADE_JOURNAL.md contains v1.4.6;
4. root active versioned files use v1.4.6;
5. v1.4.4 and v1.4.5 dated files are archived, not active;
6. both MODULE_REGISTRY.md copies are byte-identical;
7. PACKAGE_CHECKSUMS.txt exists, is non-empty, and every listed file exists
   and matches its SHA256;
8. the verify script's own required list contains no prior-version dated
   entries (the exact failure class of the rejected first v1.4.5 package);
9. BOS_CORE_DIGEST.md, both universal design rules, the Design Review Gate,
   and Fast UI Polish Mode are registered and loaded;
10. BOS_INTEGRITY_GATES.md contains Gate 7 and no duplicate gate numbers;
11. no active module file carries a stale per-file package version header;
12. the No-Suffix Corrective Release Rule is present in the Naming Standard;
13. PATCH_MANIFEST_v1.4.6.md exists;
14. clean-install simulation rule is present;
15. User Content Survival remains registered and loaded.
```
