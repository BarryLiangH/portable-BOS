# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.1.md

## Purpose

This file defines the integrity checks that must be added before BOS can be considered a fully mature Level 4 package.

The current verifier checks required files and active registry paths.

It does not yet fully prove every Markdown reference, maturity statement, archive heading, or contradiction.

## Current Verified Scope

```text
1. Required root files exist.
2. Required core files exist.
3. Registered active paths exist.
4. Upgrade journal contains the current version.
5. Active Incubator is not a legacy file.
6. Simple activation text is preserved.
```

## Known Gaps

```text
1. Markdown cross-reference validation is partial.
2. Contradiction detection is not fully automated.
3. Archive headings may contain older or confusing version labels.
4. Maturity statements must be manually checked.
5. Gateway installer behavior must be reviewed when scripts change.
```

## Future Deep Verifier Requirements

A future deep verifier should check:

```text
1. all registered files exist;
2. all file references inside active Markdown files exist;
3. active files do not point to archived files as current;
4. version labels agree across VERSION.txt, registry, manifest, menu, journal, and integrity report;
5. maturity level is consistent;
6. no active instruction contradicts simple activation;
7. no script overwrites user project files without skip/backup behavior;
8. installed registry paths are absolute when installed outside the ZIP root.
```

## Level 4 Rule

Portable BOS cannot be called true Level 4 until deep reference and contradiction verification are automated or reliably enforced by a repeatable review process.
