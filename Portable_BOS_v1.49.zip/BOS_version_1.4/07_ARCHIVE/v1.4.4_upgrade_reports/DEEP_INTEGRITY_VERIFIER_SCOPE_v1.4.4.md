# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.4.md

## Scope

The v1.4.4 verifier must check:

```text
1. all active registry paths exist;
2. simple activation command is unchanged;
3. BOS_UPGRADE_JOURNAL.md contains v1.4.4;
4. root active versioned files use v1.4.4;
5. old v1.4.3 root release files are archived, not active;
6. old v1.4.3 upgrade-system dated reports are archived, not active;
7. BOS_RELEASE_NAMING_STANDARD.md exists and is registered;
8. BOS_PACKAGE_QA_GATE.md exists and is registered;
9. USER_FACING_DESIGN_REVIEW_GATE.md exists and is registered;
10. FAST_UI_POLISH_MODE.md exists and is registered;
11. PATCH_MANIFEST_TEMPLATE.md exists;
12. PATCH_MANIFEST_v1.4.4.md exists;
13. clean-install simulation rule is present;
14. optional domain extension index is present;
15. User Content Survival remains registered and loaded.
```
