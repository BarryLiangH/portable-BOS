# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.7.md

## Scope

The v1.4.7 verifier must check:

```text
1. all active registry paths exist;
2. simple activation command is unchanged;
3. BOS_UPGRADE_JOURNAL.md contains v1.4.7;
4. root active versioned files use v1.4.7;
5. v1.4.6 dated files are archived, not active;
6. both MODULE_REGISTRY.md copies are byte-identical;
7. PACKAGE_CHECKSUMS.txt: every listed file exists and matches its SHA256;
8. PROJECT_STATE.md Current Active Package matches registry PACKAGE_NAME;
9. PROJECT_STATE.md Current Active Package names no old VERIFIED zip;
10. the verify script's own required list contains no prior-version entries;
11. all prior gates and rules remain registered and loaded;
12. PATCH_MANIFEST_v1.4.7.md exists;
13. clean-install simulation passes from the ZIP.
```
