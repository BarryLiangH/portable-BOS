# DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.5.md

## Scope

The v1.4.5 verifier must check:

```text
1. all active registry paths exist;
2. simple activation command is unchanged;
3. BOS_UPGRADE_JOURNAL.md contains v1.4.5;
4. root active versioned files use v1.4.5;
5. old v1.4.4 root release files and dated reports are archived, not active;
6. both MODULE_REGISTRY.md copies are byte-identical;
7. PACKAGE_CHECKSUMS.txt exists, is non-empty, and every listed file exists
   and matches its SHA256;
8. BOS_CORE_DIGEST.md exists and is registered and loaded early;
9. BOS_INTERACTION_EDIT_SESSION_RULE.md and BOS_WORKSPACE_FIRST_LAYOUT_RULE.md
   exist in 06_STANDARDS and are registered;
10. USER_FACING_DESIGN_REVIEW_GATE.md and FAST_UI_POLISH_MODE.md remain
    registered and loaded;
11. BOS_INTEGRITY_GATES.md contains Gate 7 (User Content Survival) and no
    duplicate gate numbers;
12. no active module file carries a stale per-file package version header;
13. PATCH_MANIFEST_v1.4.5.md exists;
14. clean-install simulation rule is present;
15. User Content Survival remains registered and loaded.
```
