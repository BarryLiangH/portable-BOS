# SUCCESS_LIBRARY.md

# BOS Success Library

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Failure rules prevent repeated mistakes.

Success rules preserve what worked.

## Rule Format

```text
ID:
Success Pattern:
Why It Worked:
Reuse Condition:
Source Project:
```

---

## S001 — Markdown-First Development

Success Pattern:

Create project knowledge files before implementation.

Why It Worked:

AI can resume, reason, and continue across chats.

Reuse Condition:

Use for every serious project.

Source Project:

TOTO-AI, DocAgent, BrainAgentWorkSpace, Changes

---

## S002 — Project State Continuity

Success Pattern:

Maintain PROJECT_STATE.md.

Why It Worked:

New AI chats can continue without rediscovering the whole project.

Reuse Condition:

Use for every project longer than one session.

---

## S003 — Block Delegation

Success Pattern:

Give AI a bounded block instead of line-by-line debugging.

Why It Worked:

Barry checks completed results instead of narrating every step.

Reuse Condition:

Use after project seed and rules are loaded.
