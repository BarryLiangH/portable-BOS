# PROMOTION_ENGINE.md

# BOS Promotion Engine

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

Promotion Engine decides how lessons from one project become permanent BOS knowledge.

## Promotion Rule

If a rule would have saved time in a past project or will save time in a future project, promote it into BOS.

## Promotion Timing

Promotion happens inside every block lifecycle.

It is not only an end-of-session ritual.

The required lifecycle is:

```text
Define
  ↓
Execute
  ↓
Verify
  ↓
Promote
  ↓
Report
```

## Promotion Targets

### Failure

Promote to:

```text
01_EXPERIENCE/FAILURE_LIBRARY.md
```

### Success

Promote to:

```text
01_EXPERIENCE/SUCCESS_LIBRARY.md
```

### Workflow

Promote to:

```text
02_ENGINEERING/WORKFLOW.md
```

### Harness Rule

Promote to:

```text
02_ENGINEERING/HARNESS.md
```

### New Project Starter Improvement

Promote to:

```text
00_BOOTSTRAP/NEW_PROJECT_STARTER.md
```

### New Capability

Promote to:

```text
04_FACTORY/PROJECT_GENERATOR.md
```

or capability map.

## Promotion Checklist

- [ ] Is this reusable?
- [ ] Did it cost time to learn?
- [ ] Could future AI repeat the mistake?
- [ ] Can it be expressed as a clear rule?
- [ ] Where should it live?
- [ ] Was PROJECT_STATE.md updated?

## Core Warning

A lesson that is not promoted is a lesson that will be paid for again.
