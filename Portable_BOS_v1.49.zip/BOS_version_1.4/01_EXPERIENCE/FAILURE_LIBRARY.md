# FAILURE_LIBRARY.md

# BOS Failure Library

Version: see VERSION.txt (package-level versioning; per-file version headers were retired in v1.4.5 to prevent drift)

## Purpose

This file stores hard-won failure rules so future projects do not repeat them.

The Failure Library is one of BOS's highest-value assets.

## Rule Format

```text
ID:
Failure:
Trigger:
Avoidance Rule:
Recovery:
Source Project:
Promote To:
```

## Index

```text
F001 — 3-Strike Debugging Failure (repeated same-fix attempts)
F002 — Windows GUI Threading Failure (worker thread touching tkinter UI)
F003 — Windows UTF-8 Output Failure (non-ASCII console corruption)
F004 — Native Drag-and-Drop Dead End (no casual retry without COM IDropTarget plan)
F005 — Missing Output Folder (write assumes folder exists)
F006 — Dangling File Reference After Restructure (rename without reference update)
F007 — PowerShell Copy-Item Folder Nesting When Destination Exists
F008 — Markdown Formatting Breaks Machine-Checkable Manifest Paths (backticked paths)
F009 — Flat Load-Pack Filename Collision (silent overwrite of same leaf name)
F010 — DeepSeek HomeVisualizer Builder Execution Failure (ghost files, fake verification)
F011 — Unchecked String Replacement and Emulated Verification Divergence
F012 — Present-Tense Drift in State Documents (stale "Current" sections)
```

## Entry Rules

```text
1. Every entry gets the next sequential F-number. No unnumbered entries.
2. New entries use the Rule Format above (Failure / Trigger / Avoidance Rule /
   Recovery / Source Project / Promote To). Older entries keep their original
   layout; do not rewrite history.
3. Every new entry must also be added to this Index with a one-line summary.
4. When this file exceeds roughly 25 entries, propose splitting it by domain
   (Windows/PowerShell, packaging, UI, AI-collaboration) at the next BOS
   maintenance checkpoint.
```

---

## F001 — 3-Strike Debugging Failure

Failure:

AI tries small variations of the same fix repeatedly.

Trigger:

Same error or same error category fails 3 times.

Avoidance Rule:

After 3 failed attempts, stop and summarize.

Recovery:

Ask Barry before continuing.

Source Project:

DocAgent / general AI development.

Promote To:

HARNESS.md, NEW_PROJECT_STARTER.md, BLOCK_ENGINE.md

---

## F002 — Windows GUI Threading Failure

Failure:

Background thread updates tkinter/customtkinter UI directly.

Trigger:

Worker thread modifies UI widget.

Avoidance Rule:

All UI updates must be scheduled on the main thread.

Recovery:

Use `self.after(0, ...)` or equivalent scheduler.

Source Project:

DocAgent

Promote To:

NEW_PROJECT_STARTER.md, project-specific HARNESS.md

---

## F003 — Windows UTF-8 Output Failure

Failure:

Chinese or non-ASCII output corrupts or crashes on Windows stdout/stderr.

Trigger:

Windows console prints non-ASCII text without UTF-8 handling.

Avoidance Rule:

Explicitly configure UTF-8 output.

Source Project:

DocAgent

Promote To:

NEW_PROJECT_STARTER.md, project-specific HARNESS.md

---

## F004 — Native Drag-and-Drop Dead End

Failure:

Repeated failed attempts to implement native drag-and-drop without proper COM strategy.

Trigger:

Trying native Windows drag-and-drop casually.

Avoidance Rule:

Do not reopen unless using deliberate COM `IDropTarget` plan.

Source Project:

DocAgent

Promote To:

NEW_PROJECT_STARTER.md

---

## F005 — Missing Output Folder

Failure:

Program writes to output path that does not exist.

Trigger:

File write assumes folder exists.

Avoidance Rule:

Always create output folders before writing.

Source Project:

DocAgent / general Python projects

Promote To:

NEW_PROJECT_STARTER.md, project-specific HARNESS.md


---

## F006 — Dangling File Reference After Restructure

Failure:

A file is removed, renamed, or moved, but other BOS files still reference the old name.

Trigger:

Repository restructure, version upgrade, or module reorganization.

Avoidance Rule:

Maintain MANIFEST.md and run a reference check before release.

Recovery:

1. Identify missing referenced file.
2. Either restore the file or update every reference.
3. Regenerate MANIFEST.md.
4. Record the fix in PROJECT_STATE.md.

Source Project:

BOS Next v1.1 debug review.

Promote To:

MANIFEST.md, HARNESS.md, CHECKPOINT.md


---

## F007 — PowerShell Copy-Item Folder Nesting When Destination Exists

### Failure Pattern

When using PowerShell:

```powershell
Copy-Item -Path $SourceFolder -Destination $TargetFolder -Recurse -Force
```

the result depends on whether `$TargetFolder` already exists.

If `$TargetFolder` does not exist, PowerShell may copy the source folder contents into the target as expected.

If `$TargetFolder` already exists, PowerShell can nest the source folder inside the target folder, creating:

```text
TargetFolder\SourceFolder\...
```

instead of:

```text
TargetFolder\...
```

This causes verification to report required files as missing even though the files exist one level deeper.

### Risk

This can break installer scripts, portable package scripts, project generators, and any Windows setup workflow.

### Required Rule

For installer and project-generation scripts, copy folder contents explicitly:

```powershell
New-Item -ItemType Directory -Path $TargetFolder -Force | Out-Null
Copy-Item -Path (Join-Path $SourceFolder '*') -Destination $TargetFolder -Recurse -Force
```

### Promotion Target

This rule must be inherited by:

- future boot scripts
- project generators
- document generators
- portable release builders
- Windows packaging workflows


---

## F008 — Markdown Formatting Breaks Machine-Checkable Manifest Paths

### Failure Pattern

A generated `MANIFEST.md` may wrap file paths in Markdown formatting for readability:

```text
- `00_BOOTSTRAP/BLOCK_ENGINE.md`
```

This looks fine to humans, but a simple integrity checker may read the path literally, including the backticks, and then falsely report that every file is missing.

### Risk

The manifest becomes visually readable but mechanically unreliable.

This creates false integrity failures and makes Barry less likely to trust future verification reports.

### Required Rule

For machine-checkable manifests, file list entries must use plain paths:

```text
- 00_BOOTSTRAP/BLOCK_ENGINE.md
```

Do not wrap manifest file paths in backticks unless the checker is explicitly designed to strip them.

### Recovery Steps

1. Regenerate `MANIFEST.md` using plain paths.
2. Re-run integrity check.
3. Confirm:
   - every listed file exists
   - every Markdown file is listed
   - no obsolete internal release labels remain
4. Promote this lesson to future release-builder and manifest-generator workflows.

### Promotion Target

This rule must be inherited by:

- future manifest generators
- release builders
- integrity checkers
- project packaging scripts
- BOS verification workflows

---

## F009 — Flat Load-Pack Filename Collision

### Failure Pattern

When building a load pack (or any flat output folder) by copying files from
several different source folders into one directory, two files from different
folders can share the same leaf name, for example:

```text
C:\BOS\Core\BOS_version_1.4\PROJECT_STATE.md
C:\BOS\Projects\<Name>\PROJECT_STATE.md
```

Both flatten to `PROJECT_STATE.md` in the destination. The second copy with
`-Force` silently overwrites the first.

### Risk

The wrong version of a file can win silently, depending only on array order.
The pack appears complete, but contains the wrong content. No error is raised.

### Required Rule

1. Do not include two files with the same leaf name in a flat pack.
2. When flattening files into one folder, track seen leaf names and skip or
   rename duplicates, and print a visible WARNING rather than overwriting
   silently:

```powershell
$SeenLeafNames = @{}
foreach ($File in $FilesToPack) {
    $Leaf = Split-Path $File -Leaf
    if ($SeenLeafNames.ContainsKey($Leaf)) {
        Write-Host "WARNING: Duplicate file name skipped: $Leaf" -ForegroundColor Yellow
        continue
    }
    $SeenLeafNames[$Leaf] = $File
    Copy-Item -Path $File -Destination (Join-Path $TempPack $Leaf) -Force
}
```

### Promotion Target

This rule must be inherited by:

- load-pack builders
- handoff packagers
- release builders
- any script that flattens files from multiple folders into one

---

## F010 — DeepSeek HomeVisualizer Builder Execution Failure (Failure Case 001)

## Failure Pattern

Good Incubator idea, failed Builder execution.

## Symptoms

```text
Ghost file claims
Fake verification logs
Unsafe PowerShell generation
Coding before architecture
Wrong state model
No real environment check
```

## Rule Promoted

A successful Incubator idea is not permission to code. Every implementation must pass Architecture Gate, Environment Reality Gate, File Creation Gate, Block Approval Gate, and Verification Gate.

## Short Memory

BOS must never confuse generated text with executed work.

---

## F011 — Unchecked String Replacement and Emulated Verification Divergence

Failure:

A scripted text replacement silently did nothing because an earlier replacement had already altered its match context, leaving a stale required-file entry in a verification script. A separate verification emulation used its own copy of the required list instead of parsing the real script, so it passed while the real script failed on the user's machine.

Trigger:

1. Sequential text replacements where a later pattern depends on text an earlier replacement changes.
2. `replace()`-style edits without asserting the match occurred.
3. Verifying a model of an artifact instead of the artifact's actual content.

Avoidance Rule:

1. Every scripted replacement must assert exactly one match before writing.
2. Order-dependent replacements must be applied most-specific-first, or the result must be re-scanned for stale patterns after all edits (e.g. grep for the old version string).
3. When PowerShell (or any target runtime) is unavailable, the verification emulation must parse required lists, regexes, and paths out of the real script text — never maintain a parallel hand-written copy.

Recovery:

Patch the file named by the failing verification line, regenerate checksums, rebuild, and re-verify by parsing the real script.

Source Project:

Portable BOS v1.4.5 release (2026-07-04), caught by Barry's on-machine verification.

Promote To:

SAFE_FILE_GENERATION_RULES.md, BOS_PACKAGE_QA_GATE.md workflows, release builders.

---

## F012 — Present-Tense Drift in State Documents

Failure:

State documents (PROJECT_STATE.md, workflow levels, rollback policy) carried sections written in present tense — "Current Active Package", "Current v1.4.2 status", "Main Purpose Of This Release" — that were never updated as new releases appended checkpoints below them. The package header said v1.4.6 while the body still claimed v1.4.2 was the current active package. Found by an external review of the delivered v1.4.6 ZIP.

Trigger:

Updating a state document by appending new entries and bumping the header, without re-reading the existing body for present-tense claims that the new release invalidates.

Avoidance Rule:

1. A "Current X" claim may exist in at most one place; everywhere else references that source (VERSION.txt, MODULE_REGISTRY.md, or the active patch manifest).
2. Historical narrative must be labelled historical ("Historical: v1.4.2 Release Purpose"), never left under a present-tense heading.
3. Every release patch must grep active files for "Current", "current version", "active package", and prior release ZIP names, and either update or re-label each hit.
4. Where practical, make the claim mechanically checkable: VERIFY_BOS_PACKAGE.ps1 now confirms PROJECT_STATE.md's Current Active Package matches the registry PACKAGE_NAME.

Recovery:

Restructure the state document: one verified current section at the top, historical sections explicitly labelled, and a verifier check added for the highest-value claim.

Source Project:

Portable BOS v1.4.7 corrective patch (2026-07-04), triggered by Barry's uploaded external review of the v1.4.6 package.

Promote To:

CHECKPOINT.md discipline, release-builder workflows, VERIFY_BOS_PACKAGE.ps1.
