# PATCH_MANIFEST_v1.4.7.md

## Patch Identity

```text
Internal version: 1.4.7
External ZIP name: Portable_BOS_v1.47.zip
Date: 2026-07-04
Rollback target: Portable_BOS_v1.46.zip / internal v1.4.6 package
```

## Reason For Patch

Barry uploaded an external review of the delivered v1.4.6 ZIP that found present-tense drift: PROJECT_STATE.md still claimed `Portable_BOS_version_1.4.2_User_Content_Survival_Patch_VERIFIED.zip` as the Current Active Package, and other sections described v1.4.2 as current. Root cause: releases updated headers and appended checkpoints without re-reading body sections written in present tense. Fixed, guarded mechanically, and promoted as F012.

## Files Added

```text
BOS_MENU_BOOK_v1.4.7.md
BOS_INTEGRITY_MAP_v1.4.7.md
INTEGRITY_REPORT_v1.4.7.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.7.md
PATCH_MANIFEST_v1.4.7.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.7.md
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.7.md
```

## Files Changed

```text
BOS_version_1.4/PROJECT_STATE.md                 (drift fix + v1.4.7 checkpoint)
BOS_version_1.4/02_ENGINEERING/WORKFLOW.md       (Level 3.5 de-versioned)
BOS_version_1.4/12_UPGRADE_SYSTEM/ROLLBACK_POLICY.md (current target defers to patch manifest)
BOS_version_1.4/01_EXPERIENCE/FAILURE_LIBRARY.md (F012 + index)
VERIFY_BOS_PACKAGE.ps1                           (drift guard + v1.4.7 bump)
BOS_UPGRADE_MANAGER.ps1
BUILD_BOS_ACTIVATION_ZIP.ps1
ACTIVATE_BOS_GATEWAY.ps1
00_FIRST_READ_ME.md
ACTIVATE_BOS_FROM_ZIP.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md (both copies, kept byte-identical)
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
BOS_version_1.4/MANIFEST.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md (current mapping)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md (v1.4.7 entry)
PACKAGE_CHECKSUMS.txt (regenerated)
```

## Files Archived

```text
BOS_MENU_BOOK_v1.4.6.md -> archive/v1.4.6_root_release_files/
BOS_INTEGRITY_MAP_v1.4.6.md -> archive/v1.4.6_root_release_files/
INTEGRITY_REPORT_v1.4.6.md -> archive/v1.4.6_root_release_files/
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.6.md -> archive/v1.4.6_root_release_files/
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.6.md -> BOS_version_1.4/07_ARCHIVE/v1.4.6_upgrade_reports/
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.6.md -> BOS_version_1.4/07_ARCHIVE/v1.4.6_upgrade_reports/
```

## Registry / Manifest Impact

```text
MODULE_REGISTRY.md updated: yes (both copies, byte-identical)
BOS_ACTIVATION_MANIFEST.md updated: yes
BOS_version_1.4/MANIFEST.md updated: yes
```

## Verification Plan

```text
1. Regenerate PACKAGE_CHECKSUMS.txt.
2. Run source verification parsing the real VERIFY_BOS_PACKAGE.ps1.
3. Extract ZIP into clean temp folder; verify from there.
4. Generate SHA256.
```

## Expected Result

```text
PACKAGE VERIFICATION PASSED
Present-tense drift check passed.
BOS UPGRADE MANAGER PASSED
```

## User Content Survival Check

```text
Does the patch touch user project folders? no
```
