# BOS_MENU_BOOK_v1.4.9.md

## Portable BOS Menu Book

Version: 1.4.9 - Universal Incubation Upgrade

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What v1.4.9 Adds

```text
Universal Incubation Upgrade:
1. Daily-Use Controls Baseline (06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md):
   mandatory everyday-usability checklist (font size, folder pickers,
   undo/redo, no-empty-area layout, progress feedback, remembered
   settings). Incubator gains Step 12B gate: every item answered
   INCLUDED / DEFERRED / N-A before Builder handoff.
2. Office Document Processing Extension
   (08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md):
   analysis depth layers, litigation/financial advisory rules, bilingual
   Chinese-English handling, acceptance tests. Serves DocAgent /
   IntelliDoc Advisor line.
3. Delivery Profile (03_INTELLIGENCE/DELIVERY_PROFILE.md): Barry's
   standing paths and delivery defaults stated as assumptions, never
   re-asked (C:\BOS\By chatgpt auto-locate case).
4. Block Delivery Procedure (02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md):
   the 12-section block delivery contract with the standard auto-locate
   install batch, promoted from the HomeVisualizer Block 37 procedure.
Purpose: daily-use basics are planned, not patched; Barry's manual work
per block is download, copy-run, paste result.
All v1.4.8 Efficient Block Round Rules capabilities carried forward.
```

## Menu A - Easy ZIP Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Menu B - Required AI Activation Result

```text
BOS v1.4.9 activated.

I loaded the Core Digest, Module Registry, Core, Governance, User Content Survival,
Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard,
User-Facing Design Review Gate, Fast UI Polish Mode, Efficient Block Round Rules,
Block Delivery Procedure, Daily-Use Controls Baseline, Delivery Profile,
Universal Design Rules, Gateway Safety Notice, and Persona rules.

Do you already have an Incubator-generated idea / Project Seed, or should I run
Incubator v1.1 from your raw idea?
```

## Menu C - Upgrade Safety

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Read BOS_ACTIVATION_MANIFEST.md.
4. Update all affected references.
5. Grep active files for "Current", old ZIP names, and prior versions;
   update or re-label every present-tense hit (F012).
6. Update PATCH_MANIFEST.
7. Regenerate PACKAGE_CHECKSUMS.txt.
8. Run package verification (files + registry + identity + checksums + drift).
9. Extract ZIP into a clean temp folder; verify again from there.
10. Release ZIP + SHA256 only after pass.
```

## Menu D - Naming Rule

```text
External release name: Portable_BOS_v1.49.zip
Internal version: 1.4.9
Corrective releases: next PATCH version, never a name suffix.
```

## Menu E - Block Format

```text
BLOCK:
FILES TOUCHED:
DONE WHEN:
RISK:
USER CONTENT SURVIVAL CHECK:
PACKAGE QA CHECK:
USER-FACING DESIGN REVIEW CHECK:
PRE-DELIVERY EXECUTION RESULT:
VERIFICATION:
PROMOTION CHECK:
```

## Menu F - Block Round Quick Reference

```text
Before delivery: run the real suite (paste real SUMMARY) + clean-extract test
+ DOM smoke for browser apps.
Layout blocks: screenshot before and after.
2 failed rounds on one symptom: deliver a diagnosis, not fix attempt #3.
Debug loop may run locally (Claude Code); release loop is always chat+ZIP.
```

## Final Rule

```text
Simple outside. Detailed inside. Verify the ZIP, not only the source.
Barry confirms tests; Barry does not discover failures.
```
