# PATCH_MANIFEST_v1.4.6.md

## Patch Identity

```text
Internal version: 1.4.6
External ZIP name: Portable_BOS_v1.46.zip
Date: 2026-07-04
Rollback target: Portable_BOS_v1.44.zip / internal v1.4.4 package
```

## Reason For Patch

The first v1.4.5 package failed Barry's on-machine verification: a stale entry in the VERIFY_BOS_PACKAGE.ps1 required list (UPGRADE_COMPLETION_REPORT_v1.4.4.md) caused by an unchecked scripted replacement, undetected because build-side verification used a parallel hand-written list instead of parsing the real script. Barry also rejected an AI-proposed "_REPACK" corrective package name as a Naming Standard violation. This corrective release ships the full v1.4.5 scope plus the fix, F011, and the No-Suffix Corrective Release Rule under the next PATCH version.

## Files Added

```text
BOS_MENU_BOOK_v1.4.6.md
BOS_INTEGRITY_MAP_v1.4.6.md
INTEGRITY_REPORT_v1.4.6.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.6.md
PATCH_MANIFEST_v1.4.6.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.6.md
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.6.md
```

## Files Changed

```text
VERIFY_BOS_PACKAGE.ps1                                        (stale entry fix + v1.4.6 bump)
BOS_version_1.4/01_EXPERIENCE/FAILURE_LIBRARY.md              (F011 + index entry)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md (No-Suffix Corrective Release Rule)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md      (correction note + v1.4.6 entry)
BOS_UPGRADE_MANAGER.ps1
BUILD_BOS_ACTIVATION_ZIP.ps1
ACTIVATE_BOS_GATEWAY.ps1
00_FIRST_READ_ME.md
ACTIVATE_BOS_FROM_ZIP.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md (both copies, kept byte-identical)
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
BOS_version_1.4/MANIFEST.md
BOS_version_1.4/PROJECT_STATE.md
PACKAGE_CHECKSUMS.txt (regenerated)
```

## Files Archived

```text
BOS_MENU_BOOK_v1.4.5.md -> archive/v1.4.5_root_release_files/
BOS_INTEGRITY_MAP_v1.4.5.md -> archive/v1.4.5_root_release_files/
INTEGRITY_REPORT_v1.4.5.md -> archive/v1.4.5_root_release_files/
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.5.md -> archive/v1.4.5_root_release_files/
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.5.md -> BOS_version_1.4/07_ARCHIVE/v1.4.5_upgrade_reports/
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.5.md -> BOS_version_1.4/07_ARCHIVE/v1.4.5_upgrade_reports/
```

## Registry / Manifest Impact

```text
MODULE_REGISTRY.md updated: yes (both copies, kept byte-identical)
BOS_ACTIVATION_MANIFEST.md updated: yes
BOS_version_1.4/MANIFEST.md updated: yes
```

## Verification Plan

```text
1. Regenerate PACKAGE_CHECKSUMS.txt.
2. Run source verification parsing the real VERIFY_BOS_PACKAGE.ps1.
3. Extract ZIP into clean temp folder.
4. Run verification from the extracted folder, including checksum verification.
5. Generate SHA256 of the ZIP.
```

## Expected Result

```text
PACKAGE VERIFICATION PASSED
Checksums verified for <N> files.
BOS UPGRADE MANAGER PASSED
Clean ZIP extraction verification passed
```

## User Content Survival Check

```text
Does the patch touch user project folders? no
```
