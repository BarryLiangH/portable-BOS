# PATCH_MANIFEST_v1.4.9.md

## Patch Identity

```text
Patch ID: P-1.4.9-01
Internal version: 1.4.9
External ZIP name: Portable_BOS_v1.49.zip
Date: 2026-07-04
Rollback target: Portable_BOS_v1.48.zip
```

## Reason For Patch

Barry directed the Incubator to serve universal project planning, not
HomeVisualizer only, with three requirements from real project pain:
(1) daily-use basics (font size, folder searching, undo/redo, display
location/size, empty-area-free layout) must be planned by the AI before
the first build instead of discovered by Barry's manual testing rounds
(HomeVisualizer and DocAgent cases); (2) office document systems need
analysis depth with litigation and financial advisories and execution
procedures (DocAgent / IntelliDoc Advisor line); (3) delivery defaults
such as the C:\BOS\By chatgpt ZIP folder must be standing assumptions,
never re-asked. Barry additionally directed that the proven 12-section
HomeVisualizer block delivery procedure (reference: Block 37) become a
BOS standard to remove his file drag-and-copy time.

## Files Added

```text
BOS_version_1.4/06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md
BOS_version_1.4/02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md
BOS_version_1.4/03_INTELLIGENCE/DELIVERY_PROFILE.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md
BOS_MENU_BOOK_v1.4.9.md
BOS_INTEGRITY_MAP_v1.4.9.md
INTEGRITY_REPORT_v1.4.9.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.9.md
PATCH_MANIFEST_v1.4.9.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.9.md
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.9.md
```

## Files Changed

```text
BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
  (Step 12 reads Delivery Profile first; new Step 12B Daily-Use Controls
   Baseline Gate; quality checklist extended)
BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
  (office extension registered; loading rule added)
MODULE_REGISTRY.md (both copies, byte-identical; 5 module IDs added:
  BLOCK_DELIVERY_PROCEDURE_ACTIVE, DAILY_USE_CONTROLS_BASELINE_ACTIVE,
  DELIVERY_PROFILE_ACTIVE, CAD_EXTENSION_ACTIVE, OFFICE_DOC_EXTENSION_ACTIVE)
BOS_ACTIVATION_MANIFEST.md (new modules and both domain extensions in load order)
BOS_version_1.4/MANIFEST.md (active file list extended)
VERIFY_BOS_PACKAGE.ps1 (required list +4; four new manifest gates;
  drift guard now checks v1.4.8; version references v1.4.9)
BOS_UPGRADE_MANAGER.ps1 / BUILD_BOS_ACTIVATION_ZIP.ps1 /
  ACTIVATE_BOS_GATEWAY.ps1 (version references)
00_FIRST_READ_ME.md / ACTIVATE_BOS_FROM_ZIP.md / README_START_HERE.md /
  PORTABLE_BOS_SYSTEM_PROMPT.md (version references)
VERSION.txt
BOS_version_1.4/PROJECT_STATE.md (Current Active Package -> v1.49;
  v1.4.8 checkpoint preserved; v1.4.9 checkpoint added)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md (v1.4.9 entry)
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
  (current mapping)
PACKAGE_CHECKSUMS.txt (regenerated)
```

## Files Archived

```text
archive/v1.4.8_root_release_files/BOS_MENU_BOOK_v1.4.8.md
archive/v1.4.8_root_release_files/BOS_INTEGRITY_MAP_v1.4.8.md
archive/v1.4.8_root_release_files/INTEGRITY_REPORT_v1.4.8.md
archive/v1.4.8_root_release_files/BOS_GATEWAY_LIMITATION_NOTICE_v1.4.8.md
BOS_version_1.4/07_ARCHIVE/v1.4.8_upgrade_reports/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.8.md
BOS_version_1.4/07_ARCHIVE/v1.4.8_upgrade_reports/UPGRADE_COMPLETION_REPORT_v1.4.8.md
```

## Files Removed

```text
None.
```

## Verification Method

```text
Emulated verification parsing the real updated VERIFY_BOS_PACKAGE.ps1
(required list, registry paths, registry identity, journal, naming,
drift guard, manifest gates, checksums, PROJECT_STATE drift), plus
clean ZIP extraction re-verification. Barry runs VERIFY_BOS_PACKAGE.ps1
on Windows as the confirming test.
```
