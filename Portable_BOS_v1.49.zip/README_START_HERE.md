# README_START_HERE.md

## Portable BOS v1.4.9 Universal Incubation Upgrade

External release ZIP:

```text
Portable_BOS_v1.49.zip
```

Start here only if you are reading the ZIP contents manually.

For normal AI activation, Barry only needs this command:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What This Version Adds

v1.4.9 preserves all prior gates (including the v1.4.8 Efficient Block Round Rules) and adds the Universal Incubation Upgrade:

```text
1. Daily-Use Controls Baseline - every project plan answers the everyday
   usability checklist (font size, folder pickers, undo/redo, no-empty-
   area layout, progress feedback, remembered settings) item by item as
   INCLUDED / DEFERRED / N-A before Builder handoff. Incubator Step 12B.
2. Office Document Processing Extension - analysis depth layers,
   litigation/financial advisory rules, bilingual Chinese-English
   handling, acceptance tests. Serves DocAgent / IntelliDoc Advisor.
3. Delivery Profile - Barry's standing paths and delivery defaults
   (C:\BOS\By chatgpt, backups, canonical project roots) stated as
   assumptions, never re-asked.
4. Block Delivery Procedure - the 12-section block delivery contract
   with the standard auto-locate install batch, promoted from the
   HomeVisualizer Block 37 procedure.
```

Modules:
BOS_version_1.4/06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md
BOS_version_1.4/03_INTELLIGENCE/DELIVERY_PROFILE.md
BOS_version_1.4/02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md

## Main Protection Files

```text
MODULE_REGISTRY.md
BOS_ACTIVATION_MANIFEST.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.9.md
BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_MANIFEST_TEMPLATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_COMMAND.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.9.md
BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md
BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md
BOS_version_1.4/00_BOOTSTRAP/BOS_CORE_DIGEST.md
PACKAGE_CHECKSUMS.txt
PATCH_MANIFEST_v1.4.9.md
```

## Active Incubator

```text
BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

## Simple Activation

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Gateway Warning

Simple ZIP activation is preferred.

The Gateway installer is optional. If it is used, existing project files must be skipped by default and recorded in a conflict/rerun report unless Barry explicitly approves overwrite with backup.

## Upgrade Protection

Every BOS update must read the Upgrade Journal first, use the Module Registry as the active module map, run verification, update the journal, run clean-install ZIP simulation, and build a verified ZIP plus SHA256.
