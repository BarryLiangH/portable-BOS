# PATCH_MANIFEST_v1.4.3.md

## Patch Identity

```text
Internal version: 1.4.3
External ZIP name: Portable_BOS_v1.43.zip
Rollback target: Portable_BOS_v1.42.zip / internal v1.4.2 package
```

## Reason For Patch

Barry identified that HomeVisualizer packaging/testing problems created repeated false failures after the app logic was already correct. The root causes were test-version drift, incomplete patch contents, and lack of clean-install ZIP verification.

Barry also required naming discipline: simple external ZIP names and detailed internal documentation.

## Files Added

```text
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_MANIFEST_TEMPLATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_COMMAND.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.3.md
BOS_version_1.4/12_UPGRADE_SYSTEM/UPGRADE_COMPLETION_REPORT_v1.4.3.md
BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md
BOS_MENU_BOOK_v1.4.3.md
BOS_INTEGRITY_MAP_v1.4.3.md
INTEGRITY_REPORT_v1.4.3.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.3.md
PATCH_MANIFEST_v1.4.3.md
```

## Files Changed

```text
00_FIRST_READ_ME.md
ACTIVATE_BOS_FROM_ZIP.md
ACTIVATE_BOS_GATEWAY.ps1
BOS_ACTIVATION_MANIFEST.md
BOS_UPGRADE_MANAGER.ps1
BUILD_BOS_ACTIVATION_ZIP.ps1
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERIFY_BOS_PACKAGE.ps1
VERSION.txt
BOS_version_1.4/MANIFEST.md
BOS_version_1.4/PROJECT_STATE.md
BOS_version_1.4/README.md
BOS_version_1.4/02_ENGINEERING/SAFE_FILE_GENERATION_RULES.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_POLICY.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_APPLICATION_RULES.md
BOS_version_1.4/12_UPGRADE_SYSTEM/REFERENCE_INTEGRITY_CHECK.md
BOS_version_1.4/12_UPGRADE_SYSTEM/VERSIONING_POLICY.md
```

## Files Archived

```text
BOS_MENU_BOOK_v1.4.2.md -> archive/v1.4.2_root_release_files/
BOS_INTEGRITY_MAP_v1.4.2.md -> archive/v1.4.2_root_release_files/
INTEGRITY_REPORT_v1.4.2.md -> archive/v1.4.2_root_release_files/
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.2.md -> archive/v1.4.2_root_release_files/
DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.2.md -> BOS_version_1.4/07_ARCHIVE/v1.4.2_upgrade_reports/
UPGRADE_COMPLETION_REPORT_v1.4.2.md -> BOS_version_1.4/07_ARCHIVE/v1.4.2_upgrade_reports/
```

## Verification Result

```text
Source verification passed.
Clean extraction verification passed.
Final ZIP created as Portable_BOS_v1.43.zip.
SHA256 generated.
```
