# 00_FIRST_READ_ME.md

## Simple Activation

This is the first file the AI must read after Barry uploads the Portable BOS ZIP.

Barry only needs to say:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## What the AI Must Do

1. Read `BOS_ACTIVATION_MANIFEST.md`.
2. Read `MODULE_REGISTRY.md`.
3. Confirm the active module registry is understood.
4. Load Core BOS, Governance, User Content Survival, Incubator v1.1, Memory, Upgrade System, Gateway Safety Notice, and Persona files in the manifest order.
5. Apply the BOS Integrity Gates before any implementation:
   - Architecture Gate
   - Environment Reality Gate
   - File Creation Gate
   - Block Approval Gate
   - Verification Gate
   - User Content Survival Gate
6. Ask Barry whether he already has an Incubator-generated idea or wants to run Incubator v1.1 now.
7. Use the active Incubator from the registry:
   `BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md`
8. Create or accept a Project Seed.
9. Run Architecture Gate, Fragile Shortcut Check, Environment Reality Check, Builder Safety Handoff, and User Content Survival check.
10. Propose Block 1 only.
11. Do not write code until Barry approves Block 1.

## User Content Survival Protection

Before any rerun, gateway action, project generation, or upgrade work touches project folders, the AI must apply:

```text
BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
```

Main rule:

```text
User content must survive rerun.
```

Default behavior for existing project files is SKIP unless Barry explicitly approves overwrite with backup.

## Upgrade System Protection

For BOS updates, the AI must read:

```text
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
MODULE_REGISTRY.md
BOS_ACTIVATION_MANIFEST.md
```

Do not release a new ZIP until:

```text
1. all affected references are updated;
2. MODULE_REGISTRY.md is correct;
3. BOS_UPGRADE_JOURNAL.md has a new entry;
4. integrity check passes;
5. clean-install simulation from the ZIP passes;
6. verified ZIP and SHA256 are produced.
```

## First Response Required

After activation, the AI should say:

```text
BOS v1.4.9 activated.

I loaded Core, Governance, User Content Survival, Incubator, Memory, Upgrade System, Package QA, Release Naming Standard, and Persona.

Do you already have an Incubator-generated idea / Project Seed, or should I run Incubator v1.1 from your raw idea?
```
