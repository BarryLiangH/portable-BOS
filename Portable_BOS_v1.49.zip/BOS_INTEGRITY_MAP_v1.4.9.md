# BOS_INTEGRITY_MAP_v1.4.9.md

## Purpose

Map the active Portable BOS v1.4.9 integrity structure.

## Active Identity

```text
External ZIP: Portable_BOS_v1.49.zip
Internal version: 1.4.9
Core folder: BOS_version_1.4
```

## Required Active Root Files

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
PORTABLE_BOS_SYSTEM_PROMPT.md
README_START_HERE.md
VERSION.txt
PACKAGE_CHECKSUMS.txt
BOS_MENU_BOOK_v1.4.9.md
BOS_INTEGRITY_MAP_v1.4.9.md
INTEGRITY_REPORT_v1.4.9.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.9.md
PATCH_MANIFEST_v1.4.9.md
```

## v1.4.9 Additions

```text
BOS_version_1.4/06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md
BOS_version_1.4/02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md
BOS_version_1.4/03_INTELLIGENCE/DELIVERY_PROFILE.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md
```

## Pass Criteria

```text
1. Active registry paths exist.
2. Current version references point to v1.4.9 files.
3. Simple activation is unchanged.
4. All prior gates active; Daily-Use Controls Baseline, Block Delivery
   Procedure, Delivery Profile, and Office Document Extension registered
   and loaded.
5. Both MODULE_REGISTRY.md copies are byte-identical.
6. Every checksummed file exists and matches its SHA256.
7. PROJECT_STATE.md Current Active Package matches registry PACKAGE_NAME.
8. Clean ZIP extraction verification passes.
```
