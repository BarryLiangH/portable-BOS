# VERIFY_BOS_PACKAGE.ps1
# Verifies required Portable BOS v1.4.9 files, registry paths, registry-copy identity, per-file SHA256 checksums, and present-tense drift.

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$CoreFolder = "BOS_version_1.4"
$BOSRoot = Join-Path $PackageRoot $CoreFolder
$Registry = Join-Path $PackageRoot "MODULE_REGISTRY.md"
$Journal = Join-Path $BOSRoot "12_UPGRADE_SYSTEM\BOS_UPGRADE_JOURNAL.md"

$Required = @(
    "00_FIRST_READ_ME.md",
    "BOS_ACTIVATION_MANIFEST.md",
    "MODULE_REGISTRY.md",
    "README_START_HERE.md",
    "PORTABLE_BOS_SYSTEM_PROMPT.md",
    "BOS_MENU_BOOK_v1.4.9.md",
    "INTEGRITY_REPORT_v1.4.9.md",
    "BOS_INTEGRITY_MAP_v1.4.9.md",
    "BOS_GATEWAY_LIMITATION_NOTICE_v1.4.9.md",
    "PATCH_MANIFEST_v1.4.9.md",
    "ACTIVATE_BOS_GATEWAY.ps1",
    "BUILD_BOS_ACTIVATION_ZIP.ps1",
    "BOS_UPGRADE_MANAGER.ps1",
    "VERSION.txt",
    "BOS_version_1.4\README.md",
    "BOS_version_1.4\OWNER.md",
    "BOS_version_1.4\VISION.md",
    "BOS_version_1.4\PROJECT_STATE.md",
    "BOS_version_1.4\MANIFEST.md",
    "BOS_version_1.4\00_BOOTSTRAP\BLOCK_ENGINE.md",
    "BOS_version_1.4\02_ENGINEERING\SAFE_FILE_GENERATION_RULES.md",
    "BOS_version_1.4\08_INCUBATOR\IDEA_INCUBATOR_v1.1.md",
    "BOS_version_1.4\08_INCUBATOR\DOMAIN_EXTENSION_INDEX.md",
    "BOS_version_1.4\08_INCUBATOR\domain_extensions\CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md",
    "BOS_version_1.4\09_MEMORY\MEMORY_LAYER_PROCEDURE.md",
    "BOS_version_1.4\10_GOVERNANCE\USER_CONTENT_SURVIVAL_RULES.md",
    "BOS_version_1.4\11_PERSONAS\BOS_ARCHITECT_GROWTH_PARTNER.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_UPGRADE_POLICY.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_UPGRADE_JOURNAL.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\REFERENCE_INTEGRITY_CHECK.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\VERSIONING_POLICY.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\ROLLBACK_POLICY.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_RELEASE_NAMING_STANDARD.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_PACKAGE_QA_GATE.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\PATCH_MANIFEST_TEMPLATE.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_UPGRADE_COMMAND.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.9.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\UPGRADE_COMPLETION_REPORT_v1.4.9.md",
    "BOS_version_1.4\02_ENGINEERING\EFFICIENT_BLOCK_ROUND_RULES.md",
    "BOS_version_1.4\06_STANDARDS\USER_FACING_DESIGN_REVIEW_GATE.md",
    "BOS_version_1.4\02_ENGINEERING\FAST_UI_POLISH_MODE.md",
    "BOS_version_1.4\00_BOOTSTRAP\BOS_CORE_DIGEST.md",
    "BOS_version_1.4\06_STANDARDS\BOS_INTERACTION_EDIT_SESSION_RULE.md",
    "BOS_version_1.4\06_STANDARDS\BOS_WORKSPACE_FIRST_LAYOUT_RULE.md",
    "BOS_version_1.4\06_STANDARDS\DAILY_USE_CONTROLS_BASELINE.md",
    "BOS_version_1.4\02_ENGINEERING\BLOCK_DELIVERY_PROCEDURE.md",
    "BOS_version_1.4\03_INTELLIGENCE\DELIVERY_PROFILE.md",
    "BOS_version_1.4\08_INCUBATOR\domain_extensions\OFFICE_DOCUMENT_PROCESSING_EXTENSION.md",
    "PACKAGE_CHECKSUMS.txt"
)

$Missing = @()
foreach ($Item in $Required) {
    if (-not (Test-Path (Join-Path $PackageRoot $Item))) {
        $Missing += $Item
    }
}

if ($Missing.Count -gt 0) {
    Write-Host "PACKAGE VERIFICATION FAILED" -ForegroundColor Red
    foreach ($Item in $Missing) { Write-Host "Missing: $Item" -ForegroundColor Red }
    exit 1
}

$RegistryText = Get-Content $Registry -Raw
$RegistryPaths = @()
foreach ($Line in ($RegistryText -split "`n")) {
    if ($Line -match '^\s*[A-Z0-9_]+_ACTIVE\s*=\s*(.+?)\s*$') {
        $PathValue = $Matches[1].Trim()
        if ($PathValue -and -not $PathValue.StartsWith("I uploaded")) {
            $RegistryPaths += $PathValue
        }
    }
}

$MissingRegistry = @()
foreach ($Rel in $RegistryPaths) {
    $WinRel = $Rel -replace '/', '\'
    if (-not (Test-Path (Join-Path $PackageRoot $WinRel))) {
        $MissingRegistry += $Rel
    }
}

if ($MissingRegistry.Count -gt 0) {
    Write-Host "REGISTRY VERIFICATION FAILED" -ForegroundColor Red
    foreach ($Item in $MissingRegistry) { Write-Host "Registry target missing: $Item" -ForegroundColor Red }
    exit 1
}

$JournalText = Get-Content $Journal -Raw
if ($JournalText -notmatch 'Version v1\.4\.9') {
    Write-Host "JOURNAL VERIFICATION FAILED: v1.4.9 entry not found." -ForegroundColor Red
    exit 1
}

if ($RegistryText -notmatch 'PACKAGE_NAME\s*=\s*Portable_BOS_v1\.49\.zip') {
    Write-Host "NAMING VERIFICATION FAILED: external package name mismatch." -ForegroundColor Red
    exit 1
}

if ($RegistryText -match 'ACTIVE\s*=\s*.*v1\.4\.8') {
    Write-Host "VERSION DRIFT VERIFICATION FAILED: active registry still points to v1.4.8." -ForegroundColor Red
    exit 1
}

$ManifestText = Get-Content (Join-Path $PackageRoot "BOS_ACTIVATION_MANIFEST.md") -Raw
if ($ManifestText -notmatch 'BOS_PACKAGE_QA_GATE\.md') {
    Write-Host "PACKAGE QA VERIFICATION FAILED: activation manifest does not load Package QA Gate." -ForegroundColor Red
    exit 1
}

if ($ManifestText -notmatch 'USER_FACING_DESIGN_REVIEW_GATE\.md') {
    Write-Host "DESIGN REVIEW GATE VERIFICATION FAILED: activation manifest does not load User-Facing Design Review Gate." -ForegroundColor Red
    exit 1
}

if ($ManifestText -notmatch 'FAST_UI_POLISH_MODE\.md') {
    Write-Host "FAST UI POLISH MODE VERIFICATION FAILED: activation manifest does not load Fast UI Polish Mode." -ForegroundColor Red
    exit 1
}

if ($ManifestText -notmatch 'BOS_RELEASE_NAMING_STANDARD\.md') {
    Write-Host "NAMING STANDARD VERIFICATION FAILED: activation manifest does not load Naming Standard." -ForegroundColor Red
    exit 1
}

if ($ManifestText -notmatch 'DAILY_USE_CONTROLS_BASELINE\.md') {
    Write-Host "DAILY-USE BASELINE VERIFICATION FAILED: activation manifest does not load Daily-Use Controls Baseline." -ForegroundColor Red
    exit 1
}

if ($ManifestText -notmatch 'BLOCK_DELIVERY_PROCEDURE\.md') {
    Write-Host "BLOCK DELIVERY VERIFICATION FAILED: activation manifest does not load Block Delivery Procedure." -ForegroundColor Red
    exit 1
}

if ($ManifestText -notmatch 'DELIVERY_PROFILE\.md') {
    Write-Host "DELIVERY PROFILE VERIFICATION FAILED: activation manifest does not load Delivery Profile." -ForegroundColor Red
    exit 1
}

$VersionText = Get-Content (Join-Path $PackageRoot "VERSION.txt") -Raw
if ($VersionText -notmatch '1\.4\.9' -or $VersionText -notmatch 'Portable_BOS_v1\.49\.zip') {
    Write-Host "VERSION FILE VERIFICATION FAILED." -ForegroundColor Red
    exit 1
}

# --- v1.4.5 Registry Copy Identity Check (W4) ---
$RegistryCopy = Join-Path $BOSRoot "12_UPGRADE_SYSTEM\MODULE_REGISTRY.md"
$RegistryCopyText = Get-Content $RegistryCopy -Raw
if ($RegistryText -ne $RegistryCopyText) {
    Write-Host "REGISTRY IDENTITY VERIFICATION FAILED: root MODULE_REGISTRY.md and 12_UPGRADE_SYSTEM copy differ." -ForegroundColor Red
    exit 1
}

# --- v1.4.7 Present-Tense Drift Check (F012) ---
$StateText = Get-Content (Join-Path $BOSRoot "PROJECT_STATE.md") -Raw
if ($RegistryText -match 'PACKAGE_NAME\s*=\s*(\S+)') {
    $CurrentPackage = $Matches[1]
    if ($StateText -notmatch [regex]::Escape($CurrentPackage)) {
        Write-Host "PRESENT-TENSE DRIFT VERIFICATION FAILED: PROJECT_STATE.md does not name the current package $CurrentPackage." -ForegroundColor Red
        exit 1
    }
}
if ($StateText -match 'Current Active Package[\s\S]{0,200}?VERIFIED\.zip') {
    Write-Host "PRESENT-TENSE DRIFT VERIFICATION FAILED: PROJECT_STATE.md Current Active Package still names an old VERIFIED zip." -ForegroundColor Red
    exit 1
}

# --- v1.4.5 Package Checksum Verification (W3) ---
$ChecksumFile = Join-Path $PackageRoot "PACKAGE_CHECKSUMS.txt"
$ChecksumFailures = @()
$ChecksumCount = 0
foreach ($Line in (Get-Content $ChecksumFile)) {
    if ([string]::IsNullOrWhiteSpace($Line)) { continue }
    if ($Line -match '^([0-9a-fA-F]{64})\s+(.+)$') {
        $Expected = $Matches[1].ToLower()
        $Rel = $Matches[2].Trim()
        $Full = Join-Path $PackageRoot ($Rel -replace '/', '\')
        if (-not (Test-Path -LiteralPath $Full)) {
            $ChecksumFailures += "MISSING: $Rel"
            continue
        }
        $Actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Full).Hash.ToLower()
        if ($Actual -ne $Expected) {
            $ChecksumFailures += "MISMATCH: $Rel"
        }
        $ChecksumCount++
    }
}
if ($ChecksumCount -eq 0) {
    Write-Host "CHECKSUM VERIFICATION FAILED: PACKAGE_CHECKSUMS.txt contains no valid entries." -ForegroundColor Red
    exit 1
}
if ($ChecksumFailures.Count -gt 0) {
    Write-Host "CHECKSUM VERIFICATION FAILED" -ForegroundColor Red
    foreach ($Item in $ChecksumFailures) { Write-Host $Item -ForegroundColor Red }
    exit 1
}
Write-Host ("Checksums verified for {0} files." -f $ChecksumCount) -ForegroundColor Green

Write-Host "PACKAGE VERIFICATION PASSED" -ForegroundColor Green
Write-Host "Required files found." -ForegroundColor Green
Write-Host "Registry active paths verified." -ForegroundColor Green
Write-Host "Upgrade journal verified." -ForegroundColor Green
Write-Host "Package QA Gate verified." -ForegroundColor Green
Write-Host "Release Naming Standard verified." -ForegroundColor Green
Write-Host "Simple external naming verified." -ForegroundColor Green
Write-Host "Registry copy identity verified." -ForegroundColor Green
Write-Host "Per-file checksums verified." -ForegroundColor Green
Write-Host "Present-tense drift check passed." -ForegroundColor Green
