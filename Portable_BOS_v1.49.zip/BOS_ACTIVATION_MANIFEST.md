# BOS_ACTIVATION_MANIFEST.md

# Portable BOS Activation Manifest

Version: 1.4.9 Efficient Block Round Rules

## Purpose

This manifest is the BOS bootloader. It allows Barry to upload one ZIP and activate BOS with one simple instruction.

Barry's normal activation command is:

```text
I uploaded the BOS ZIP. Read 00_FIRST_READ_ME.md and carry on.
```

## Activation Goal

```text
Barry uploads ZIP
  ↓
AI reads 00_FIRST_READ_ME.md
  ↓
AI reads this manifest
  ↓
AI reads MODULE_REGISTRY.md
  ↓
AI loads Core + Governance + User Content Survival + Incubator v1.1 + Memory + Upgrade System + Gateway Safety Notice + Persona
  ↓
AI applies Integrity Gates, including User Content Survival Gate
  ↓
AI asks Barry for an existing Incubator handoff or a raw idea
  ↓
AI creates Project Seed, runs Architecture Gate, Fragile Shortcut Check, Environment Reality Check, Builder Safety Handoff, and User Content Survival check
  ↓
AI proposes Block 1
  ↓
AI waits for approval before coding
```

## Required Load Order

Read files in this order:

```text
00_FIRST_READ_ME.md
BOS_ACTIVATION_MANIFEST.md
MODULE_REGISTRY.md
BOS_version_1.4/00_BOOTSTRAP/BOS_CORE_DIGEST.md
BOS_version_1.4/OWNER.md
BOS_version_1.4/VISION.md
BOS_version_1.4/PROJECT_STATE.md
BOS_version_1.4/02_ENGINEERING/HARNESS.md
BOS_version_1.4/02_ENGINEERING/WORKFLOW.md
BOS_version_1.4/00_BOOTSTRAP/BLOCK_ENGINE.md
BOS_version_1.4/00_BOOTSTRAP/NEW_PROJECT_STARTER.md
BOS_version_1.4/01_EXPERIENCE/FAILURE_LIBRARY.md
BOS_version_1.4/01_EXPERIENCE/SUCCESS_LIBRARY.md
BOS_version_1.4/01_EXPERIENCE/PROMOTION_ENGINE.md
BOS_version_1.4/06_STANDARDS/PORTABLE_BOS_LIMITS_AND_GUARDRAILS.md
BOS_version_1.4/06_STANDARDS/USER_FACING_DESIGN_REVIEW_GATE.md
BOS_version_1.4/06_STANDARDS/BOS_INTERACTION_EDIT_SESSION_RULE.md
BOS_version_1.4/06_STANDARDS/BOS_WORKSPACE_FIRST_LAYOUT_RULE.md
BOS_version_1.4/02_ENGINEERING/FAST_UI_POLISH_MODE.md
BOS_version_1.4/02_ENGINEERING/EFFICIENT_BLOCK_ROUND_RULES.md
BOS_version_1.4/02_ENGINEERING/BLOCK_DELIVERY_PROCEDURE.md
BOS_version_1.4/06_STANDARDS/DAILY_USE_CONTROLS_BASELINE.md
BOS_version_1.4/03_INTELLIGENCE/DELIVERY_PROFILE.md
BOS_GATEWAY_LIMITATION_NOTICE_v1.4.9.md
BOS_version_1.4/10_GOVERNANCE/BOS_GROWTH_GOVERNANCE.md
BOS_version_1.4/10_GOVERNANCE/IDEA_MATURITY_LEVELS.md
BOS_version_1.4/10_GOVERNANCE/BOS_INTEGRITY_GATES.md
BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
BOS_version_1.4/10_GOVERNANCE/FAILURE_CASE_REVIEW_RULES.md
BOS_version_1.4/10_GOVERNANCE/failure_cases/BOS_FAILURE_CASE_001_DEEPSEEK_HOMEVISUALIZER.md
BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
BOS_version_1.4/08_INCUBATOR/PROMPT_REFINER.md
BOS_version_1.4/08_INCUBATOR/SOCRATIC_TUTOR_MODE.md
BOS_version_1.4/08_INCUBATOR/HANDOFF_TO_CORE_BOS.md
BOS_version_1.4/08_INCUBATOR/INCUBATOR_TO_BUILDER_SAFETY_GATE.md
BOS_version_1.4/08_INCUBATOR/DOMAIN_EXTENSION_INDEX.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/CAD_GEOMETRY_PHYSICAL_LAYOUT_EXTENSION.md
BOS_version_1.4/08_INCUBATOR/domain_extensions/OFFICE_DOCUMENT_PROCESSING_EXTENSION.md
BOS_version_1.4/09_MEMORY/MEMORY_LAYER_PROCEDURE.md
BOS_version_1.4/09_MEMORY/LLMWIKI_PROCEDURE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_POLICY.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_JOURNAL.md
BOS_version_1.4/12_UPGRADE_SYSTEM/REFERENCE_INTEGRITY_CHECK.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_RELEASE_NAMING_STANDARD.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_PACKAGE_QA_GATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/PATCH_MANIFEST_TEMPLATE.md
BOS_version_1.4/12_UPGRADE_SYSTEM/BOS_UPGRADE_COMMAND.md
BOS_version_1.4/12_UPGRADE_SYSTEM/DEEP_INTEGRITY_VERIFIER_SCOPE_v1.4.9.md
BOS_version_1.4/11_PERSONAS/BOS_ARCHITECT_GROWTH_PARTNER.md
```

## Active Incubator Rule

The active Incubator file is defined in `MODULE_REGISTRY.md` as:

```text
INCUBATOR_ACTIVE = BOS_version_1.4/08_INCUBATOR/IDEA_INCUBATOR_v1.1.md
```

Do not use archived Incubator files for activation.

## User Content Survival Rule v1.4.2

Any rerun of activation, gateway installation, project generation, or upgrade work must protect user-created content.

```text
Default action for existing project files = SKIP.
Overwrite requires explicit Barry approval and timestamped backup.
A rerun/conflict report is required.
User content must survive rerun.
```

The active rule file is:

```text
BOS_version_1.4/10_GOVERNANCE/USER_CONTENT_SURVIVAL_RULES.md
```

## Upgrade System Rule

For any BOS update, rename, added file, removed file, branch change, package rebuild, or reference correction:

```text
1. Read BOS_UPGRADE_JOURNAL.md first.
2. Read MODULE_REGISTRY.md.
3. Treat the change as a patch.
4. Update registry, manifest, journal, scripts, and integrity report together.
5. Create/update the patch manifest.
6. Run verification before release.
7. Run clean-install ZIP simulation before release.
8. Protect user content during rerun.
```

## Optional Load Only When Needed

Do not load these unless the task needs them:

```text
BOS_version_1.4/05_PRODUCTS/BPAIECO/
BOS_version_1.4/07_ARCHIVE/
BOS_version_1.4/08_INCUBATOR/archive/
BOS_version_1.4/09_MEMORY/raw/
archive/
```

## Required AI First Response After Activation

After loading these files, the AI must say:

```text
BOS v1.4.9 activated.

I loaded the Core Digest, Module Registry, Core, Governance, User Content Survival, Incubator v1.1, Memory, Upgrade System, Package QA, Release Naming Standard, User-Facing Design Review Gate, Fast UI Polish Mode, Universal Design Rules, Gateway Safety Notice, and Persona rules.

Do you already have an Incubator-generated idea / Project Seed, or should I run Incubator v1.1 from your raw idea?
```

## No Coding Rule

The AI must not write code until:

```text
1. Project Seed is accepted.
2. Architecture Gate passes.
3. Builder Safety Handoff is complete.
4. User Content Survival check is complete.
5. Block 1 is proposed.
6. Barry approves Block 1.
```

## Gateway Safety Rule v1.4.2

Normal activation does not require running any installer.

If the Gateway installer is used, it must not silently overwrite existing project files. Existing project files must be skipped by default and recorded in a conflict/rerun report unless Barry explicitly approves replacement.

This rule applies to all user-created content, not only `README.md` and `PROJECT_STATE.md`.
