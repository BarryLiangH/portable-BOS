# BOS_UPGRADE_MANAGER.ps1
# Portable BOS v1.4.9 verification manager.
# Reads the Upgrade Journal first, checks Module Registry, verifies references, and optionally rebuilds the package.

param(
    [switch]$BuildRelease,
    [string]$OutputZip = ""
)

$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$CoreFolder = "BOS_version_1.4"
$CoreRoot = Join-Path $PackageRoot $CoreFolder
$UpgradeRoot = Join-Path $CoreRoot "12_UPGRADE_SYSTEM"
$Journal = Join-Path $UpgradeRoot "BOS_UPGRADE_JOURNAL.md"
$Registry = Join-Path $PackageRoot "MODULE_REGISTRY.md"

Write-Host ""
Write-Host "=== BOS Upgrade Manager v1.4.9 ===" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $Journal)) {
    Write-Host "FAILED: Upgrade journal not found. Upgrade cannot continue." -ForegroundColor Red
    exit 1
}

Write-Host "Step 1: Read upgrade journal" -ForegroundColor Yellow
$JournalText = Get-Content $Journal -Raw
if ($JournalText -notmatch 'Version v1\.4\.9') {
    Write-Host "FAILED: BOS_UPGRADE_JOURNAL.md does not contain v1.4.9." -ForegroundColor Red
    exit 1
}
Write-Host "OK: v1.4.9 journal entry found." -ForegroundColor Green

Write-Host "Step 2: Read module registry" -ForegroundColor Yellow
if (-not (Test-Path $Registry)) {
    Write-Host "FAILED: MODULE_REGISTRY.md not found." -ForegroundColor Red
    exit 1
}
$RegistryText = Get-Content $Registry -Raw
Write-Host "OK: MODULE_REGISTRY.md found." -ForegroundColor Green

Write-Host "Step 3: Verify package" -ForegroundColor Yellow
& (Join-Path $PackageRoot "VERIFY_BOS_PACKAGE.ps1")

Write-Host "Step 4: Verify simple activation command" -ForegroundColor Yellow
$FirstRead = Get-Content (Join-Path $PackageRoot "00_FIRST_READ_ME.md") -Raw
if ($FirstRead -notmatch 'I uploaded the BOS ZIP\. Read 00_FIRST_READ_ME\.md and carry on\.') {
    Write-Host "FAILED: Simple activation command not found or changed." -ForegroundColor Red
    exit 1
}
Write-Host "OK: Simple activation preserved." -ForegroundColor Green

Write-Host "Step 5: Verify Package QA and Naming Standard" -ForegroundColor Yellow
foreach ($Required in @(
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_PACKAGE_QA_GATE.md",
    "BOS_version_1.4\12_UPGRADE_SYSTEM\BOS_RELEASE_NAMING_STANDARD.md",
    "PATCH_MANIFEST_v1.4.9.md"
)) {
    if (-not (Test-Path (Join-Path $PackageRoot $Required))) {
        Write-Host "FAILED: Required v1.4.9 file missing: $Required" -ForegroundColor Red
        exit 1
    }
}
Write-Host "OK: Package QA and Naming Standard found." -ForegroundColor Green

if ($BuildRelease) {
    Write-Host "Step 6: Build release ZIP" -ForegroundColor Yellow
    if ([string]::IsNullOrWhiteSpace($OutputZip)) {
        $OutputZip = Join-Path (Split-Path -Parent $PackageRoot) "Portable_BOS_v1.49.zip"
    }
    & (Join-Path $PackageRoot "BUILD_BOS_ACTIVATION_ZIP.ps1") -OutputZip $OutputZip
}

Write-Host ""
Write-Host "BOS UPGRADE MANAGER PASSED" -ForegroundColor Green
Write-Host "The package is internally consistent." -ForegroundColor Green
